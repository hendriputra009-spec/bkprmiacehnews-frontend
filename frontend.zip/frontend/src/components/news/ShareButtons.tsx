'use client';

import { useState, useEffect } from 'react';
import { 
  MessageCircle, 
  Facebook, 
  Twitter, 
  Link2, 
  Check,
  Share2,
  Send
} from 'lucide-react';

interface ShareButtonsProps {
  title: string;
  description?: string;
  url?: string;
  image?: string;
}

export default function ShareButtons({
  title,
  description = '',
  url,
  image
}: ShareButtonsProps) {
  const [copied, setCopied] = useState(false);
  const [mounted, setMounted] = useState(false);
  
  // Only render on client side to avoid hydration mismatch
  useEffect(() => {
    setMounted(true);
  }, []);
  
  // Get the full URL for sharing
  const shareUrl = typeof window !== 'undefined' 
    ? url || window.location.href 
    : url || '';
  
  // Encode for URL sharing
  const encodedTitle = encodeURIComponent(title);
  const encodedDescription = encodeURIComponent(description);
  const encodedUrl = encodeURIComponent(shareUrl);

  // Share URLs
  const whatsappUrl = `https://wa.me/?text=${encodedTitle}%20-%20${encodedUrl}`;
  const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`;
  const twitterUrl = `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`;
  const telegramUrl = `https://t.me/share/url?url=${encodedUrl}&text=${encodedTitle}`;

  // Copy to clipboard function
  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = shareUrl;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Web Share API
  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title,
          text: description,
          url: shareUrl,
        });
      } catch (err) {
        console.log('Share cancelled');
      }
    }
  };

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <span className="text-sm font-medium text-slate-600 dark:text-slate-400 mr-2">
        Bagikan:
      </span>
      
      {/* WhatsApp */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="w-10 h-10 flex items-center justify-center rounded-full bg-green-500 text-white hover:bg-green-600 transition-colors"
        aria-label="Bagikan ke WhatsApp"
      >
        <MessageCircle className="w-5 h-5" />
      </a>

      {/* Facebook */}
      <a
        href={facebookUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="w-10 h-10 flex items-center justify-center rounded-full bg-blue-600 text-white hover:bg-blue-700 transition-colors"
        aria-label="Bagikan ke Facebook"
      >
        <Facebook className="w-5 h-5" />
      </a>

      {/* Twitter / X */}
      <a
        href={twitterUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="w-10 h-10 flex items-center justify-center rounded-full bg-black text-white hover:bg-slate-800 transition-colors"
        aria-label="Bagikan ke Twitter"
      >
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
        </svg>
      </a>

      {/* Telegram */}
      <a
        href={telegramUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="w-10 h-10 flex items-center justify-center rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors"
        aria-label="Bagikan ke Telegram"
      >
        <Send className="w-4 h-4" />
      </a>

      {/* Copy Link */}
      <button
        onClick={copyToClipboard}
        className={`w-10 h-10 flex items-center justify-center rounded-full transition-colors ${
          copied 
            ? 'bg-green-500 text-white' 
            : 'bg-slate-200 text-slate-600 hover:bg-slate-300 dark:bg-slate-700 dark:text-slate-300 dark:hover:bg-slate-600'
        }`}
        aria-label="Salin tautan"
      >
        {copied ? <Check className="w-5 h-5" /> : <Link2 className="w-5 h-5" />}
      </button>

      {/* Native Share (Mobile) - Only render after mount */}
      {mounted && typeof navigator !== 'undefined' && 'share' in navigator && (
        <button
          onClick={handleNativeShare}
          className="w-10 h-10 flex items-center justify-center rounded-full bg-primary text-white hover:bg-primary-600 transition-colors lg:hidden"
          aria-label="Bagikan"
        >
          <Share2 className="w-5 h-5" />
        </button>
      )}
    </div>
  );
}

