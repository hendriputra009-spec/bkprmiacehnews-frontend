import Link from 'next/link';
import { Mail, Phone, MapPin, Facebook, Instagram, Youtube, Twitter } from 'lucide-react';

const footerLinks = {
  tentang: [
    { href: '/profil', label: 'Profil Organisasi' },
    { href: '/profil?jenis=visi_misi', label: 'Visi Misi' },
    { href: '/profil?jenis=struktur_organisasi', label: 'Struktur Organisasi' },
    { href: '/tentang', label: 'Tentang Kami' },
  ],
  dpd: [
    { href: '/dpd', label: 'Daftar DPD' },
    { href: '/dpd?kabupaten=banda-aceh', label: 'DPD Banda Aceh' },
    { href: '/dpd?kabupaten=aceh-besar', label: 'DPD Aceh Besar' },
  ],
  layanan: [
    { href: '/berita', label: 'Berita' },
    { href: '/galeri', label: 'Galeri' },
    { href: '/tata-laksana', label: 'Tata Laksana Jumat' },
    { href: '/lembaga', label: 'Lembaga' },
  ],
};

export default function Footer() {
  return (
    <footer className="bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800 text-slate-300">
      {/* Main Footer Content */}
      <div className="container-page py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-16 h-16 rounded-xl overflow-hidden bg-white p-1">
                <img 
                  src="/logo/logo.jpeg" 
                  alt="BKPRMI Aceh" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h2 className="text-2xl font-heading font-bold text-white">
                  BKPRMI
                </h2>
                <p className="text-sm text-primary-400 font-medium">Aceh</p>
              </div>
            </div>
            <p className="text-slate-400 mb-6 leading-relaxed max-w-md">
              Badan Komunikasi Pemuda Remaja Masjid Indonesia. 
              Membangun generasi muda Islam yang berakhlakul karimah, bertakwa, 
              dan berintelektualitas tinggi.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800/50 flex items-center justify-center hover:bg-primary transition-all duration-300 group">
                <Facebook className="w-5 h-5 group-hover:text-white" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800/50 flex items-center justify-center hover:bg-primary transition-all duration-300 group">
                <Instagram className="w-5 h-5 group-hover:text-white" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800/50 flex items-center justify-center hover:bg-primary transition-all duration-300 group">
                <Youtube className="w-5 h-5 group-hover:text-white" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800/50 flex items-center justify-center hover:bg-primary transition-all duration-300 group">
                <Twitter className="w-5 h-5 group-hover:text-white" />
              </a>
            </div>
          </div>

          {/* Tentang */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-5 relative">
              <span className="relative z-10">Tentang</span>
              <span className="absolute left-0 bottom-0 w-8 h-0.5 bg-primary rounded-full"></span>
            </h3>
            <ul className="space-y-3">
              {footerLinks.tentang.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-slate-400 hover:text-primary hover:pl-2 transition-all duration-300 text-sm">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* DPD */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-5 relative">
              <span className="relative z-10">DPD</span>
              <span className="absolute left-0 bottom-0 w-8 h-0.5 bg-primary rounded-full"></span>
            </h3>
            <ul className="space-y-3">
              {footerLinks.dpd.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-slate-400 hover:text-primary hover:pl-2 transition-all duration-300 text-sm">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Layanan */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-5 relative">
              <span className="relative z-10">Layanan</span>
              <span className="absolute left-0 bottom-0 w-8 h-0.5 bg-primary rounded-full"></span>
            </h3>
            <ul className="space-y-3">
              {footerLinks.layanan.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-slate-400 hover:text-primary hover:pl-2 transition-all duration-300 text-sm">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Contact Info Bar */}
        <div className="mt-12 pt-8 border-t border-slate-700/50">
          <div className="flex flex-col lg:flex-row gap-6 lg:items-center lg:justify-between">
            <div className="flex flex-col sm:flex-row gap-6 sm:gap-10">
              <a href="tel:082248526996" className="flex items-center gap-3 group">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary transition-colors">
                  <Phone className="w-4 h-4 text-primary group-hover:text-white" />
                </div>
                <span className="text-sm group-hover:text-white transition-colors">0822-4852-6996</span>
              </a>
              <a href="mailto:bkprmi.aceh@gmail.com" className="flex items-center gap-3 group">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary transition-colors">
                  <Mail className="w-4 h-4 text-primary group-hover:text-white" />
                </div>
                <span className="text-sm group-hover:text-white transition-colors">bkprmi.aceh@gmail.com</span>
              </a>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <MapPin className="w-4 h-4 text-primary" />
                </div>
                <span className="text-sm">Aceh, Indonesia</span>
              </div>
            </div>
            <p className="text-sm text-slate-500">
              © {new Date().getFullYear()} BKPRMI Aceh. All rights reserved.
            </p>
          </div>
        </div>
      </div>
      
      {/* Bottom Bar */}
      <div className="border-t border-slate-800/50">
        <div className="container-page py-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-slate-500">
            <p>Dikembangkan dengan ❤️ oleh Tim BKPRMI Aceh</p>
            <div className="flex gap-6">
              <Link href="/privacy" className="hover:text-primary transition-colors">Kebijakan Privasi</Link>
              <Link href="/terms" className="hover:text-primary transition-colors">Ketentuan Layanan</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
