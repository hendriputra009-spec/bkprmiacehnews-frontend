'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { Calendar } from 'lucide-react';

interface YearFilterProps {
  availableYears: number[];
  currentYear: string;
}

export default function YearFilter({ availableYears, currentYear }: YearFilterProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const tahun = searchParams.get('tahun') || '';

  const handleYearChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedYear = e.target.value;
    if (selectedYear) {
      router.push(`/galeri?tahun=${selectedYear}`);
    } else {
      router.push('/galeri');
    }
  };

  return (
    <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center">
          <Calendar className="w-6 h-6 text-secondary" />
        </div>
        <div className="flex-1">
          <label className="text-sm text-slate-500 block mb-1">Filter Tahun</label>
          <select 
            value={tahun}
            onChange={handleYearChange}
            className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 bg-white"
          >
            <option value="">Semua Tahun</option>
            {availableYears.map((year: number) => (
              <option key={year} value={year}>{year}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
}

