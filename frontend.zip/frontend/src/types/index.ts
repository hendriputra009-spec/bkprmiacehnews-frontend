export interface User {
  id: number;
  name: string;
  email: string;
  role: 'super_admin' | 'admin_dpd';
  dpd_id?: number;
  dpd?: Dpd;
}

export interface Dpd {
  id: number;
  nama_kabupaten: string;
  slug: string;
  sk_dpd?: string;
  alamat?: string;
  telepon?: string;
  email?: string;
  struktur_organisasi?: any;
  bagan_pengurus?: string;
  logo?: string;
  status: 'aktif' | 'nonaktif';
  created_at?: string;
  updated_at?: string;
}

export interface Kategori {
  id: number;
  nama: string;
  slug: string;
  deskripsi?: string;
  beritas_count?: number;
}

export interface Berita {
  id: number;
  judul: string;
  slug: string;
  excerpt?: string;
  konten?: string;
  gambar?: string;
  kategori_id?: number;
  kategori?: Kategori;
  author_id?: number;
  author?: User;
  dpd_id?: number;
  dpd?: Dpd;
  status: 'draft' | 'pending' | 'published';
  viewed: number;
  meta_title?: string;
  meta_description?: string;
  created_at?: string;
  updated_at?: string;
  komentars?: Komentar[];
}

export interface Galeri {
  id: number;
  judul: string;
  slug: string;
  deskripsi?: string;
  gambar: string;
  tanggal?: string;
  author_id?: number;
  author?: User;
  status: 'draft' | 'published';
  created_at?: string;
}

export interface Kabupaten {
  id: number;
  nama_kabupaten: string;
  slug: string;
}

export interface TataJumat {
  id: number;
  dpd_id: number;
  dpd?: Dpd;
  kabupaten_id?: number;
  kabupaten?: Kabupaten;
  tanggal_masehi: string;
  tanggal_hijriyah?: string;
  file?: string;
  file_type?: 'image' | 'document' | 'text';
  text_content?: string;
  status: 'draft' | 'pending' | 'published';
  created_at?: string;
}

export interface Lembaga {
  id: number;
  nama: string;
  slug: string;
  deskripsi?: string;
  logo?: string;
  status: 'aktif' | 'nonaktif';
}

export interface Komentar {
  id: number;
  berita_id: number;
  nama: string;
  email: string;
  komentar: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at?: string;
}

export interface Donasi {
  id: number;
  nama: string;
  email: string;
  telepon?: string;
  nominal: number;
  program: string;
  pesan?: string;
  status: 'pending' | 'confirmed';
  created_at?: string;
}

export interface Profil {
  id: number;
  jenis: string;
  judul?: string;
  konten?: string;
  file?: string;
  updated_at?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  data: T;
}

export interface PaginatedResponse<T> {
  success: boolean;
  data: {
    data: T[];
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    next_page_url?: string;
    prev_page_url?: string;
  };
}

export interface AuthResponse {
  success: boolean;
  message: string;
  data: {
    user: User;
    token: string;
  };
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface DashboardStats {
  total_berita: number;
  total_galeri: number;
  total_dpd: number;
  total_donasi: number;
  total_komentar: number;
}
