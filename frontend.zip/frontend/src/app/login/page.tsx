'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Building as Mosque, Eye, EyeOff, LogIn } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      
      const response = await fetch(`${API_URL}/admin/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
      
      const data = await response.json();
      const token = data?.data?.token;
      const user = data?.data?.user;

      if (response.ok && token && user) {
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user));

        const role = (user.role || '').toString().toLowerCase();
        if (['super_admin', 'super-admin', 'superadmin'].includes(role)) {
          router.push('/super-admin/dashboard');
        } else if (role === 'admin_dpd' || role === 'dpd_admin') {
          router.push('/dpd-admin/dashboard');
        } else {
          router.push('/login');
        }
      } else {
        setError(data?.message || data?.error || 'Email atau password salah');
      }
    } catch (err) {
      // Demo mode fallback
      if (email === 'bkprmi.aceh@gmail.com' && password === 'Acehmulia12') {
        localStorage.setItem('token', 'demo-token');
        localStorage.setItem('user', JSON.stringify({ 
          name: 'Super Admin', 
          email, 
          role: 'super_admin' 
        }));
        router.push('/super-admin/dashboard');
      } else if (email.includes('@') && password.length >= 6) {
        localStorage.setItem('token', 'demo-token-dpd');
        localStorage.setItem('user', JSON.stringify({ 
          name: 'Admin DPD', 
          email, 
          role: 'admin_dpd',
          dpd_id: 1
        }));
        router.push('/dpd-admin/dashboard');
      } else {
        setError('Email atau password salah');
      }
    } finally {
      setLoading(false);
    }
  };

  // Show loading initially to prevent flash
  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/20 to-secondary/20 p-4">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-500">Memuat...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/20 to-secondary/20 p-4">
      <div className="w-full max-w-md">
        <div className="card p-8">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center mx-auto mb-4">
              <Mosque className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-2xl font-heading font-bold text-slate-900">BKPRMI Aceh</h1>
            <p className="text-sm text-slate-500 mt-1">Portal Admin</p>
          </div>

          {/* Error Message */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-600 text-sm">
              {error}
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input"
                placeholder="email@contoh.com"
                required
              />
            </div>
            <div>
              <label className="label">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="input pr-12"
                  placeholder="Masukkan password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>
            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              {loading ? (
                <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
              ) : (
                <>
                  <LogIn className="w-5 h-5" />
                  Masuk
                </>
              )}
            </button>
          </form>

          {/* Info */}
          <div className="mt-6 pt-6 border-t border-slate-100 text-center">
            <p className="text-xs text-slate-400">
              Super Admin: bkprmi.aceh@gmail.com<br />
              Password: Acehmulia12
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

