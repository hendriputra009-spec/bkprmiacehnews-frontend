
import { Metadata } from 'next';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import Link from 'next/link';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Globe, 
  ArrowLeft, 
  FileText, 
  Users, 
  Building,
  Calendar,
  Image as ImageIcon
} from 'lucide-react';

export const dynamic = 'force-dynamic';

const getBaseUrl = () => {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
    return new URL(apiUrl).origin;
  } catch {
    return 'http://localhost:8000';
  }
};

const getStorageUrl = (path?: string) => {
  if (!path) return null;
  return `${getBaseUrl()}/storage/${path}`;
};

interface Props {
  params: { slug: string };
}

async function getDpd(slug: string) {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
  
  try {
    const res = await fetch(`${baseUrl}/dpd/${encodeURIComponent(slug)}`, { 
      cache: 'no-store' 
    });
    
    if (!res.ok) {
      return null;
    }
    
    const data = await res.json();
    return data.data || null;
  } catch (error) {
    console.error('Error fetching DPD:', error);
    return null;
  }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const dpd = await getDpd(params.slug);
  
  if (!dpd) {
    return {
      title: 'DPD Tidak Ditemukan - BKPRMI Aceh',
    };
  }

  return {
    title: `${dpd.nama_kabupaten} - DPD BKPRMI Aceh`,
    description: `Informasi lengkap tentang DPD BKPRMI ${dpd.nama_kabupaten}. Hubungi kami di ${dpd.alamat || ''} atau melalui telepon ${dpd.telepon || ''}.`,
    keywords: `BKPRMI, ${dpd.nama_kabupaten}, DPD, Organisasi Masjid, Aceh`,
    openGraph: {
      title: `${dpd.nama_kabupaten} - DPD BKPRMI Aceh`,
      description: `Informasi lengkap tentang DPD BKPRMI ${dpd.nama_kabupaten}`,
      type: 'website',
      locale: 'id_ID',
      siteName: 'BKPRMI Aceh',
    },
    twitter: {
      card: 'summary_large_image',
      title: `${dpd.nama_kabupaten} - DPD BKPRMI Aceh`,
      description: `Informasi lengkap tentang DPD BKPRMI ${dpd.nama_kabupaten}`,
    },
  };
}

export default async function DpdDetailPage({ params }: Props) {
  const dpd = await getDpd(params.slug);

  if (!dpd) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-semibold mb-2">Halaman tidak ditemukan</h1>
            <p className="text-slate-500 mb-4">DPD yang Anda cari tidak tersedia.</p>
            <Link href="/dpd" className="btn btn-primary">
              Kembali ke daftar DPD
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const logoUrl = getStorageUrl(dpd.logo);
  const sekretariatUrl = getStorageUrl(dpd.foto_sekretariat);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />
      
      {/* Breadcrumb */}
      <div className="bg-white border-b border-slate-200">
        <div className="container-page py-3">
          <nav className="flex items-center gap-2 text-sm">
            <Link href="/" className="text-slate-500 hover:text-primary transition-colors">
              Beranda
            </Link>
            <ArrowLeft className="w-4 h-4 text-slate-400 rotate-90" />
            <Link href="/dpd" className="text-slate-500 hover:text-primary transition-colors">
              DPD
            </Link>
            <ArrowLeft className="w-4 h-4 text-slate-400 rotate-90" />
            <span className="text-slate-900 font-medium">{dpd.nama_kabupaten}</span>
          </nav>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-primary-700 to-primary-900 text-white py-12">
        <div className="container-page">
          <div className="flex flex-col md:flex-row items-center gap-6">
            {/* Logo */}
            <div className="w-24 h-24 md:w-32 md:h-32 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center overflow-hidden border-2 border-white/20 flex-shrink-0">
              {logoUrl ? (
                <img 
                  src={logoUrl} 
                  alt={`Logo DPD ${dpd.nama_kabupaten}`}
                  className="w-full h-full object-cover"
                />
              ) : (
                <Building className="w-12 h-12 md:w-16 md:h-16 text-white/50" />
              )}
            </div>
            
            <div className="text-center md:text-left">
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-heading font-bold mb-2">
                DPD BKPRMI {dpd.nama_kabupaten}
              </h1>
              <p className="text-primary-100 text-lg">
                Dewan Pimpinan Daerah BKPRMI Aceh
              </p>
              {dpd.sk_dpd && (
                <div className="flex items-center justify-center md:justify-start gap-2 mt-3 text-primary-200">
                  <FileText className="w-4 h-4" />
                  <span className="text-sm">SK: {dpd.sk_dpd}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      <main className="flex-1 py-8">
        <div className="container-page">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Secretariat Photo */}
              {sekretariatUrl && (
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                  <div className="p-4 border-b border-slate-100">
                    <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                      <Building className="w-5 h-5 text-primary" />
                      Sekretariat
                    </h2>
                  </div>
                  <div className="aspect-video">
                    <img 
                      src={sekretariatUrl} 
                      alt={`Sekretariat DPD ${dpd.nama_kabupaten}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              )}

              {/* Profile / About */}
              {dpd.profil_mpd_bkprmi && (
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                  <div className="p-4 border-b border-slate-100">
                    <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                      <FileText className="w-5 h-5 text-primary" />
                      Profil DPD
                    </h2>
                  </div>
                  <div className="p-6">
                    <div 
                      className="prose prose-slate max-w-none"
                      dangerouslySetInnerHTML={{ __html: dpd.profil_mpd_bkprmi }}
                    />
                  </div>
                </div>
              )}

              {/* Structure / Organization */}
              {dpd.struktur_organisasi && (
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                  <div className="p-4 border-b border-slate-100">
                    <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                      <Users className="w-5 h-5 text-primary" />
                      Struktur Organisasi
                    </h2>
                  </div>
                  <div className="p-6">
                    <div 
                      className="prose prose-slate max-w-none"
                      dangerouslySetInnerHTML={{ __html: dpd.struktur_organisasi }}
                    />
                  </div>
                </div>
              )}

              {/* Bagan Pengurus */}
              {dpd.bagan_pengurus && (
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                  <div className="p-4 border-b border-slate-100">
                    <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                      <Globe className="w-5 h-5 text-primary" />
                      Bagan Pengurus
                    </h2>
                  </div>
                  <div className="p-6">
                    {getStorageUrl(dpd.bagan_pengurus) ? (
                      <img 
                        src={getStorageUrl(dpd.bagan_pengurus)!} 
                        alt="Bagan Pengurus DPD"
                        className="w-full h-auto rounded-xl"
                      />
                    ) : (
                      <div 
                        className="prose prose-slate max-w-none"
                        dangerouslySetInnerHTML={{ __html: dpd.bagan_pengurus }}
                      />
                    )}
                  </div>
                </div>
              )}

              {/* No Content Fallback */}
              {!dpd.profil_mpd_bkprmi && !dpd.struktur_organisasi && !dpd.bagan_pengurus && !sekretariatUrl && (
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 text-center">
                  <ImageIcon className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">
                    Informasi Sedang Dikembangkan
                  </h3>
                  <p className="text-slate-500">
                    Profil dan struktur organisasi DPD {dpd.nama_kabupaten} akan segera dilengkapi.
                  </p>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Contact Information */}
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div className="p-4 border-b border-slate-100">
                  <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <Phone className="w-5 h-5 text-primary" />
                    Kontak
                  </h2>
                </div>
                <div className="p-6 space-y-4">
                  {dpd.alamat && (
                    <div className="flex items-start gap-3">
                      <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium text-slate-900">Alamat</p>
                        <p className="text-slate-600 text-sm">{dpd.alamat}</p>
                      </div>
                    </div>
                  )}
                  
                  {dpd.telepon && (
                    <div className="flex items-center gap-3">
                      <Phone className="w-5 h-5 text-primary flex-shrink-0" />
                      <div>
                        <p className="font-medium text-slate-900">Telepon</p>
                        <a 
                          href={`tel:${dpd.telepon}`} 
                          className="text-slate-600 text-sm hover:text-primary transition-colors"
                        >
                          {dpd.telepon}
                        </a>
                      </div>
                    </div>
                  )}
                  
                  {dpd.email && (
                    <div className="flex items-center gap-3">
                      <Mail className="w-5 h-5 text-primary flex-shrink-0" />
                      <div>
                        <p className="font-medium text-slate-900">Email</p>
                        <a 
                          href={`mailto:${dpd.email}`} 
                          className="text-slate-600 text-sm hover:text-primary transition-colors"
                        >
                          {dpd.email}
                        </a>
                      </div>
                    </div>
                  )}

                  {!dpd.alamat && !dpd.telepon && !dpd.email && (
                    <p className="text-slate-500 text-sm text-center py-4">
                      Informasi kontak belum tersedia
                    </p>
                  )}
                </div>
              </div>

              {/* SK DPD */}
              {dpd.sk_dpd && (
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                  <div className="p-4 border-b border-slate-100">
                    <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                      <FileText className="w-5 h-5 text-primary" />
                      SK DPD
                    </h2>
                  </div>
                  <div className="p-6">
                    <p className="text-slate-600">{dpd.sk_dpd}</p>
                    {dpd.sk_dpd_file && getStorageUrl(dpd.sk_dpd_file) && (
                      <a 
                        href={getStorageUrl(dpd.sk_dpd_file)!}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-outline w-full mt-4"
                      >
                        <FileText className="w-4 h-4 mr-2" />
                        Lihat SK
                      </a>
                    )}
                  </div>
                </div>
              )}

              {/* Quick Links */}
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div className="p-4 border-b border-slate-100">
                  <h2 className="text-lg font-bold text-slate-900">
                    Tautan Cepat
                  </h2>
                </div>
                <div className="p-4 space-y-2">
                  <Link 
                    href="/berita" 
                    className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-50 transition-colors text-slate-600 hover:text-primary"
                  >
                    <Calendar className="w-4 h-4" />
                    <span className="text-sm">Berita {dpd.nama_kabupaten}</span>
                  </Link>
                  <Link 
                    href="/tata-laksana" 
                    className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-50 transition-colors text-slate-600 hover:text-primary"
                  >
                    <FileText className="w-4 h-4" />
                    <span className="text-sm">Tata Laksana</span>
                  </Link>
                  <Link 
                    href="/donasi" 
                    className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-50 transition-colors text-slate-600 hover:text-primary"
                  >
                    <Phone className="w-4 h-4" />
                    <span className="text-sm">Donasi</span>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

