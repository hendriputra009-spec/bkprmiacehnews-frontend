import Link from 'next/link';
import { Metadata } from 'next';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import ShareButtons from '@/components/news/ShareButtons';
import { ArrowLeft, Clock, Calendar, ChevronRight, Image as ImageIcon } from 'lucide-react';

export const dynamic = 'force-dynamic';

const getBaseUrl = () => {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
    return new URL(apiUrl).origin;
  } catch {
    return 'http://localhost:8000';
  }
};

const getStorageUrl = (path?: string) => {
  if (!path) return '/storage/placeholder/berita-placeholder.svg';
  return `${getBaseUrl()}/storage/${path}`;
};

// Function to generate metadata for SEO
export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const { slug } = params;
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

  try {
    const res = await fetch(
      `${baseUrl}/berita/${encodeURIComponent(slug)}`,
      { cache: 'no-store' }
    );

    if (!res.ok) {
      return {
        title: 'Berita Tidak Ditemukan - BKPRMI Aceh',
      };
    }

    const payload = await res.json();
    const berita = payload?.data?.berita;

    if (!berita) {
      return {
        title: 'Berita Tidak Ditemukan - BKPRMI Aceh',
      };
    }

    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://bkpmriaceh.org';
    const articleUrl = `${siteUrl}/berita/${berita.slug}`;
    const imageUrl = berita.gambar 
      ? `${getBaseUrl()}/storage/${berita.gambar}`
      : `${siteUrl}/og-image.jpg`;

    return {
      title: `${berita.judul} - BKPRMI Aceh`,
      description: berita.excerpt || berita.judul,
      keywords: [berita.kategori?.nama || '', 'BKPRMI', 'Aceh', 'berita'].filter(Boolean),
      authors: [{ name: 'BKPRMI Aceh' }],
      openGraph: {
        title: berita.judul,
        description: berita.excerpt || berita.judul,
        url: articleUrl,
        type: 'article',
        publishedTime: berita.created_at,
        modifiedTime: berita.updated_at,
        authors: ['BKPRMI Aceh'],
        section: berita.kategori?.nama || 'Berita',
        tags: [berita.kategori?.nama || 'BKPRMI'].filter(Boolean),
        images: [
          {
            url: imageUrl,
            width: 1200,
            height: 630,
            alt: berita.judul,
          },
        ],
        locale: 'id_ID',
        siteName: 'BKPRMI Aceh',
      },
      twitter: {
        card: 'summary_large_image',
        title: berita.judul,
        description: berita.excerpt || berita.judul,
        images: [imageUrl],
        creator: '@bkprmi_aceh',
      },
      alternates: {
        canonical: articleUrl,
      },
    };
  } catch (error) {
    console.error('Error generating metadata:', error);
    return {
      title: 'BKPRMI Aceh',
    };
  }
}

export default async function BeritaDetailPage({
  params,
  searchParams,
}: {
  params: { slug: string };
  searchParams: { preview?: string };
}) {
  const { slug } = params;
  const preview = searchParams.preview === '1';
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://bkpmriaceh.org';

  const res = await fetch(
    `${baseUrl}/berita/${encodeURIComponent(slug)}${preview ? '?preview=1' : ''}`,
    { cache: 'no-store' }
  );

  if (!res.ok) {
    return (
      <div className="min-h-screen flex flex-col bg-slate-50">
        <Navbar />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center px-4">
            <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-4xl">📰</span>
            </div>
            <h1 className="text-2xl font-bold text-slate-900 mb-2">Halaman tidak ditemukan</h1>
            <p className="text-slate-500 mb-6">Berita yang Anda cari tidak tersedia.</p>
            <Link href="/berita" className="btn btn-primary">
              Kembali ke daftar berita
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const payload = await res.json();
  const berita = payload?.data?.berita;

  if (!berita) {
    return (
      <div className="min-h-screen flex flex-col bg-slate-50">
        <Navbar />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center px-4">
            <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-4xl">📰</span>
            </div>
            <h1 className="text-2xl font-bold text-slate-900 mb-2">Berita tidak ditemukan</h1>
            <p className="text-slate-500 mb-6">Data berita tidak tersedia atau rusak.</p>
            <Link href="/berita" className="btn btn-primary">
              Kembali ke daftar berita
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  // Format date
  const formattedDate = new Date(berita.created_at).toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  // Generate JSON-LD structured data
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'NewsArticle',
    headline: berita.judul,
    description: berita.excerpt || berita.judul,
    image: berita.gambar ? `${getBaseUrl()}/storage/${berita.gambar}` : `${siteUrl}/og-image.jpg`,
    datePublished: berita.created_at,
    dateModified: berita.updated_at || berita.created_at,
    author: {
      '@type': 'Organization',
      name: 'BKPRMI Aceh',
      url: siteUrl,
    },
    publisher: {
      '@type': 'Organization',
      name: 'BKPRMI Aceh',
      logo: {
        '@type': 'ImageObject',
        url: `${siteUrl}/logo.png`,
      },
    },
    mainEntityOfPage: {
      '@type': 'WebPage',
      '@id': `${siteUrl}/berita/${berita.slug}`,
    },
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <div className="min-h-screen flex flex-col bg-slate-50">
        <Navbar />
        
        {/* Breadcrumb */}
        <div className="bg-white border-b border-slate-200">
          <div className="container-page py-3">
            <nav className="flex items-center gap-2 text-sm">
              <Link href="/" className="text-slate-500 hover:text-primary transition-colors">
                Beranda
              </Link>
              <ChevronRight className="w-4 h-4 text-slate-400" />
              <Link href="/berita" className="text-slate-500 hover:text-primary transition-colors">
                Berita
              </Link>
              <ChevronRight className="w-4 h-4 text-slate-400" />
              <span className="text-slate-900 font-medium truncate max-w-xs">
                {berita.judul}
              </span>
            </nav>
          </div>
        </div>

        <main className="flex-1 py-8">
          <div className="container-page">
            <article className="max-w-4xl mx-auto">
              {/* Back Button */}
              <Link 
                href="/berita" 
                className="inline-flex items-center gap-2 text-slate-600 hover:text-primary transition-colors mb-6"
              >
                <ArrowLeft className="w-4 h-4" /> 
                Kembali ke Berita
              </Link>

              {/* Article Header */}
              <header className="mb-8">
                {/* Category & Date */}
                <div className="flex flex-wrap items-center gap-3 mb-4">
                  {berita.kategori && (
                    <span className="bg-primary text-white text-sm font-semibold px-4 py-1.5 rounded-full">
                      {berita.kategori.nama}
                    </span>
                  )}
                  <div className="flex items-center gap-4 text-sm text-slate-500">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-4 h-4" />
                      {formattedDate}
                    </span>
                  </div>
                </div>

                {/* Title */}
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-heading font-bold text-slate-900 leading-tight mb-6">
                  {berita.judul}
                </h1>

                {/* Excerpt */}
                {berita.excerpt && (
                  <p className="text-xl text-slate-600 leading-relaxed border-l-4 border-primary pl-6 py-2">
                    {berita.excerpt}
                  </p>
                )}
              </header>

              {/* Featured Image */}
              <div className="relative w-full bg-slate-100 rounded-2xl overflow-hidden mb-8 shadow-lg">
                {berita.gambar ? (
                  <img
                    src={getStorageUrl(berita.gambar)}
                    alt={berita.judul}
                    className="w-full h-auto object-contain"
                  />
                ) : (
                  <div className="w-full aspect-video bg-primary/10 flex items-center justify-center">
                    <ImageIcon className="w-24 h-24 text-primary/30" />
                  </div>
                )}
              </div>

              {/* Share Buttons */}
              <div className="bg-white rounded-xl border border-slate-200 p-5 mb-8">
                <ShareButtons 
                  title={berita.judul}
                  description={berita.excerpt || ''}
                  url={`${siteUrl}/berita/${berita.slug}`}
                  image={berita.gambar ? `${getBaseUrl()}/storage/${berita.gambar}` : undefined}
                />
              </div>

              {/* Article Content */}
              <div 
                className="prose prose-lg max-w-none prose-headings:font-heading prose-headings:font-bold prose-h1:text-3xl prose-h2:text-2xl prose-h3:text-xl prose-p:text-slate-700 prose-p:leading-relaxed prose-a:text-primary prose-a:no-underline hover:prose-a:underline prose-img:rounded-xl prose-img:shadow-lg prose-blockquote:border-l-primary prose-blockquote:bg-slate-50 prose-blockquote:py-2 prose-blockquote:px-4 prose-blockquote:not-italic prose-li:marker:text-primary"
                dangerouslySetInnerHTML={{ __html: berita.konten }} 
              />

              {/* Tags */}
              {berita.kategori && (
                <div className="mt-10 pt-8 border-t border-slate-200">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-medium text-slate-600">Kategori:</span>
                    <Link 
                      href={`/berita?kategori=${berita.kategori.slug}`}
                      className="bg-slate-100 text-slate-700 hover:bg-primary hover:text-white text-sm px-4 py-1.5 rounded-full transition-colors"
                    >
                      {berita.kategori.nama}
                    </Link>
                  </div>
                </div>
              )}
            </article>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}

