import type { Metadata } from 'next';
import './globals.css';
import { Inter, Poppins } from 'next/font/google';

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
});

const poppins = Poppins({
  weight: ['400', '500', '600', '700', '800'],
  subsets: ['latin'],
  variable: '--font-poppins',
});

export const metadata: Metadata = {
  title: 'BKPRMI Aceh - Badan Komunikasi Pengarusutamaan Remaja Masjid Indonesia',
  description: 'Portal berita resmi BKPRMI Aceh. Membangun generasi muda Islam yang berakhlakul karimah.',
  keywords: 'BKPRMI, Aceh, Remaja Masjid, Islam, Organisasi',
  authors: [{ name: 'BKPRMI Aceh' }],
  openGraph: {
    title: 'BKPRMI Aceh',
    description: 'Portal berita resmi BKPRMI Aceh',
    type: 'website',
    locale: 'id_ID',
    siteName: 'BKPRMI Aceh',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'BKPRMI Aceh',
    description: 'Portal berita resmi BKPRMI Aceh',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id" className={`${inter.variable} ${poppins.variable}`}>
      <body className="min-h-screen bg-background font-sans">
        {children}
      </body>
    </html>
  );
}
