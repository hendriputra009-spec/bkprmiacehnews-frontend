import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import Link from 'next/link';
import { MapPin, Phone, Mail, FileText, AlertCircle } from 'lucide-react';

export const dynamic = 'force-dynamic';

async function getData() {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
  
  try {
    const res = await fetch(`${baseUrl}/dpd`, { cache: 'no-store' });
    const data = res.ok ? await res.json() : { data: [] };
    return data.data || [];
  } catch (error) {
    console.error('Error fetching DPD:', error);
    return [];
  }
}

export default async function DpdPage() {
  const dpds = await getData();

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 py-12 bg-background">
        <div className="container-page">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-heading font-bold text-slate-900 mb-4">
              DPD BKPRMI Aceh
            </h1>
            <p className="text-slate-500">
              Daftar Dewan Pimpinan Daerah (DPD) BKPRMI di 23 Kabupaten/Kota seluruh Aceh
            </p>
          </div>

          {/* DPD Grid */}
          {dpds.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {dpds.map((dpd: any) => (
                <Link 
                  key={dpd.id} 
                  href={`/dpd/${dpd.slug}`}
                  className="card hover:shadow-lg transition-all duration-300"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 rounded-xl bg-primary text-white flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-7 h-7" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-lg font-semibold text-slate-900 mb-1">
                        {dpd.nama_kabupaten}
                      </h3>
                      {dpd.sk_dpd && (
                        <div className="flex items-center gap-1 text-sm text-slate-500 mb-2">
                          <FileText className="w-4 h-4" />
                          <span className="truncate">SK: {dpd.sk_dpd}</span>
                        </div>
                      )}
                      <div className="flex flex-wrap gap-3 text-sm">
                        {dpd.telepon && (
                          <span className="text-slate-500 flex items-center gap-1">
                            <Phone className="w-3 h-3" /> {dpd.telepon}
                          </span>
                        )}
                        {dpd.email && (
                          <span className="text-slate-500 flex items-center gap-1">
                            <Mail className="w-3 h-3" /> {dpd.email}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-white rounded-xl">
              <AlertCircle className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                Data DPD Belum Tersedia
              </h3>
              <p className="text-slate-500">
                Informasi DPD akan segera dilengkapi. Silakan hubungi kami untuk informasi lebih lanjut.
              </p>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}

