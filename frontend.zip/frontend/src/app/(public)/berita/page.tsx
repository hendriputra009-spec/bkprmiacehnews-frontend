import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import Link from 'next/link';
import { Search, Filter, Image as ImageIcon, AlertCircle, ChevronRight, Clock } from 'lucide-react';

export const dynamic = 'force-dynamic';

const getBaseUrl = () => {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
    return new URL(apiUrl).origin;
  } catch {
    return 'http://localhost:8000';
  }
};

const getStorageUrl = (path?: string) => {
  if (!path) return `${getBaseUrl()}/storage/placeholder/berita-placeholder.svg`;
  return `${getBaseUrl()}/storage/${path}`;
};

async function getData(search: string = '', kategori: string = '') {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

  try {
    let url = `${baseUrl}/berita?limit=12`;
    if (search) url += `&search=${encodeURIComponent(search)}`;
    if (kategori) url += `&kategori=${encodeURIComponent(kategori)}`;
    
    const [beritaRes, kategoriRes] = await Promise.all([
      fetch(url, { cache: 'no-store' }),
      fetch(`${baseUrl}/kategori`, { cache: 'no-store' })
    ]);
    
    const berita = beritaRes.ok ? await beritaRes.json() : { data: { data: [] } };
    const kategoris = kategoriRes.ok ? await kategoriRes.json() : { kategoris: [] };

    return {
      berita: berita.data?.data ?? [],
      kategoris: kategoris.kategoris ?? [],
      search,
      kategori
    };
  } catch (error) {
    console.error('Error fetching data:', error);
    return { berita: [], kategoris: [], search: '', kategori: '' };
  }
}

function formatDate(dateString: string) {
  const date = new Date(dateString);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - date.getTime());
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) return 'Hari ini';
  if (diffDays === 1) return 'Kemarin';
  if (diffDays < 7) return `${diffDays} hari lalu`;
  
  return date.toLocaleDateString('id-ID', { 
    day: 'numeric', 
    month: 'long', 
    year: 'numeric' 
  });
}

// News Card Component
function NewsCard({ item }: { item: any }) {
  return (
    <Link 
      href={`/berita/${item.slug}`}
      className="group"
    >
      <article className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 h-full flex flex-col">
        {/* Image Container - Show full image without cropping */}
        <div className="relative w-full aspect-[16/10] bg-slate-100 overflow-hidden">
          {item.gambar ? (
            <img 
              src={getStorageUrl(item.gambar)} 
              alt={item.judul}
              className="w-full h-full object-contain bg-white group-hover:scale-105 transition-transform duration-500"
            />
          ) : (
            <div className="w-full h-full bg-primary/10 flex items-center justify-center">
              <ImageIcon className="w-12 h-12 text-primary/30" />
            </div>
          )}
        </div>
        
        {/* Content */}
        <div className="p-5 flex-1 flex flex-col">
          <div className="flex items-center gap-2 mb-3">
            {item.kategori && (
              <span className="bg-primary/10 text-primary text-xs font-semibold px-2 py-0.5 rounded-full">
                {item.kategori.nama}
              </span>
            )}
          </div>
          <h3 className="text-base font-bold text-slate-900 group-hover:text-primary transition-colors mb-2 line-clamp-2 flex-1">
            {item.judul}
          </h3>
          <p className="text-sm text-slate-500 line-clamp-2 mb-3">
            {item.excerpt || 'Klik untuk membaca selengkapnya...'}
          </p>
          <span className="flex items-center gap-1 text-xs text-slate-400 mt-auto">
            <Clock className="w-3 h-3" />
            {formatDate(item.created_at)}
          </span>
        </div>
      </article>
    </Link>
  );
}

// Featured News Card Component
function FeaturedNewsCard({ item, isMain = false }: { item: any; isMain?: boolean }) {
  return (
    <Link 
      href={`/berita/${item.slug}`}
      className="group"
    >
      <article className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 h-full">
        {/* Image Container - Show full image without cropping */}
        <div className={`relative w-full ${isMain ? 'aspect-[16/9]' : 'aspect-video'} bg-slate-100 overflow-hidden`}>
          {item.gambar ? (
            <img 
              src={getStorageUrl(item.gambar)} 
              alt={item.judul}
              className="w-full h-full object-contain bg-white group-hover:scale-105 transition-transform duration-500"
            />
          ) : (
            <div className="w-full h-full bg-primary/10 flex items-center justify-center">
              <ImageIcon className="w-16 h-16 text-primary/30" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          <div className="absolute top-4 left-4">
            {item.kategori && (
              <span className="bg-primary text-white text-xs font-semibold px-3 py-1 rounded-full">
                {item.kategori.nama}
              </span>
            )}
          </div>
        </div>
        
        <div className="p-6">
          <h3 className={`font-bold text-slate-900 group-hover:text-primary transition-colors mb-3 ${isMain ? 'text-xl lg:text-2xl' : 'text-lg'} line-clamp-2`}>
            {item.judul}
          </h3>
          <p className="text-slate-600 mb-4 line-clamp-3">
            {item.excerpt || 'Klik untuk membaca selengkapnya...'}
          </p>
          <div className="flex items-center gap-4 text-sm text-slate-500">
            <span className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              {formatDate(item.created_at)}
            </span>
          </div>
        </div>
      </article>
    </Link>
  );
}

// Secondary Featured Card (horizontal layout)
function SecondaryFeaturedCard({ item }: { item: any }) {
  return (
    <Link 
      href={`/berita/${item.slug}`}
      className="group"
    >
      <article className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 h-full">
        <div className="flex flex-col sm:flex-row h-full">
          {/* Image Container - Show full image without cropping */}
          <div className="sm:w-2/5 aspect-video sm:aspect-auto relative bg-slate-100 overflow-hidden">
            {item.gambar ? (
              <img 
                src={getStorageUrl(item.gambar)} 
                alt={item.judul}
                className="w-full h-full object-contain bg-white group-hover:scale-105 transition-transform duration-500"
              />
            ) : (
              <div className="w-full h-full bg-primary/10 flex items-center justify-center">
                <ImageIcon className="w-10 h-10 text-primary/30" />
              </div>
            )}
          </div>
          <div className="sm:w-3/5 p-5">
            <div className="flex items-center gap-2 mb-2">
              {item.kategori && (
                <span className="bg-primary/10 text-primary text-xs font-semibold px-2 py-0.5 rounded-full">
                  {item.kategori.nama}
                </span>
              )}
            </div>
            <h3 className="text-lg font-bold text-slate-900 group-hover:text-primary transition-colors mb-2 line-clamp-2">
              {item.judul}
            </h3>
            <p className="text-sm text-slate-500 line-clamp-2">
              {item.excerpt || 'Klik untuk membaca selengkapnya...'}
            </p>
            <span className="flex items-center gap-1 text-xs text-slate-400 mt-3">
              <Clock className="w-3 h-3" />
              {formatDate(item.created_at)}
            </span>
          </div>
        </div>
      </article>
    </Link>
  );
}

export default async function BeritaPage({
  searchParams,
}: {
  searchParams: { search?: string; kategori?: string };
}) {
  const search = searchParams?.search || '';
  const kategori = searchParams?.kategori || '';
  const { berita, kategoris } = await getData(search, kategori);

  // Check if this is a filtered view
  const isFiltered = search || kategori;

  // Get featured news (first 3) and regular news - only for non-filtered view
  const featuredNews = !isFiltered ? berita.slice(0, 3) : [];
  const regularNews = !isFiltered ? berita.slice(3) : berita;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />
      
      {/* Breadcrumb */}
      <div className="bg-white border-b border-slate-200">
        <div className="container-page py-3">
          <nav className="flex items-center gap-2 text-sm">
            <Link href="/" className="text-slate-500 hover:text-primary transition-colors">
              Beranda
            </Link>
            <ChevronRight className="w-4 h-4 text-slate-400" />
            <span className="text-slate-900 font-medium">Berita</span>
          </nav>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-primary-700 to-primary-900 text-white py-12">
        <div className="container-page">
          <h1 className="text-3xl lg:text-4xl font-heading font-bold mb-3">
            {isFiltered ? 'Hasil Pencarian' : 'Berita Terbaru'}
          </h1>
          <p className="text-primary-100 text-lg max-w-2xl">
            {isFiltered 
              ? `Ditemukan ${berita.length} berita sesuai filter Anda`
              : 'Informasi terkini dan terbaru dari BKPRMI Aceh'
            }
          </p>
        </div>
      </div>
      
      <main className="flex-1 py-8">
        <div className="container-page">
          {/* Search & Filter */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 mb-8">
            <form className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  name="search"
                  defaultValue={search}
                  placeholder="Cari berita..."
                  className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                />
              </div>
              <select 
                name="kategori" 
                defaultValue={kategori}
                className="md:w-56 px-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all bg-white"
              >
                <option value="">Semua Kategori</option>
                {kategoris.map((kat: any) => (
                  <option key={kat.id} value={kat.slug}>{kat.nama}</option>
                ))}
              </select>
              <button 
                type="submit" 
                className="btn btn-primary px-8 py-3"
              >
                <Filter className="w-5 h-5 mr-2" />
                Cari
              </button>
            </form>
          </div>

          {berita.length > 0 ? (
            <>
              {/* Featured News Section - Only show when not filtered */}
              {featuredNews.length > 0 && !isFiltered && (
                <section className="mb-10">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-heading font-bold text-slate-900 flex items-center gap-2">
                      <span className="w-1 h-6 bg-primary rounded-full"></span>
                      Berita Utama
                    </h2>
                  </div>
                  
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Main Featured */}
                    <FeaturedNewsCard item={featuredNews[0]} isMain={true} />

                    {/* Secondary Featured */}
                    {featuredNews.slice(1).map((item: any) => (
                      <SecondaryFeaturedCard key={item.id} item={item} />
                    ))}
                  </div>
                </section>
              )}

              {/* News Grid - Shows all news when filtered */}
              <section>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-heading font-bold text-slate-900 flex items-center gap-2">
                    <span className="w-1 h-6 bg-primary rounded-full"></span>
                    {isFiltered ? 'Berita Terbaru' : 'Berita Lainnya'}
                  </h2>
                  <span className="text-sm text-slate-500">
                    {berita.length} berita ditemukan
                  </span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {regularNews.map((item: any) => (
                    <NewsCard key={item.id} item={item} />
                  ))}
                </div>
              </section>
            </>
          ) : (
            <div className="text-center py-20 bg-white rounded-2xl border border-slate-200">
              <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <AlertCircle className="w-10 h-10 text-slate-400" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                Tidak Ada Berita
              </h3>
              <p className="text-slate-500 mb-6 max-w-md mx-auto">
                {isFiltered 
                  ? 'Tidak ada berita yang sesuai dengan filter yang Anda pilih. Coba gunakan kata kunci lain atau pilih kategori berbeda.'
                  : 'Belum ada berita tersedia. Berita terbaru akan segera hadir.'
                }
              </p>
              <Link href="/berita" className="btn btn-primary">
                Lihat Semua Berita
              </Link>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}

