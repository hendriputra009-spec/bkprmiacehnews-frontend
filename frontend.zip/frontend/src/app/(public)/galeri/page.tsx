import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import Link from 'next/link';
import { Image as ImageIcon, Calendar, ChevronRight, Grid } from 'lucide-react';

export const dynamic = 'force-dynamic';

const getBaseUrl = () => {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
    return new URL(apiUrl).origin;
  } catch {
    return 'http://localhost:8000';
  }
};

async function getData() {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
  
  try {
    const res = await fetch(`${baseUrl}/galeri?limit=50`, { cache: 'no-store' });
    const data = res.ok ? await res.json() : { data: [] };
    return data.data?.data ?? data.data ?? [];
  } catch (error) {
    console.error('Error fetching galeri:', error);
    return [];
  }
}

function formatDate(dateString: string) {
  const date = new Date(dateString);
  return date.toLocaleDateString('id-ID', { 
    day: 'numeric', 
    month: 'long', 
    year: 'numeric' 
  });
}

function GaleriCard({ item }: { item: any }) {
  const getBaseUrl = () => {
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      return new URL(apiUrl).origin;
    } catch {
      return 'http://localhost:8000';
    }
  };
  
  const imagePath = item.gambar || item.gambar_url || '';
  const imageUrl = imagePath 
    ? `${getBaseUrl()}/storage/${imagePath}`
    : null;

  return (
    <Link 
      href={`/galeri/${item.slug}`}
      className="group block break-inside-avoid"
    >
      <div className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300">
        <div className="relative aspect-[4/3] bg-slate-100">
          {imageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img 
              src={imageUrl}
              alt={item.judul}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <ImageIcon className="w-12 h-12 text-slate-300" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        </div>
        <div className="p-4">
          <h3 className="font-semibold text-slate-900 group-hover:text-primary transition-colors line-clamp-2 mb-2">
            {item.judul}
          </h3>
          {item.tanggal && (
            <p className="text-xs text-slate-500 flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {formatDate(item.tanggal)}
            </p>
          )}
        </div>
      </div>
    </Link>
  );
}

export default async function GaleriPage() {
  const galeris = await getData();

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />
      
      {/* Breadcrumb */}
      <div className="bg-white border-b border-slate-200">
        <div className="container-page py-3">
          <nav className="flex items-center gap-2 text-sm">
            <Link href="/" className="text-slate-500 hover:text-primary transition-colors">
              Beranda
            </Link>
            <ChevronRight className="w-4 h-4 text-slate-400" />
            <span className="text-slate-900 font-medium">Galeri</span>
          </nav>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-primary-700 to-primary-900 text-white py-12">
        <div className="container-page">
          <h1 className="text-3xl lg:text-4xl font-heading font-bold mb-3">
            Galeri Kegiatan
          </h1>
          <p className="text-primary-100 text-lg max-w-2xl">
            Dokumentasi kegiatan dan momen bersejarah dari BKPRMI Aceh
          </p>
        </div>
      </div>
      
      <main className="flex-1 py-8">
        <div className="container-page">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-1 gap-4 mb-8">
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Grid className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">{galeris.length}</p>
                  <p className="text-sm text-slate-500">Total Galeri</p>
                </div>
              </div>
            </div>
          </div>

          {/* Galeri Grid */}
          {galeris.length > 0 ? (
            <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-6 space-y-6">
              {galeris.map((item: any) => (
                <GaleriCard key={item.id} item={item} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-white rounded-2xl border border-slate-200">
              <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <ImageIcon className="w-10 h-10 text-slate-400" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                Galeri Belum Tersedia
              </h3>
              <p className="text-slate-500 mb-6 max-w-md mx-auto">
                Dokumentasi kegiatan akan segera diupload. Silakan tunggu informasi selanjutnya.
              </p>
              <Link href="/" className="btn btn-primary">
                Kembali ke Beranda
              </Link>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}

