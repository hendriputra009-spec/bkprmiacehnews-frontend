import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { FileText, Download, History, Target, Award, BookOpen, AlertCircle } from 'lucide-react';

export const dynamic = 'force-dynamic';

const PROFIL_TYPES = [
  { key: 'sejarah_bkprmi', label: 'Sejarah BKPRMI', icon: History },
  { key: 'sejarah_bkprmi_aceh', label: 'Sejarah BKPRMI Aceh', icon: History },
  { key: 'struktur_organisasi', label: 'Struktur Organisasi', icon: Target },
  { key: 'ad_art', label: 'AD/ART', icon: FileText },
  { key: 'pedoman_organisasi', label: 'Pedoman Organisasi', icon: BookOpen },
  { key: 'pengakuan_negara', label: 'Pengakuan Negara', icon: Award },
];

async function getData() {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
  
  try {
    const res = await fetch(`${baseUrl}/profil`, { cache: 'no-store' });
    const data = res.ok ? await res.json() : { data: [] };
    
    // Transform to object
    const profilMap: Record<string, any> = {};
    (data.data || []).forEach((item: any) => {
      profilMap[item.jenis] = item;
    });
    return profilMap;
  } catch (error) {
    console.error('Error fetching profil:', error);
    return {};
  }
}

export default async function ProfilPage() {
  const profil = await getData();

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 py-12 bg-background">
        <div className="container-page">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-heading font-bold text-slate-900 mb-4">
              Profil Organisasi
            </h1>
            <p className="text-slate-500">
              Informasi lengkap tentang BKPRMI Aceh
            </p>
          </div>

          {/* Profil Sections */}
          <div className="space-y-8">
            {PROFIL_TYPES.map(({ key, label, icon: Icon }) => {
              const data = profil[key];
              return (
                <div key={key} id={key} className="card">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-primary text-white flex items-center justify-center">
                      <Icon className="w-5 h-5" />
                    </div>
                    <h2 className="text-xl font-semibold text-slate-900">{label}</h2>
                  </div>
                  
                  {data?.konten ? (
                    <div 
                      className="prose prose-slate max-w-none"
                      dangerouslySetInnerHTML={{ __html: data.konten }}
                    />
                  ) : data?.file ? (
                    <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                      <p className="text-slate-500">
                        Dokumen tersedia untuk diunduh.
                      </p>
                      <a 
                        href={`/storage/${data.file}`}
                        target="_blank"
                        className="btn btn-primary flex items-center gap-2"
                      >
                        <Download className="w-4 h-4" />
                        Unduh Dokumen
                      </a>
                    </div>
                  ) : (
                    <div className="text-center py-8 bg-slate-50 rounded-lg">
                      <AlertCircle className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                      <p className="text-slate-500">
                        Konten belum tersedia. Silakan hubungi admin untuk informasi lebih lanjut.
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

