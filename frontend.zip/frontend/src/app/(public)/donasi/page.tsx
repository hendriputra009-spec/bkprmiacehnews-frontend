'use client';

import { useState } from 'react';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { Heart, Banknote, Phone, Mail, Send, CheckCircle } from 'lucide-react';

const REKENING_INFO = [
  { bank: 'Bank Aceh', norek: '01001990000060', atasnama: 'BKPRMI Aceh' },
  { bank: 'BSI', norek: '7254214803', atasnama: 'BKPRMI Aceh' },
];

const PROGRAM_DONASI = [
  'Program Pendidikan',
  'Program Dakwah',
  'Program Masjid',
  'Bantuan Sosial',
  'Lainnya',
];

export default function DonasiPage() {
  const [formData, setFormData] = useState({
    nama: '',
    email: '',
    telepon: '',
    nominal: '',
    program: '',
    pesan: '',
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1'}/donasi`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData),
        }
      );
      
      if (response.ok) {
        setSuccess(true);
        setFormData({
          nama: '',
          email: '',
          telepon: '',
          nominal: '',
          program: '',
          pesan: '',
        });
      } else {
        const data = await response.json();
        setError(data.message || 'Terjadi kesalahan. Silakan coba lagi.');
      }
    } catch (err) {
      setError('Terjadi kesalahan koneksi. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1 py-12 bg-background">
          <div className="container-page">
            <div className="max-w-xl mx-auto text-center py-16">
              <div className="w-20 h-20 rounded-full bg-green-100 text-green-600 flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-10 h-10" />
              </div>
              <h1 className="text-2xl font-bold text-slate-900 mb-4">
                Terima Kasih!
              </h1>
              <p className="text-slate-600 mb-8">
                Donasi Anda telah berhasil dicatat. Kami akan menghubungi Anda segera untuk konfirmasi.
              </p>
              <button 
                onClick={() => setSuccess(false)}
                className="btn btn-primary"
              >
                Donasi Lagi
              </button>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 py-12 bg-background">
        <div className="container-page">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Form Donasi */}
            <div className="card">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl bg-primary text-white flex items-center justify-center">
                  <Heart className="w-6 h-6" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-slate-900">Donasi</h1>
                  <p className="text-slate-500">Support program kami</p>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="label">Nama Lengkap</label>
                  <input
                    type="text"
                    required
                    className="input"
                    value={formData.nama}
                    onChange={(e) => setFormData({...formData, nama: e.target.value})}
                    placeholder="Masukkan nama lengkap Anda"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="label">Email</label>
                    <input
                      type="email"
                      required
                      className="input"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      placeholder="email@example.com"
                    />
                  </div>
                  <div>
                    <label className="label">No. Telepon</label>
                    <input
                      type="tel"
                      required
                      className="input"
                      value={formData.telepon}
                      onChange={(e) => setFormData({...formData, telepon: e.target.value})}
                      placeholder="0812xxxxxxx"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="label">Nominal Donasi (Rp)</label>
                    <input
                      type="number"
                      required
                      min="10000"
                      className="input"
                      value={formData.nominal}
                      onChange={(e) => setFormData({...formData, nominal: e.target.value})}
                      placeholder="Contoh: 100000"
                    />
                  </div>
                  <div>
                    <label className="label">Program Donasi</label>
                    <select
                      required
                      className="input"
                      value={formData.program}
                      onChange={(e) => setFormData({...formData, program: e.target.value})}
                    >
                      <option value="">Pilih Program</option>
                      {PROGRAM_DONASI.map((prog) => (
                        <option key={prog} value={prog}>{prog}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="label">Pesan (Opsional)</label>
                  <textarea
                    className="input min-h-[100px]"
                    value={formData.pesan}
                    onChange={(e) => setFormData({...formData, pesan: e.target.value})}
                    placeholder="Tulis pesan untuk kami..."
                  />
                </div>

                {error && (
                  <div className="p-3 bg-red-50 text-red-600 rounded-lg text-sm">
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="btn btn-primary w-full flex items-center justify-center gap-2"
                >
                  {loading ? (
                    'Mengirim...'
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      Kirim Donasi
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Info Rekening */}
            <div className="space-y-6">
              <div className="card">
                <h2 className="text-xl font-bold text-slate-900 mb-4">
                  Rekening Donasi
                </h2>
                <p className="text-slate-500 mb-6">
                  Silakan transfer donasi ke salah satu rekening berikut:
                </p>
                <div className="space-y-4">
                  {REKENING_INFO.map((rek, idx) => (
                    <div key={idx} className="p-4 bg-slate-50 rounded-xl">
                      <div className="flex items-center gap-3 mb-2">
                        <Banknote className="w-6 h-6 text-primary" />
                        <span className="font-semibold text-slate-900">{rek.bank}</span>
                      </div>
                      <p className="text-2xl font-bold text-primary mb-1">
                        {rek.norek}
                      </p>
                      <p className="text-sm text-slate-500">
                        Atas nama: {rek.atasnama}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card">
                <h2 className="text-xl font-bold text-slate-900 mb-4">
                  Hubungi Kami
                </h2>
                <div className="space-y-3">
                  <a 
                    href="https://wa.me/6282248526996"
                    target="_blank"
                    className="flex items-center gap-3 text-slate-600 hover:text-primary"
                  >
                    <Phone className="w-5 h-5" />
                    <span>0822 4852 6996</span>
                  </a>
                  <a 
                    href="mailto:bkprmi.aceh@gmail.com"
                    className="flex items-center gap-3 text-slate-600 hover:text-primary"
                  >
                    <Mail className="w-5 h-5" />
                    <span>bkprmi.aceh@gmail.com</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

