import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import Link from 'next/link';
import { AlertCircle, Download, Image as ImageIcon } from 'lucide-react';

export const dynamic = 'force-dynamic';

const getBaseUrl = () => {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
    return new URL(apiUrl).origin;
  } catch {
    return 'http://localhost:8000';
  }
};

const getStorageUrl = (path?: string) => {
  if (!path) return null;
  return `${getBaseUrl()}/storage/${path}`;
};

async function getData() {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
  
  try {
    const res = await fetch(`${baseUrl}/lembaga`, { cache: 'no-store' });
    const data = res.ok ? await res.json() : { data: [] };
    return data.data || [];
  } catch (error) {
    console.error('Error fetching lembaga:', error);
    return [];
  }
}

export default async function LembagaPage() {
  const lembagas = await getData();

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 py-12 bg-background">
        <div className="container-page">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-heading font-bold text-slate-900 mb-4">
              Lembaga BKPRMI Aceh
            </h1>
            <p className="text-slate-500">
              Badan-badan Lembaga dalam struktur organisasi BKPRMI Aceh
            </p>
          </div>

          {/* Lembaga Grid */}
          {lembagas.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {lembagas.map((item: any) => (
                <div key={item.id} className="card hover:shadow-lg transition-shadow">
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 overflow-hidden">
                      {item.logo ? (
                        <img 
                          src={getStorageUrl(item.logo)!} 
                          alt={item.nama}
                          className="w-full h-full object-contain p-2"
                        />
                      ) : (
                        <div className="text-primary font-bold text-xl">
                          {item.nama.charAt(0)}
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-slate-900 mb-2">
                        {item.nama}
                      </h3>
                      {item.deskripsi && (
                        <p className="text-sm text-slate-500 line-clamp-3 mb-3">
                          {item.deskripsi}
                        </p>
                      )}
                      {item.file && (
                        <a 
                          href={getStorageUrl(item.file)!}
                          target="_blank"
                          className="text-sm text-primary hover:underline flex items-center gap-1"
                        >
                          <Download className="w-4 h-4" />
                          Unduh Dokumen
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-white rounded-xl">
              <AlertCircle className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                Lembaga Belum Didaftarkan
              </h3>
              <p className="text-slate-500">
                Informasi lembaga akan segera dilengkapi. Silakan tunggu informasi selanjutnya.
              </p>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}

