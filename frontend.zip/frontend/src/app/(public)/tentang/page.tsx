import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { Phone, Mail, MapPin, MessageCircle, Target, Eye, Heart } from 'lucide-react';

export const dynamic = 'force-dynamic';

async function getData() {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
  
  try {
    const res = await fetch(`${baseUrl}/profil?jenis=visi_misi`, { cache: 'no-store' });
    const data = res.ok ? await res.json() : { data: null };
    return data.data || null;
  } catch (error) {
    console.error('Error fetching profil:', error);
    return null;
  }
}

export default async function TentangPage() {
  const profil = await getData();

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 py-12 bg-background">
        <div className="container-page">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-heading font-bold text-slate-900 mb-4">
              Tentang Kami
            </h1>
            <p className="text-slate-500">
              BKPRMI Aceh - Badan Komunikasi Pengarusutamaan Remaja Masjid Indonesia
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Visi Misi */}
              <div className="card">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-primary text-white flex items-center justify-center">
                    <Target className="w-6 h-6" />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-900">Visi & Misi</h2>
                </div>
                
                {profil?.konten ? (
                  <div 
                    className="prose prose-slate max-w-none"
                    dangerouslySetInnerHTML={{ __html: profil.konten }}
                  />
                ) : (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold text-slate-900 mb-2 flex items-center gap-2">
                        <Eye className="w-5 h-5 text-primary" />
                        Visi
                      </h3>
                      <p className="text-slate-600">
                        Menjadi organisasi remaja masjid yang profesional, inovatif, dan bertanggung jawab dalam membina generasi muda Islam yang berakhlakul karimah, berilmu, dan berjiwa sosial tinggi.
                      </p>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold text-slate-900 mb-2 flex items-center gap-2">
                        <Target className="w-5 h-5 text-primary" />
                        Misi
                      </h3>
                      <ul className="space-y-2 text-slate-600">
                        <li>1. Membina ketakwaan dan akhlakul karimah generasi muda</li>
                        <li>2. Meningkatkan kualitas pendidikan dan pengetahuan agama Islam</li>
                        <li>3. Memfasilitasi kreativitas dan inovasi generasi muda</li>
                        <li>4. Melembangkan jaringan komunikasi antar remaja masjid</li>
                        <li>5. Ikut serta dalam program-program social kemasyarakatan</li>
                      </ul>
                    </div>
                  </div>
                )}
              </div>

              {/* Tentang */}
              <div className="card">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-primary text-white flex items-center justify-center">
                    <Heart className="w-6 h-6" />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-900">Tentang BKPRMI</h2>
                </div>
                
                <div className="prose prose-slate max-w-none">
                  <p>
                    <strong>BKPRMI (Badan Komunikasi Pemuda Remaja Masjid Indonesia)</strong> 
                    adalah organisasi yang bergerak dalam bidang kepemudaan Islam yang berfokus pada 
                    pengembangan potensi remaja Masjid di seluruh Indonesia.
                  </p>
                  <p>
                    BKPRMI Aceh merupakan perwakilan daerah dari BKPRMI Nasional yang bergerak 
                    di wilayah Provinsi Aceh. Organisasi ini memiliki tugas pokok untuk 
                    menghimpun, membina, dan memberdayakan remaja Masjid di seluruh Aceh 
                    dalam berbagai aspek kehidupan bermasyarakat.
                  </p>
                  <p>
                    Dengan spirit Islami dan moderne, BKPRMI Aceh terus berkomitmen untuk 
                    membangun generasi muda yang shaleh secara moral, cerdas secara intelektual, 
                    dan bermanfaat bagi masyarakat.
                  </p>
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Kontak */}
              <div className="card">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">
                  Hubungi Kami
                </h3>
                <div className="space-y-4">
                  <a 
                    href="https://wa.me/6282248526996"
                    target="_blank"
                    className="flex items-center gap-3 text-slate-600 hover:text-primary"
                  >
                    <div className="w-10 h-10 rounded-lg bg-green-100 text-green-600 flex items-center justify-center">
                      <MessageCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">WhatsApp</p>
                      <p className="font-medium">0822 4852 6996</p>
                    </div>
                  </a>
                  
                  <a 
                    href="mailto:bkprmi.aceh@gmail.com"
                    className="flex items-center gap-3 text-slate-600 hover:text-primary"
                  >
                    <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
                      <Mail className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Email</p>
                      <p className="font-medium">bkprmi.aceh@gmail.com</p>
                    </div>
                  </a>
                  
                  <div className="flex items-center gap-3 text-slate-600">
                    <div className="w-10 h-10 rounded-lg bg-red-100 text-red-600 flex items-center justify-center">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Alamat</p>
                      <p className="font-medium">Aceh, Indonesia</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* sosial media */}
              <div className="card">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">
                  Sosial Media
                </h3>
                <p className="text-slate-500 text-sm mb-4">
                  Ikuti kami di media sosial untuk informasi terbaru.
                </p>
                <div className="flex gap-3">
                  <a href="#" className="btn btn-outline">
                    Facebook
                  </a>
                  <a href="#" className="btn btn-outline">
                    Instagram
                  </a>
                  <a href="#" className="btn btn-outline">
                    YouTube
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

