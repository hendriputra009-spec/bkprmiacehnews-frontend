import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import ShareButtons from '@/components/news/ShareButtons';
import TataLaksanaClient, { KabupatenOption, TataJumatItem } from './TataLaksanaClient';

export const dynamic = 'force-dynamic';

export async function generateMetadata() {
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
  
  return {
    title: 'Tata Laksana Jumat - BKPRMI Aceh',
    description: 'Jadwal khutbah Jumat dari DPD BKPRMI se-Aceh, terupdate dan dapat dibagikan.',
    openGraph: {
      title: 'Tata Laksana Jumat - BKPRMI Aceh',
      description: 'Jadwal khutbah Jumat dari DPD BKPRMI se-Aceh, terupdate dan dapat dibagikan.',
      url: `${baseUrl}/tata-laksana`,
      siteName: 'BKPRMI Aceh',
      locale: 'id_ID',
      type: 'website',
    },
    twitter: {
      card: 'summary_large_image',
      title: 'Tata Laksana Jumat - BKPRMI Aceh',
      description: 'Jadwal khutbah Jumat dari DPD BKPRMI se-Aceh, terupdate dan dapat dibagikan.',
    },
  };
}

async function getData(kabupatenId?: string): Promise<TataJumatItem[]> {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
  const params = new URLSearchParams();
  if (kabupatenId) params.set('kabupaten_id', kabupatenId);

  try {
    const res = await fetch(`${baseUrl}/tata-jumat?${params.toString()}`, { cache: 'no-store' });
    const data = res.ok ? await res.json() : { data: [] };
    const payload = data.data ?? [];

    if (Array.isArray(payload)) return payload;
    if (Array.isArray(payload.data)) return payload.data;
    return [];
  } catch (error) {
    console.error('Error fetching tata jumat:', error);
    return [];
  }
}

async function getKabupatens(): Promise<KabupatenOption[]> {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
  try {
    const res = await fetch(`${baseUrl}/kabupaten`, { cache: 'no-store' });
    const data = res.ok ? await res.json() : { data: [] };
    return data.data ?? [];
  } catch (error) {
    console.error('Error fetching kabupaten:', error);
    return [];
  }
}

export default async function TataLaksanaPage({ searchParams }: { searchParams?: { kabupaten_id?: string; kabupaten?: string } }) {
  const kabupatens = await getKabupatens();

  // Support old URLs that passed `kabupaten` name as query param
  let selectedKabupatenId = searchParams?.kabupaten_id ?? '';
  if (!selectedKabupatenId && searchParams?.kabupaten) {
    const found = kabupatens.find(k => k.nama_kabupaten === searchParams.kabupaten);
    selectedKabupatenId = found ? String(found.id) : '';
  }

  const tataJumats = await getData(selectedKabupatenId);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 py-12 bg-background">
        <TataLaksanaClient
          initialKabupatens={kabupatens}
          initialTataJumats={tataJumats}
          initialSelectedKabupatenId={selectedKabupatenId}
        />
      </main>
      <Footer />
    </div>
  );
}

