'use client';

import { useEffect, useMemo, useState } from 'react';
import Image from 'next/image';
import { Calendar, MapPin, Download, Search, ChevronDown, ChevronUp, FileText, X, Eye, File, ExternalLink, Share2 } from 'lucide-react';
import ShareButtons from '@/components/news/ShareButtons';

export type TataJumatItem = {
  id: number;
  dpd?: { id?: number; nama_kabupaten: string };
  kabupaten?: string;
  tanggal_masehi: string;
  tanggal_hijriyah?: string;
  file?: string;
  file_type?: 'image' | 'document' | 'text';
  text_content?: string;
};

export type KabupatenOption = {
  id: number;
  nama_kabupaten: string;
};

type Props = {
  initialKabupatens: KabupatenOption[];
  initialTataJumats: TataJumatItem[];
  initialSelectedKabupatenId: string;
};

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
const STORAGE_URL = process.env.NEXT_PUBLIC_STORAGE_URL || 'http://localhost:8000/storage';
const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';

function buildQueryParams(kabupatenId: string) {
  const params = new URLSearchParams();
  if (kabupatenId) params.set('kabupaten_id', kabupatenId);
  return params.toString();
}

async function fetchTataJumats(kabupatenId: string): Promise<TataJumatItem[]> {
  const params = buildQueryParams(kabupatenId);
  const res = await fetch(`${API_URL}/tata-jumat?${params}`, { cache: 'no-store' });
  const data = res.ok ? await res.json() : { data: [] };
  const payload = data.data ?? [];
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload.data)) return payload.data;
  return [];
}

// Format date from ISO format to YYYY-MM-DD
const formatDate = (dateString?: string) => {
  if (!dateString) return '-';
  try {
    // Handle ISO format like "2026-03-11T00:00:00.000000Z"
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  } catch {
    return dateString;
  }
};

// Image component with error handling - shows full image without cropping
function SafeImage({ 
  src, 
  alt, 
  className,
  fill = false,
  unoptimized = false
}: { 
  src: string; 
  alt: string; 
  className?: string;
  fill?: boolean;
  unoptimized?: boolean;
}) {
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);

  if (error) {
    return (
      <div className={`bg-slate-100 flex items-center justify-center ${className}`}>
        <div className="text-center">
          <FileText className="w-12 h-12 text-slate-400 mx-auto mb-2" />
          <p className="text-sm text-slate-500">Gambar tidak tersedia</p>
        </div>
      </div>
    );
  }

  if (fill) {
    return (
      <div className={`relative ${className}`}>
        {loading && (
          <div className="absolute inset-0 bg-slate-200 animate-pulse rounded-lg" />
        )}
        <Image
          src={src}
          alt={alt}
          fill
          unoptimized={unoptimized}
          className={`object-contain rounded-lg transition-opacity duration-300 ${ loading ? 'opacity-0' : 'opacity-100'}`}
          onLoad={() => setLoading(false)}
          onError={() => {
            setError(true);
            setLoading(false);
          }}
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 90vw, 1200px"
        />
      </div>
    );
  }

  return (
    <div className={`relative ${className}`}>
      {loading && (
        <div className="absolute inset-0 bg-slate-200 animate-pulse rounded-lg" />
      )}
      <Image
        src={src}
        alt={alt}
        className={`w-full h-full object-contain rounded-lg transition-opacity duration-300 ${ loading ? 'opacity-0' : 'opacity-100'}`}
        onLoad={() => setLoading(false)}
        onError={() => {
          setError(true);
          setLoading(false);
        }}
        width={800}
        height={600}
        unoptimized={unoptimized}
      />
    </div>
  );
}

// Enhanced Modal for detail view with improved responsive layout
function DetailModal({ 
  item, 
  onClose 
}: { 
  item: TataJumatItem; 
  onClose: () => void;
}) {
  const imageUrl = item.file ? `${STORAGE_URL}/${item.file}` : '';
  const shareUrl = `${BASE_URL}/tata-laksana?kabupaten_id=${item.dpd?.id || ''}`;
  
  // Get file extension for display
  const getFileExtension = (filename: string) => {
    const parts = filename.split('.');
    return parts.length > 1 ? parts[parts.length - 1].toUpperCase() : 'FILE';
  };
  
  const fileName = item.file ? item.file.split('/').pop() || 'dokumen' : '';
  const fileExtension = getFileExtension(fileName);
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      
      {/* Modal Content */}
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[95vh] overflow-hidden flex flex-col">
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-all shadow-lg border border-slate-200"
        >
          <X className="w-5 h-5 text-slate-600" />
        </button>
        
        {/* Image Preview - Full width, not cropped - using object-contain */}
        {item.file_type === 'image' && item.file && (
          <div className="relative w-full bg-slate-900 flex items-center justify-center min-h-[300px] max-h-[50vh] sm:max-h-[60vh]">
            <SafeImage 
              src={imageUrl} 
              alt={item.kabupaten || item.dpd?.nama_kabupaten || 'Tata Laksana'} 
              className="w-full h-full min-h-[300px] max-h-[50vh] sm:max-h-[60vh]"
              fill
              unoptimized
            />
            {/* Image overlay hint */}
            <div className="absolute bottom-4 left-4 bg-black/50 backdrop-blur-sm px-3 py-1.5 rounded-full flex items-center gap-2">
              <Eye className="w-4 h-4 text-white" />
              <span className="text-white text-sm font-medium">Klik untuk memperbesar</span>
            </div>
          </div>
        )}
        
        {/* Content Section */}
        <div className="p-6 sm:p-8 overflow-y-auto flex-1">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-start gap-4 mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-600 to-primary-700 text-white flex flex-col items-center justify-center shadow-lg">
                <span className="text-[10px] font-medium opacity-80 uppercase">Jumat</span>
                <span className="text-xl font-bold leading-none">
                  {new Date(item.tanggal_masehi).getDate()}
                </span>
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                  {item.kabupaten || item.dpd?.nama_kabupaten}
                </h2>
                <div className="flex items-center gap-2 mt-1">
                  <Calendar className="w-4 h-4 text-slate-400" />
                  <span className="text-sm text-slate-600">{formatDate(item.tanggal_masehi)}</span>
                  {item.tanggal_hijriyah && (
                    <>
                      <span className="text-slate-300">•</span>
                      <span className="text-sm text-slate-500">{item.tanggal_hijriyah}</span>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          {/* Text Content */}
          {item.file_type === 'text' && item.text_content && (
            <div className="mb-6">
              <div 
                className="prose prose-slate max-w-none prose-lg"
                dangerouslySetInnerHTML={{ __html: item.text_content }}
              />
            </div>
          )}
          
          {/* Document/File Section with Preview and Download */}
          {item.file_type === 'document' && item.file && (
            <div className="mb-6">
              <div className="bg-slate-50 rounded-xl border-2 border-dashed border-slate-200 p-6">
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  {/* File Icon/Preview */}
                  <div className="w-20 h-20 rounded-xl bg-white shadow-sm flex items-center justify-center border border-slate-200">
                    <File className="w-10 h-10 text-primary" />
                  </div>
                  
                  {/* File Info */}
                  <div className="flex-1 text-center sm:text-left">
                    <h3 className="font-semibold text-slate-900 mb-1">Dokumen</h3>
                    <p className="text-sm text-slate-500 mb-3">{fileName}</p>
                    <div className="flex flex-wrap justify-center sm:justify-start gap-2">
                      <span className="px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full">
                        {fileExtension}
                      </span>
                    </div>
                  </div>
                  
                  {/* Action Buttons - Open and Download */}
                  <div className="flex flex-col sm:flex-row gap-2">
                    <a
                      href={imageUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors font-medium text-sm shadow-sm"
                    >
                      <ExternalLink className="w-4 h-4" />
                      Buka
                    </a>
                    <a
                      href={imageUrl}
                      download={fileName}
                      rel="noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2.5 bg-primary text-white rounded-lg hover:bg-primary-700 transition-colors font-medium text-sm shadow-sm"
                    >
                      <Download className="w-4 h-4" />
                      Unduh
                    </a>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Image Download Section */}
          {item.file_type === 'image' && item.file && (
            <div className="mb-6 p-4 bg-slate-50 rounded-xl">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <p className="font-medium text-slate-900">Tentang gambar ini</p>
                  <p className="text-sm text-slate-500">Klik gambar untuk melihat ukuran penuh</p>
                </div>
                <div className="flex gap-2">
                  <a
                    href={imageUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors text-sm font-medium"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Buka
                  </a>
                  <a
                    href={imageUrl}
                    download={`tata-laksana-${item.kabupaten || item.dpd?.nama_kabupaten}-${formatDate(item.tanggal_masehi)}.jpg`}
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-700 transition-colors text-sm font-medium"
                  >
                    <Download className="w-4 h-4" />
                    Unduh
                  </a>
                </div>
              </div>
            </div>
          )}
          
          {/* Share Section */}
          <div className="border-t border-slate-200 pt-6">
            <div className="flex items-center gap-2 mb-4">
              <Share2 className="w-5 h-5 text-slate-400" />
              <span className="text-sm font-semibold text-slate-700 uppercase tracking-wide">Bagikan</span>
            </div>
            <ShareButtons 
              title={`Tata Laksana Jumat - ${item.kabupaten || item.dpd?.nama_kabupaten}`}
              description={`Jadwal khutbah Jumat ${formatDate(item.tanggal_masehi)} - ${item.tanggal_hijriyah || ''}`}
              url={shareUrl}
              image={item.file_type === 'image' ? imageUrl : undefined}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default function TataLaksanaClient({ initialKabupatens, initialTataJumats, initialSelectedKabupatenId }: Props) {
  const [kabupatens, setKabupatens] = useState<KabupatenOption[]>(initialKabupatens);
  const [tataJumats, setTataJumats] = useState<TataJumatItem[]>(initialTataJumats);
  const [selectedKabupatenId, setSelectedKabupatenId] = useState(initialSelectedKabupatenId);
  const [loading, setLoading] = useState(false);
  const [expandedItems, setExpandedItems] = useState<Record<number, boolean>>({});
  const [selectedItem, setSelectedItem] = useState<TataJumatItem | null>(null);

  useEffect(() => {
    if (!initialKabupatens.length) {
      (async () => {
        try {
          const res = await fetch(`${API_URL}/kabupaten`, { cache: 'no-store' });
          const data = res.ok ? await res.json() : { data: [] };
          setKabupatens(data.data ?? []);
        } catch (error) {
          console.error('Error fetching kabupaten:', error);
        }
      })();
    }
  }, [initialKabupatens]);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const data = await fetchTataJumats(selectedKabupatenId);
        setTataJumats(data);
      } catch (error) {
        console.error('Error fetching tata jumat:', error);
        setTataJumats([]);
      } finally {
        setLoading(false);
      }
    };

    load();
  }, [selectedKabupatenId]);

  const kabupatenOptions = useMemo(() => kabupatens, [kabupatens]);

  const groupedByKabupaten = useMemo(() => {
    return tataJumats.reduce((acc: Record<string, TataJumatItem[]>, item) => {
      const key = item.kabupaten || item.dpd?.nama_kabupaten || 'Lainnya';
      if (!acc[key]) acc[key] = [];
      acc[key].push(item);
      return acc;
    }, {});
  }, [tataJumats]);

  const hasItems = tataJumats.length > 0;

  const toggleExpand = (id: number) => {
    setExpandedItems(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const getImageUrl = (file: string) => `${STORAGE_URL}/${file}`;

  return (
    <div className="min-h-screen flex flex-col">
      <div className="container-page">
        {/* Header Section */}
        <div className="mb-8">
          <h1 className="text-3xl lg:text-4xl font-heading font-bold text-slate-900 mb-3">
            Tata Laksana Jumat
          </h1>
          <p className="text-slate-500 max-w-2xl">
            Lihat jadwal khutbah Jumat dari DPD BKPRMI se-Aceh. Gunakan filter untuk menemukan jadwal berdasarkan Kabupaten.
          </p>
        </div>

        {/* Filter Section */}
        <div className="flex flex-col lg:flex-row lg:items-center gap-4 mb-8">
          <div className="flex items-center gap-3">
            <label className="text-sm font-medium text-slate-600">Filter Kabupaten</label>
            <div className="relative">
              <select
                value={selectedKabupatenId}
                className="input pr-10 appearance-none cursor-pointer"
                onChange={(event) => {
                  const value = event.target.value;
                  const url = new URL(window.location.href);

                  if (value) {
                    url.searchParams.set('kabupaten_id', value);
                  } else {
                    url.searchParams.delete('kabupaten_id');
                  }

                  window.history.replaceState(null, '', url.toString());
                  setSelectedKabupatenId(value);
                }}
              >
                <option value="">Semua Kabupaten</option>
                {kabupatenOptions.map(k => (
                  <option key={k.id} value={k.id}>
                    {k.nama_kabupaten}
                  </option>
                ))}
              </select>
              <Search className="w-5 h-5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Content */}
        {loading ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="animate-pulse bg-white rounded-xl h-64" />
            ))}
          </div>
        ) : !hasItems ? (
          <div className="text-center py-16 bg-white rounded-xl shadow-card">
            <Calendar className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-900 mb-2">Tata Laksana Belum Tersedia</h3>
            <p className="text-slate-500">
              Jadwal khutbah Jumat akan segera diupdate oleh DPD masing-masing.
            </p>
          </div>
        ) : (
          <div className="space-y-8">
            {Object.entries(groupedByKabupaten).map(([kabupaten, items]) => (
              <section key={kabupaten} className="card">
                <div className="flex items-center gap-2 mb-6 pb-4 border-b border-slate-200">
                  <MapPin className="w-5 h-5 text-primary" />
                  <h2 className="text-xl font-semibold text-slate-900">{kabupaten}</h2>
                  <span className="ml-auto text-sm text-slate-500">{items.length} item</span>
                </div>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {items.map(item => {
                    const isExpanded = expandedItems[item.id];
                    const hasLongText = item.text_content && item.text_content.length > 200;
                    const imageUrl = item.file ? getImageUrl(item.file) : '';
                    
                    return (
                      <article 
                        key={item.id} 
                        className="rounded-xl border border-slate-200 bg-white shadow-card overflow-hidden hover:shadow-elevated transition-shadow duration-300"
                      >
                        {/* Image Section - Click to view detail */}
                        {item.file_type === 'image' && item.file && (
                          <div 
                            className="relative h-44 w-full cursor-pointer group"
                            onClick={() => setSelectedItem(item)}
                          >
                            <SafeImage 
                              src={imageUrl} 
                              alt={kabupaten} 
                              className="w-full h-full"
                              fill
                              unoptimized
                            />
                            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                            <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                              <span className="px-2 py-1 bg-black/50 backdrop-blur-sm text-white text-xs rounded-full flex items-center gap-1">
                                <Eye className="w-3 h-3" />
                                Lihat
                              </span>
                            </div>
                          </div>
                        )}
                        
                        <div className="p-5">
                          <div className="flex items-start gap-4 mb-4">
                            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary-700 to-primary-600 text-white flex flex-col items-center justify-center flex-shrink-0 shadow-lg">
                              <span className="text-[10px] font-medium opacity-80 uppercase tracking-wider">Jumat</span>
                              <span className="text-lg font-bold leading-none">
                                {new Date(item.tanggal_masehi).getDate()}
                              </span>
                            </div>
                            <div className="flex-1 min-w-0">
                              <h3 className="text-lg font-semibold text-slate-900 truncate">
                                {item.kabupaten || item.dpd?.nama_kabupaten}
                              </h3>
                              <p className="text-sm text-slate-500 mt-1">{item.tanggal_hijriyah}</p>
                            </div>
                          </div>

                          {/* Text Content with Read More */}
                          {item.file_type === 'text' && item.text_content && (
                            <div className="mb-4">
                              <div 
                                className={`prose prose-slate prose-sm max-w-none text-slate-600 ${!isExpanded ? 'line-clamp-3' : ''}`}
                                dangerouslySetInnerHTML={{ 
                                  __html: isExpanded ? item.text_content : item.text_content.substring(0, 200) + '...' 
                                }} 
                              />
                              {hasLongText && (
                                <button
                                  onClick={() => toggleExpand(item.id)}
                                  className="mt-2 text-sm font-medium text-primary hover:text-primary-700 flex items-center gap-1 transition-colors"
                                >
                                  {isExpanded ? (
                                    <>Lihat Lebih Sedikit <ChevronUp className="w-4 h-4" /></>
                                  ) : (
                                    <>Baca Selanjutkan <ChevronDown className="w-4 h-4" /></>
                                  )}
                                </button>
                              )}
                            </div>
                          )}

                          {/* Document Preview */}
                          {item.file_type === 'document' && item.file && (
                            <div className="mb-4 p-3 bg-slate-50 rounded-lg">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center border border-slate-200">
                                  <File className="w-5 h-5 text-primary" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="text-sm font-medium text-slate-700 truncate">Dokumen</p>
                                  <p className="text-xs text-slate-500">Klik untuk melihat</p>
                                </div>
                              </div>
                            </div>
                          )}
                          
                          {/* Actions - All content types have Detail button */}
                          <div className="flex items-center gap-2 pt-3 border-t border-slate-100">
                            <button 
                              onClick={() => setSelectedItem(item)}
                              className="w-full px-3 py-2.5 text-sm font-medium text-primary bg-primary-50 rounded-lg hover:bg-primary-100 transition-colors flex items-center justify-center gap-2"
                            >
                              <FileText className="w-4 h-4" />
                              Lihat Detail
                            </button>
                          </div>
                        </div>
                      </article>
                    );
                  })}
                </div>
              </section>
            ))}
          </div>
        )}
      </div>
      
      {/* Detail Modal */}
      {selectedItem && (
        <DetailModal 
          item={selectedItem} 
          onClose={() => setSelectedItem(null)} 
        />
      )}
    </div>
  );
}

