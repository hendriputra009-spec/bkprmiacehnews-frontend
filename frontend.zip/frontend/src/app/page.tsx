import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import Link from 'next/link';
import { ArrowRight, Calendar, MapPin, Image as ImageIcon, FileText, Heart, AlertCircle, Users, Clock, ChevronLeft, ChevronRight } from 'lucide-react';

export const dynamic = 'force-dynamic';

async function getData() {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
  
  try {
    const [beritaRes, galeriRes, tataJumatRes, dpdRes] = await Promise.all([
      fetch(`${baseUrl}/berita?limit=4`, { cache: 'no-store' }),
      fetch(`${baseUrl}/galeri?limit=8`, { cache: 'no-store' }),
      fetch(`${baseUrl}/tata-jumat?limit=3`, { cache: 'no-store' }),
      fetch(`${baseUrl}/dpd`, { cache: 'no-store' })
    ]);
    
    const berita = beritaRes.ok ? await beritaRes.json() : { data: { data: [] } };
    const galeri = galeriRes.ok ? await galeriRes.json() : { data: { data: [] } };
    const tataJumat = tataJumatRes.ok ? await tataJumatRes.json() : { data: { data: [] } };
    const dpd = dpdRes.ok ? await dpdRes.json() : { data: { data: [] } };
    
    return {
      berita: berita.data?.data ?? [],
      galeri: galeri.data?.data ?? [],
      tataJumat: tataJumat.data?.data ?? [],
      totalDpd: dpd.data?.data?.length ?? 0,
      totalGaleri: galeri.data?.data?.length ?? 0,
      totalBerita: berita.data?.data?.length ?? 0,
    };
  } catch (error) {
    console.error('Error fetching data:', error);
    return { 
      berita: [], 
      galeri: [], 
      tataJumat: [], 
      totalDpd: 0,
      totalGaleri: 0,
      totalBerita: 0,
    };
  }
}

export default async function HomePage() {
  const { berita, galeri, tataJumat, totalDpd, totalGaleri, totalBerita } = await getData();

  const stats = [
    { label: 'DPD', value: totalDpd || '23', icon: MapPin, color: 'bg-green-500' },
    { label: 'Berita', value: totalBerita > 0 ? `${totalBerita}+` : '0', icon: FileText, color: 'bg-blue-500' },
    { label: 'Galeri', value: totalGaleri > 0 ? `${totalGaleri}+` : '0', icon: ImageIcon, color: 'bg-purple-500' },
    { label: 'Aktivis', value: '500+', icon: Users, color: 'bg-orange-500' },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        {/* Hero Section - Modern & Professional */}
        <section className="relative min-h-[85vh] flex items-center bg-gradient-to-br from-primary via-primary-700 to-secondary overflow-hidden">
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0" style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            }}></div>
          </div>
          
          {/* Decorative Elements */}
          <div className="absolute top-20 right-10 w-72 h-72 bg-white/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 left-20 w-96 h-96 bg-accent/20 rounded-full blur-3xl"></div>
          
          <div className="container-page relative z-10">
            <div className="max-w-4xl">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
                <span className="w-2 h-2 bg-accent rounded-full animate-pulse"></span>
                <span className="text-sm font-medium text-white/90">Badan Komunikasi Pemuda Remaja Masjid Indonesia</span>
              </div>
              
              <h1 className="text-4xl md:text-5xl lg:text-7xl font-heading font-bold mb-6 leading-tight text-white">
                Membangun <span className="text-accent">Generasi Muda</span> Islam yang Berakhlakul Karimah
              </h1>
              
              <p className="text-lg md:text-xl text-white/80 mb-8 max-w-2xl leading-relaxed">
                Menyatukan langkah pemuda Aceh dalam kebaikan, ketakwaan, dan kontribusi nyata bagi masyarakat.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <Link href="/profil" className="btn bg-white text-primary hover:bg-slate-100 px-8 py-3.5 text-base font-semibold shadow-lg hover:shadow-xl transition-all">
                  Pelajari Lebih Lanjut
                </Link>
                <Link href="/donasi" className="btn bg-accent text-slate-900 hover:bg-yellow-400 px-8 py-3.5 text-base font-bold shadow-lg hover:shadow-xl transition-all">
                  Berdonasi
                </Link>
              </div>
            </div>
          </div>
          
          {/* Scroll Indicator */}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
            <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
              <div className="w-1.5 h-3 bg-white/60 rounded-full"></div>
            </div>
          </div>
        </section>

        {/* Stats Section - Modern Cards */}
        <section className="py-12 -mt-16 relative z-20">
          <div className="container-page">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="bg-white rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-shadow duration-300">
                  <div className={`w-14 h-14 rounded-xl ${stat.color} flex items-center justify-center mb-4 shadow-lg`}>
                    <stat.icon className="w-7 h-7 text-white" />
                  </div>
                  <div className="text-3xl md:text-4xl font-bold text-slate-900 mb-1">{stat.value}</div>
                  <div className="text-sm text-slate-500 font-medium">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* About Section */}
        <section className="py-20 bg-white">
          <div className="container-page">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <span className="text-primary font-semibold text-sm tracking-wider uppercase">Tentang Kami</span>
                <h2 className="text-3xl md:text-4xl font-heading font-bold text-slate-900 mt-2 mb-6">
                  BKPRMI Aceh: Menyatukan Pemuda dalam Kebaikan
                </h2>
                <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                  Badan Komunikasi Pemuda Remaja Masjid Indonesia (BKPRMI) Aceh merupakan organisasi yang bergerak dalam pengembangan generasi muda Islam di Provinsi Aceh.
                </p>
                <p className="text-slate-600 mb-8 leading-relaxed">
                  Kami berkomitmen untuk meningkatkan kualitas generasi muda melalui program-program positif yang berlandaskan Al-Quran dan Sunnah.
                </p>
                <Link href="/tentang" className="inline-flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all">
                  Selengkapnya <ArrowRight className="w-5 h-5" />
                </Link>
              </div>
              <div className="relative">
                <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl">
                  <div className="w-full h-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                    <div className="text-center text-white p-8">
                      <MapPin className="w-16 h-16 mx-auto mb-4 opacity-80" />
                      <p className="text-xl font-semibold">23 DPD se-Aceh</p>
                      <p className="opacity-80">Kabupaten/Kota</p>
                    </div>
                  </div>
                </div>
                {/* Floating Card */}
                <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-xl p-4 flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <Heart className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-slate-900">100%</p>
                    <p className="text-sm text-slate-500">Ikhlas & Transparan</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Galeri Section - Featured */}
        <section className="py-20 bg-gradient-to-br from-slate-50 to-slate-100">
          <div className="container-page">
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-10">
              <div>
                <span className="text-primary font-semibold text-sm tracking-wider uppercase">Dokumentasi</span>
                <h2 className="text-3xl md:text-4xl font-heading font-bold text-slate-900 mt-2">
                  Galeri Kegiatan
                </h2>
                <p className="text-slate-600 mt-2">Momentum berharga dari aktivitas BKPRMI Aceh</p>
              </div>
              <Link href="/galeri" className="btn-outline mt-4 md:mt-0">
                Lihat Semua Galeri
              </Link>
            </div>

            {galeri.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                {galeri.slice(0, 8).map((item: any, index: number) => (
                  <Link 
                    key={item.id} 
                    href={`/galeri/${item.slug}`}
                    className={`group relative aspect-square rounded-2xl overflow-hidden ${
                      index === 0 ? 'md:col-span-2 md:row-span-2' : ''
                    }`}
                  >
                    {item.gambar ? (
                      <img 
                        src={`${new URL(process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1').origin}/storage/${item.gambar}`}
                        alt={item.judul}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    ) : (
                      <div className="w-full h-full bg-primary/10 flex items-center justify-center">
                        <ImageIcon className="w-12 h-12 text-primary/30" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <div className="absolute bottom-0 left-0 right-0 p-4">
                        <h3 className="text-white font-semibold text-sm line-clamp-2">{item.judul}</h3>
                        {item.tanggal && (
                          <p className="text-white/70 text-xs mt-1">{new Date(item.tanggal).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-white rounded-2xl">
                <ImageIcon className="w-16 h-16 text-slate-200 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">Galeri Belum Tersedia</h3>
                <p className="text-slate-500">Dokumentasi kegiatan akan segera diupload.</p>
              </div>
            )}
          </div>
        </section>

        {/* Berita Terkini */}
        <section className="py-20 bg-white">
          <div className="container-page">
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-10">
              <div>
                <span className="text-primary font-semibold text-sm tracking-wider uppercase">Informasi</span>
                <h2 className="text-3xl md:text-4xl font-heading font-bold text-slate-900 mt-2">
                  Berita Terkini
                </h2>
                <p className="text-slate-600 mt-2">Update informasi terbaru dari BKPRMI Aceh</p>
              </div>
              <Link href="/berita" className="btn-outline mt-4 md:mt-0">
                Lihat Semua Berita
              </Link>
            </div>

            {berita.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {berita.map((item: any) => (
                  <Link 
                    key={item.id} 
                    href={`/berita/${item.slug}`}
                    className="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300"
                  >
                    <div className="aspect-[16/10] bg-slate-100 overflow-hidden">
                      {item.gambar ? (
                        <img 
                          src={`${new URL(process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1').origin}/storage/${item.gambar}`}
                          alt={item.judul}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                          <ImageIcon className="w-10 h-10 text-primary/30" />
                        </div>
                      )}
                    </div>
                    <div className="p-5">
                      <div className="flex items-center gap-2 mb-3">
                        {item.kategori && (
                          <span className="text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-full">
                            {item.kategori.nama}
                          </span>
                        )}
                        <span className="text-xs text-slate-400 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(item.created_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}
                        </span>
                      </div>
                      <h3 className="text-base font-semibold text-slate-900 group-hover:text-primary transition-colors line-clamp-2">
                        {item.judul}
                      </h3>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-slate-50 rounded-2xl">
                <AlertCircle className="w-16 h-16 text-slate-200 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">Belum Ada Berita</h3>
                <p className="text-slate-500">Berita terbaru akan segera hadir.</p>
              </div>
            )}
          </div>
        </section>

        {/* Tata Laksana Jumat */}
        <section className="py-20 bg-gradient-to-br from-slate-50 to-slate-100">
          <div className="container-page">
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-10">
              <div>
                <span className="text-primary font-semibold text-sm tracking-wider uppercase">Keagamaan</span>
                <h2 className="text-3xl md:text-4xl font-heading font-bold text-slate-900 mt-2">
                  Tata Laksana Jumat
                </h2>
                <p className="text-slate-600 mt-2">Jadwal khutbah Jumat dari seluruh Aceh</p>
              </div>
              <Link href="/tata-laksana" className="btn-outline mt-4 md:mt-0">
                Lihat Semua
              </Link>
            </div>

            {tataJumat.length > 0 ? (
              <div className="grid md:grid-cols-3 gap-6">
                {tataJumat.map((item: any) => (
                  <div key={item.id} className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-shadow">
                    <div className="flex items-start gap-4">
                      <div className="w-16 h-16 rounded-xl bg-primary text-white flex flex-col items-center justify-center flex-shrink-0 shadow-lg">
                        <span className="text-xs font-medium opacity-80">Jumat</span>
                        <span className="text-xl font-bold">
                          {item.tanggal_masehi ? new Date(item.tanggal_masehi).getDate() : '-'}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 text-sm text-slate-500 mb-1">
                          <Calendar className="w-4 h-4" />
                          <span>{item.tanggal_hijriyah || '-'}</span>
                        </div>
                        <h3 className="font-semibold text-slate-900 truncate">
                          {item.kabupaten || item.dpd?.nama_kabupaten || 'Kabupaten'}
                        </h3>
                        <div className="flex items-center gap-2 mt-2">
                          <span className={`text-xs px-2 py-1 rounded-full ${
                            (item.file_type || 'text') === 'pdf' 
                              ? 'bg-red-100 text-red-600' 
                              : 'bg-blue-100 text-blue-600'
                          }`}>
                            {(item.file_type || 'text').toUpperCase()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-white rounded-2xl">
                <Calendar className="w-16 h-16 text-slate-200 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">Belum Ada Jadwal</h3>
                <p className="text-slate-500">Jadwal khutbah Jumat akan segera diupdate.</p>
              </div>
            )}
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-primary via-primary-700 to-secondary relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0" style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='80' height='80' viewBox='0 0 80 80' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Ccircle cx='40' cy='40' r='8'/%3E%3Ccircle cx='20' cy='20' r='4'/%3E%3Ccircle cx='60' cy='60' r='4'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            }}></div>
          </div>
          
          <div className="container-page relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-6">
                Mari Berpartisipasi dalam Kebaikan
              </h2>
              <p className="text-lg text-white/80 mb-10 max-w-2xl mx-auto">
                Dukung program-program BKPRMI Aceh untuk membangun generasi muda Islam yang berakhlakul karimah melalui donasi Anda.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Link href="/donasi" className="btn bg-white text-primary hover:bg-slate-100 font-bold px-8 py-4 text-lg shadow-xl hover:shadow-2xl transition-all">
                  Berdonasi Sekarang
                </Link>
                <Link href="/dpd" className="btn border-2 border-white text-white hover:bg-white hover:text-primary font-semibold px-8 py-4 text-lg transition-all">
                  Daftar DPD
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

