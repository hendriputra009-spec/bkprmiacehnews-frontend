'use client';

import { Calendar, FileText } from 'lucide-react';

const stats = [
  { label: 'Tata Jumat', value: '0', icon: Calendar },
  { label: 'Draft', value: '0', icon: FileText },
];

export default function DpdDashboardPage() {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-900">Dashboard DPD</h1>
        <p className="text-slate-500">Kelola profil dan tata laksana Jumat DPD Anda</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="card">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                <stat.icon className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
                <p className="text-xs text-slate-500">{stat.label}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="card">
        <h2 className="text-lg font-semibold text-slate-900 mb-4">Aksi Cepat</h2>
        <div className="grid grid-cols-2 gap-4">
          <a href="/dpd-admin/tata-jumat/create" className="p-4 bg-blue-50 rounded-xl text-center hover:bg-blue-100 transition-colors">
            <Calendar className="w-6 h-6 text-blue-600 mx-auto mb-2" />
            <span className="text-sm font-medium text-blue-600">Input Tata Jumat</span>
          </a>
          <a href="/dpd-admin/profil" className="p-4 bg-green-50 rounded-xl text-center hover:bg-green-100 transition-colors">
            <FileText className="w-6 h-6 text-green-600 mx-auto mb-2" />
            <span className="text-sm font-medium text-green-600">Edit Profil DPD</span>
          </a>
        </div>
      </div>
    </div>
  );
}
