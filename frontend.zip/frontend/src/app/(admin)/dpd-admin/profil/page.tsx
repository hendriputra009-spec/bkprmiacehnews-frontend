'use client';

import { useState, useEffect } from 'react';
import { Save, Building } from 'lucide-react';

export default function DpdProfilPage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [dpd, setDpd] = useState<any>(null);
  const [formData, setFormData] = useState({
    nama_kabupaten: '',
    sk_dpd: '',
    alamat: '',
    telepon: '',
    email: ''
  });

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) {
      const parsed = JSON.parse(userData);
      setUser(parsed);
      fetchDpd(parsed.dpd_id);
    }
  }, []);

  const fetchDpd = async (dpdId: number) => {
    try {
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/dpd/${dpdId}`);
      const data = await res.json();
      if (data.dpd) {
        setDpd(data.dpd);
        setFormData({
          nama_kabupaten: data.dpd.nama_kabupaten || '',
          sk_dpd: data.dpd.sk_dpd || '',
          alamat: data.dpd.alamat || '',
          telepon: data.dpd.telepon || '',
          email: data.dpd.email || ''
        });
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/dpd/profile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        alert('Profil DPD berhasil diperbarui');
      } else {
        alert('Gagal memperbarui profil');
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Profil DPD {formData.nama_kabupaten}</h1>
      </div>

      <div className="card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
            <Building className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="font-semibold">Informasi DPD</h2>
            <p className="text-sm text-slate-500">Kelola informasi profil DPD Anda</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="label">Nama Kabupaten/Kota</label>
            <input type="text" name="nama_kabupaten" value={formData.nama_kabupaten} onChange={handleChange} className="input" disabled />
          </div>
          <div>
            <label className="label">SK DPD</label>
            <input type="text" name="sk_dpd" value={formData.sk_dpd} onChange={handleChange} className="input" />
          </div>
          <div>
            <label className="label">Alamat</label>
            <textarea name="alamat" value={formData.alamat} onChange={handleChange} className="input" rows={3} />
          </div>
          <div>
            <label className="label">Telepon</label>
            <input type="text" name="telepon" value={formData.telepon} onChange={handleChange} className="input" />
          </div>
          <div>
            <label className="label">Email</label>
            <input type="email" name="email" value={formData.email} onChange={handleChange} className="input" />
          </div>

          <div className="pt-4">
            <button onClick={handleSave} disabled={saving} className="btn-primary flex items-center gap-2">
              {saving ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <Save className="w-5 h-5" />}
              Simpan Perubahan
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

