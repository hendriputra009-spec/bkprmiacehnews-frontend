'use client';

import { Plus, Edit, Trash2 } from 'lucide-react';

export default function TataJumatAdminPage() {
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Tata Laksana Jumat</h1>
          <p className="text-slate-500">Kelola tata laksana Jumat DPD Anda</p>
        </div>
        <a href="/dpd-admin/tata-jumat/create" className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" /> Tambah
        </a>
      </div>
      <div className="card">
        <p className="text-center text-slate-400 py-8">Belum ada data. Klik "Tambah" untuk input.</p>
      </div>
    </div>
  );
}
