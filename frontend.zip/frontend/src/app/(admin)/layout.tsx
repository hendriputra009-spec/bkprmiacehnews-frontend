'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { 
  Building as Mosque, Menu, X, Home, FileText, Image, MapPin, Building2, 
  Calendar, Users, Heart, Settings, LogOut, Lock 
} from 'lucide-react';

const menuItems = [
  { href: '/super-admin/dashboard', label: 'Dashboard', icon: Home },
  { href: '/super-admin/berita', label: 'Berita', icon: FileText },
  { href: '/super-admin/galeri', label: 'Galeri', icon: Image },
  { href: '/super-admin/dpd', label: 'DPD', icon: MapPin },
  { href: '/super-admin/tata-jumat', label: 'Tata Jumat', icon: Calendar },
  { href: '/super-admin/lembaga', label: 'Lembaga', icon: Building2 },
  { href: '/super-admin/kategori', label: 'Kategori', icon: FileText },
  { href: '/super-admin/komentar', label: 'Komentar', icon: Users },
  { href: '/super-admin/donasi', label: 'Donasi', icon: Heart },
  { href: '/super-admin/profil', label: 'Profil', icon: Settings },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [checkingAuth, setCheckingAuth] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check authentication
    setCheckingAuth(true);

    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');

    if (!token || !userData) {
      router.push('/login');
      setCheckingAuth(false);
      return;
    }

    try {
      const parsed = JSON.parse(userData);

      // Allow any naming variant from backend (super_admin / super-admin / superadmin)
      const role = (parsed.role || '').toString().toLowerCase();
      const isSuperAdmin = ['super_admin', 'super-admin', 'superadmin'].includes(role);

      if (!isSuperAdmin) {
        router.push('/login');
        setCheckingAuth(false);
        return;
      }

      setUser(parsed);
      setCheckingAuth(false);
    } catch (e) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      router.push('/login');
      setCheckingAuth(false);
    }
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    router.push('/login');
  };

  // Show loading while checking auth
  if (checkingAuth) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-500">Memeriksa keamanan...</p>
        </div>
      </div>
    );
  }

  // If we checked auth and still have no valid user, show a message and prompt to login.
  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center border border-slate-200 rounded-2xl p-8 bg-white shadow-sm">
          <p className="text-lg font-semibold mb-3">Akses ditolak</p>
          <p className="text-sm text-slate-600 mb-6">
            Sepertinya Anda belum login atau sesi Anda telah berakhir. Silakan login kembali untuk mengakses halaman ini.
          </p>
          <button
            onClick={() => router.push('/login')}
            className="btn-primary w-full"
          >
            Login
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`fixed top-0 left-0 z-50 h-full w-64 bg-slate-900 text-white transform transition-transform lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <Link href="/super-admin/dashboard" className="flex items-center gap-2">
            <img src="/logo/logo.jpeg" alt="BKPRMI Aceh" className="w-10 h-10 rounded-lg object-cover" />
            <div>
              <h1 className="font-bold">BKPRMI</h1>
              <p className="text-xs text-slate-400">Aceh Admin</p>
            </div>
          </Link>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden">
            <X className="w-6 h-6" />
          </button>
        </div>

        <nav className="p-4 space-y-1">
          {menuItems.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setSidebarOpen(false)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${
                  isActive 
                    ? 'bg-primary text-white' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-slate-800">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-500/10 transition-colors w-full"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="lg:ml-64">
        {/* Topbar */}
        <header className="sticky top-0 z-30 bg-white border-b border-slate-200 px-4 py-3 lg:px-6">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-lg hover:bg-slate-100"
            >
              <Menu className="w-6 h-6" />
            </button>
            <div className="flex items-center gap-4 ml-auto">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white font-medium">
                  {user?.name?.charAt(0) || 'A'}
                </div>
                <span className="hidden sm:block text-sm font-medium text-slate-700">
                  {user?.name || 'Admin'}
                </span>
              </div>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="p-4 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}

