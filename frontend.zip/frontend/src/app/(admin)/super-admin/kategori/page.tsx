'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Plus, Search, Edit, Trash2, Folder } from 'lucide-react';
import { adminApi } from '@/lib/api';

export default function KategoriAdminPage() {
  const router = useRouter();
  const [kategoris, setKategoris] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({ nama: '', slug: '', deskripsi: '' });

  useEffect(() => {
    fetchKategoris();
  }, []);



  const fetchKategoris = async () => {
    try {
      setLoading(true);
      const res = await adminApi.getAdminKategori();
      console.log('fetchKategoris response:', res.data);

      const data = res.data?.data ?? res.data;
      const list = Array.isArray(data) ? data : (Array.isArray(data?.data) ? data.data : []);

      if (!Array.isArray(list)) {
        console.warn('Expected kategori list to be an array, received:', data);
      }

      setKategoris(list);
    } catch (error: any) {
      console.error('Error fetching kategori:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Yakin hapus kategori ini?')) return;
    try {
      await adminApi.deleteKategori(id);
      setKategoris(kategoris.filter(k => k.id !== id));
    } catch (error: any) {
      console.error('Error deleting kategori:', error);
      alert(`Gagal menghapus kategori: ${error?.response?.data?.message || error.message || 'Unknown error'}`);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      await adminApi.createKategori(formData);
      setShowModal(false);
      setFormData({ nama: '', slug: '', deskripsi: '' });
      fetchKategoris();
    } catch (error: any) {
      console.error('Error saving kategori:', error);
      const message = error?.response?.data?.message || error?.message || 'Cek koneksi backend';
      alert('Gagal menyimpan: ' + message);
    } finally {
      setSaving(false);
    }
  };

  const filteredKategoris = Array.isArray(kategoris)
    ? kategoris.filter(k => k.nama?.toLowerCase().includes(search.toLowerCase()))
    : [];

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Kelola Kategori</h1>
        <button onClick={() => setShowModal(true)} className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" /> Tambah Kategori
        </button>
      </div>

      <div className="card">
        <div className="p-4 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input type="text" placeholder="Cari..." value={search} onChange={(e) => setSearch(e.target.value)} className="input pl-10" />
          </div>
        </div>

        {loading ? (
          <div className="p-8 text-center">
            <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          </div>
        ) : filteredKategoris.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <Folder className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Belum ada kategori</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="text-left p-4">Nama</th>
                  <th className="text-left p-4">Slug</th>
                  <th className="text-left p-4">Deskripsi</th>
                  <th className="text-left p-4">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filteredKategoris.map((kategori) => (
                  <tr key={kategori.id} className="border-t hover:bg-slate-50">
                    <td className="p-4 font-medium">{kategori.nama}</td>
                    <td className="p-4">{kategori.slug}</td>
                    <td className="p-4">{kategori.deskripsi}</td>
                    <td className="p-4">
                      <div className="flex gap-2">
                        <button onClick={() => router.push(`/super-admin/kategori/edit/${kategori.id}`)} className="btn-secondary p-2">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDelete(kategori.id)} className="btn-danger p-2">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Tambah Kategori</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="label">Nama</label>
                <input type="text" value={formData.nama} onChange={(e) => setFormData({...formData, nama: e.target.value, slug: e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '-')})} className="input" required />
              </div>
              <div>
                <label className="label">Slug</label>
                <input type="text" value={formData.slug} onChange={(e) => setFormData({...formData, slug: e.target.value})} className="input" required />
              </div>
              <div>
                <label className="label">Deskripsi</label>
                <textarea value={formData.deskripsi} onChange={(e) => setFormData({...formData, deskripsi: e.target.value})} className="input" rows={2} />
              </div>
              <div className="flex gap-4 justify-end">
                <button type="button" onClick={() => setShowModal(false)} className="btn-secondary">Batal</button>
                <button type="submit" disabled={saving} className="btn-primary">
                  {saving ? 'Menyimpan...' : 'Simpan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

