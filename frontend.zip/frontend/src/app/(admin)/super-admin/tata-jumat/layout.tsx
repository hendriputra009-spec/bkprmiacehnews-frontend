export default function TataJumatLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
