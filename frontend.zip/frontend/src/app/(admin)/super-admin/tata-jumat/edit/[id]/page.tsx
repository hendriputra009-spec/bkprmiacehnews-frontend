'use client';

import dynamic from 'next/dynamic';
import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { ArrowLeft, Save } from 'lucide-react';

const ReactQuill = dynamic(() => import('react-quill'), { ssr: false });
import 'react-quill/dist/quill.snow.css';

export default function EditTataJumatPage() {
  const router = useRouter();
  const { id } = useParams();
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [dpds, setDpds] = useState<any[]>([]);
  const [kabupatens, setKabupatens] = useState<any[]>([]);
  const [formData, setFormData] = useState({
    dpd_id: '',
    kabupaten_id: '',
    kabupaten: '',
    tanggal_masehi: '',
    tanggal_hijriyah: '',
    file_type: 'image' as 'image' | 'document' | 'text',
    text_content: '',
    status: 'draft' as 'draft' | 'pending' | 'published',
  });
  const [file, setFile] = useState<File | null>(null);
  const [existingFile, setExistingFile] = useState<string | null>(null);

  useEffect(() => {
    fetchDpds();
    fetchKabupatens();
  }, []);

  // The user can choose the DPD manually, so we don't automatically populate it from kabupaten.

  useEffect(() => {
    if (id) {
      fetchData();
    }
  }, [id]);

  const fetchDpds = async () => {
    try {
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/dpd`);
      const data = await res.json();
      if (data.data) setDpds(data.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchKabupatens = async () => {
    try {
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/kabupaten`);
      const data = await res.json();
      if (data.data) setKabupatens(data.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchData = async () => {
    try {
      setInitialLoading(true);
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/tata-jumat/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await res.json();
      if (data?.data) {
        const item = data.data;
        setFormData({
          dpd_id: String(item.dpd_id),
          kabupaten_id: item.kabupaten_id ? String(item.kabupaten_id) : '',
          kabupaten: item.kabupaten ?? item.dpd?.nama_kabupaten ?? '',
          tanggal_masehi: item.tanggal_masehi ?? '',
          tanggal_hijriyah: item.tanggal_hijriyah ?? '',
          file_type: item.file_type ?? 'image',
          text_content: item.text_content ?? '',
          status: item.status ?? 'draft',
        });
        setExistingFile(item.file ?? null);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setInitialLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFile(e.target.files?.[0] ?? null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

      const body = new FormData();
      body.append('_method', 'PUT');
      body.append('dpd_id', formData.dpd_id);
      body.append('kabupaten_id', formData.kabupaten_id);
      body.append('kabupaten', formData.kabupaten);
      body.append('tanggal_masehi', formData.tanggal_masehi);
      body.append('tanggal_hijriyah', formData.tanggal_hijriyah);
      body.append('file_type', formData.file_type);
      body.append('status', formData.status);

      if (formData.file_type === 'text') {
        body.append('text_content', formData.text_content);
      }

      if (file && formData.file_type !== 'text') {
        body.append('file', file);
      }

      const res = await fetch(`${API_URL}/admin/tata-jumat/${id}`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body,
      });

      if (res.ok) {
        router.push('/super-admin/tata-jumat');
      } else {
        const error = await res.json().catch(() => null);
        alert(error?.message || 'Gagal memperbarui data');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Terjadi kesalahan');
    } finally {
      setLoading(false);
    }
  };

  const selectedDpd = dpds.find(d => d.id === Number(formData.dpd_id));

  if (initialLoading) {
    return (
      <div className="text-center py-16">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 hover:bg-slate-100 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-bold">Edit Tata Laksana</h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card p-6">
          <h2 className="font-semibold mb-4">Informasi Tata Laksana</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="label">Kabupaten</label>
              <select name="kabupaten_id" value={formData.kabupaten_id} onChange={handleChange} className="input" required>
                <option value="">Pilih Kabupaten</option>
                {kabupatens.map(k => (
                  <option key={k.id} value={k.id}>{k.nama_kabupaten}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">DPD</label>
              <select name="dpd_id" value={formData.dpd_id} onChange={handleChange} className="input" required>
                <option value="">Pilih DPD</option>
                {dpds.map(d => (
                  <option key={d.id} value={d.id}>{d.nama_kabupaten}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Tanggal Masehi</label>
              <input type="date" name="tanggal_masehi" value={formData.tanggal_masehi} onChange={handleChange} className="input" required />
            </div>
            <div>
              <label className="label">Tanggal Hijriyah</label>
              <input type="text" name="tanggal_hijriyah" value={formData.tanggal_hijriyah} onChange={handleChange} className="input" placeholder="10 Rajab 1446" />
            </div>

            <div>
              <label className="label">Tipe File</label>
              <select name="file_type" value={formData.file_type} onChange={handleChange} className="input">
                <option value="image">Image</option>
                <option value="document">Document</option>
                <option value="text">Text</option>
              </select>
            </div>
            <div>
              <label className="label">Status</label>
              <select name="status" value={formData.status} onChange={handleChange} className="input">
                <option value="draft">Draft</option>
                <option value="pending">Pending</option>
                <option value="published">Published</option>
              </select>
            </div>

            {formData.file_type === 'image' && (
              <div className="md:col-span-2">
                <label className="label">Upload Gambar</label>
                <input type="file" accept="image/png,image/jpeg" onChange={handleFileChange} className="input" />
                {existingFile && !file && (
                  <p className="text-sm text-slate-500 mt-2">File saat ini: <a href={`${process.env.NEXT_PUBLIC_API_URL}/storage/${existingFile}`} target="_blank" rel="noreferrer" className="text-primary underline">Lihat</a></p>
                )}
              </div>
            )}

            {formData.file_type === 'document' && (
              <div className="md:col-span-2">
                <label className="label">Upload Dokumen</label>
                <input type="file" accept=".pdf,.doc,.docx" onChange={handleFileChange} className="input" />
                {existingFile && !file && (
                  <p className="text-sm text-slate-500 mt-2">File saat ini: <a href={`${process.env.NEXT_PUBLIC_API_URL}/storage/${existingFile}`} target="_blank" rel="noreferrer" className="text-primary underline">Lihat</a></p>
                )}
              </div>
            )}

            {formData.file_type === 'text' && (
              <div className="md:col-span-2">
                <label className="label">Konten</label>
                <ReactQuill value={formData.text_content} onChange={(value) => setFormData(prev => ({ ...prev, text_content: value }))} />
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-4">
          <button type="button" onClick={() => router.back()} className="btn-secondary">Batal</button>
          <button type="submit" disabled={loading} className="btn-primary flex items-center gap-2">
            {loading ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <Save className="w-5 h-5" />}
            Simpan
          </button>
        </div>
      </form>
    </div>
  );
}
