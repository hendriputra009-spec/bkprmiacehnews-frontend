'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Plus, Search, Edit, Trash2, Calendar } from 'lucide-react';

export default function TataJumatAdminPage() {
  const router = useRouter();
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [dpds, setDpds] = useState<any[]>([]);
  const [kabupatens, setKabupatens] = useState<any[]>([]);

  useEffect(() => {
    fetchData();
    fetchDpds();
    fetchKabupatens();
  }, []);

  const fetchData = async () => {
    try {
      setError(null);
      setLoading(true);

      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const headers: Record<string, string> = { Accept: 'application/json' };
      if (token) headers.Authorization = `Bearer ${token}`;

      const res = await fetch(`${API_URL}/admin/tata-jumat`, { headers });

      if (!res.ok) {
        if (res.status === 401) {
          setError('Sesi tidak valid. Anda akan diarahkan ke halaman login.');
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          router.push('/login');
          return;
        }

        const errText = await res.text();
        setError(`Gagal memuat data: ${res.status} ${res.statusText} - ${errText}`);
        setData([]);
        return;
      }

      const result = await res.json();
      console.log('Tata Jumat response:', result);

      // Normalize response shape (Laravel pagination, plain array, etc.)
      const entries =
        Array.isArray(result?.data?.data)
          ? result.data.data
          : Array.isArray(result?.data)
          ? result.data
          : Array.isArray(result)
          ? result
          : [];

      setData(entries);
    } catch (error) {
      console.error('Error:', error);
      setError('Terjadi kesalahan saat memuat data. Periksa konsol untuk detail.');
      setData([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchDpds = async () => {
    try {
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/dpd`);
      const result = await res.json();
      if (result.data) setDpds(result.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchKabupatens = async () => {
    try {
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/kabupaten`);
      const result = await res.json();
      if (result.data) setKabupatens(result.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Yakin hapus data ini?')) return;
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/tata-jumat/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setData(data.filter(d => d.id !== id));
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const getDpdName = (dpdId: number) => {
    const dpd = dpds.find(d => d.id === dpdId);
    return dpd?.nama_kabupaten || 'Unknown';
  };

  const getKabupatenName = (kabupatenId?: number) => {
    if (!kabupatenId) return null;
    const kab = kabupatens.find(k => k.id === kabupatenId);
    return kab?.nama_kabupaten || null;
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return '-';
    try {
      // Handle ISO format like "2026-03-11T00:00:00.000000Z"
      const date = new Date(dateString);
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    } catch {
      return dateString;
    }
  };

  const filteredData = data.filter(d => {
    const kabupaten = d.kabupaten || getKabupatenName(d.kabupaten_id) || getDpdName(d.dpd_id);
    const searchLower = search.toLowerCase();
    const kabupatenMatch = kabupaten ? kabupaten.toLowerCase().includes(searchLower) : false;
    const tanggalMatch = d.tanggal_masehi ? d.tanggal_masehi.toLowerCase().includes(searchLower) : false;
    return kabupatenMatch || tanggalMatch;
  });

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Kelola Tata Jumat</h1>
        <button onClick={() => router.push('/super-admin/tata-jumat/create')} className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" /> Tambah Tata Jumat
        </button>
      </div>

      <div className="card">
        <div className="p-4 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input type="text" placeholder="Cari..." value={search} onChange={(e) => setSearch(e.target.value)} className="input pl-10" />
          </div>
        </div>

        {error && (
          <div className="p-4 text-sm text-red-600 bg-red-50 border border-red-200 rounded-xl mb-4">
            {error}
          </div>
        )}

        {loading ? (
          <div className="p-8 text-center">
            <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          </div>
        ) : filteredData.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <Calendar className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Belum ada data</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="text-left p-4">Tanggal</th>
                  <th className="text-left p-4">Kabupaten</th>
                  <th className="text-left p-4">Tipe</th>
                  <th className="text-left p-4">Status</th>
                  <th className="text-left p-4">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filteredData.map((item) => {
                  const kabupaten = item.kabupaten || getKabupatenName(item.kabupaten_id) || getDpdName(item.dpd_id);
                  return (
                    <tr key={item.id} className="border-t hover:bg-slate-50">
                      <td className="p-4">{formatDate(item.tanggal_masehi)}</td>
                      <td className="p-4">{kabupaten}</td>
                      <td className="p-4 capitalize">{item.file_type || 'unknown'}</td>
                      <td className="p-4">
                        <span className={`px-2 py-1 text-xs rounded-lg ${item.status === 'published' ? 'bg-green-500 text-white' : item.status === 'pending' ? 'bg-yellow-500 text-white' : 'bg-gray-500 text-white'}`}>
                          {item.status}
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="flex gap-2">
                          <button onClick={() => router.push(`/super-admin/tata-jumat/edit/${item.id}`)} className="btn-secondary p-2">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button onClick={() => handleDelete(item.id)} className="btn-danger p-2">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

