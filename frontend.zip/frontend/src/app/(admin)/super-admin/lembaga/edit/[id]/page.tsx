'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Save } from 'lucide-react';

const getBaseUrl = () => {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
    return new URL(apiUrl).origin;
  } catch {
    return 'http://localhost:8000';
  }
};

export default function EditLembagaPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const { id } = params;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [logo, setLogo] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [formData, setFormData] = useState({
    nama: '',
    slug: '',
    deskripsi: '',
    status: 'aktif',
  });

  const generateSlug = (text: string) =>
    text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

  useEffect(() => {
    const fetchLembaga = async () => {
      try {
        setError(null);
        const token = localStorage.getItem('token');
        if (!token) {
          setError('Silakan login terlebih dahulu.');
          return;
        }

        const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
        const res = await fetch(`${API_URL}/admin/lembaga/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: 'application/json',
          },
        });

        if (!res.ok) {
          const body = await res.text();
          setError(`Gagal memuat lembaga: ${res.status} ${res.statusText} - ${body}`);
          return;
        }

        const data = await res.json();
        const lembaga = data?.data ?? data?.lembaga ?? data;
        if (!lembaga) {
          setError('Data lembaga tidak ditemukan.');
          return;
        }

        setFormData({
          nama: lembaga.nama ?? '',
          slug: lembaga.slug ?? '',
          deskripsi: lembaga.deskripsi ?? '',
          status: lembaga.status ?? 'aktif',
        });

        if (lembaga.logo) {
          setPreview(`${getBaseUrl()}/storage/${lembaga.logo}`);
        }
      } catch (err) {
        console.error(err);
        setError('Terjadi kesalahan saat memuat data lembaga.');
      } finally {
        setLoading(false);
      }
    };

    fetchLembaga();
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const next = { ...prev, [name]: value };
      if (name === 'nama') {
        next.slug = generateSlug(value);
      }
      return next;
    });
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLogo(file);

    const reader = new FileReader();
    reader.onloadend = () => setPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const token = localStorage.getItem('token');
    if (!token) {
      alert('Silakan login terlebih dahulu');
      setSaving(false);
      return;
    }

    try {
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const payload = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        payload.append(key, String(value ?? ''));
      });
      if (logo) payload.append('logo', logo);

      // Laravel generally expects multipart updates via POST + _method=PUT
      payload.append('_method', 'PUT');

      const res = await fetch(`${API_URL}/admin/lembaga/${id}`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/json',
        },
        body: payload,
      });

      const data = await res.json();
      if (!res.ok) {
        alert('Gagal memperbarui lembaga: ' + (data?.message || data?.error || res.statusText));
        return;
      }

      router.push('/super-admin/lembaga');
    } catch (err: any) {
      console.error(err);
      alert('Terjadi kesalahan saat menyimpan.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 hover:bg-slate-100 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-bold">Edit Lembaga</h1>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-600">
          {error}
        </div>
      )}

      {loading ? (
        <div className="card p-8 text-center">
          <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card p-6">
              <h2 className="font-semibold mb-4">Informasi Lembaga</h2>
              <div className="space-y-4">
                <div>
                  <label className="label">
                    Nama Lembaga <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="nama"
                    value={formData.nama}
                    onChange={handleChange}
                    className="input"
                    placeholder="Contoh: Remaja Masjid"
                    required
                  />
                </div>
                <div>
                  <label className="label">Slug</label>
                  <input
                    type="text"
                    name="slug"
                    value={formData.slug}
                    onChange={handleChange}
                    className="input"
                    placeholder="remaja-masjid"
                  />
                </div>
                <div>
                  <label className="label">Deskripsi</label>
                  <textarea
                    name="deskripsi"
                    value={formData.deskripsi}
                    onChange={handleChange}
                    className="input"
                    rows={4}
                    placeholder="Deskripsi lembaga..."
                  />
                </div>
                <div>
                  <label className="label">Status</label>
                  <select
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    className="input"
                  >
                    <option value="aktif">Aktif</option>
                    <option value="nonaktif">Nonaktif</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="card p-6">
              <h2 className="font-semibold mb-4">Logo Lembaga</h2>
              <div>
                <label className="label">Upload Logo</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoChange}
                  className="input file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-primary file:text-white file:cursor-pointer"
                />
                <p className="text-xs text-slate-500 mt-1">Format: JPG, PNG. Max 2MB</p>
              </div>

              {preview && (
                <div className="mt-4">
                  <img
                    src={preview}
                    alt="Preview Logo"
                    className="max-w-full h-48 object-contain rounded-xl bg-slate-50"
                  />
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-end gap-4">
            <button type="button" onClick={() => router.back()} className="btn-secondary">
              Batal
            </button>
            <button type="submit" disabled={saving} className="btn-primary flex items-center gap-2">
              {saving ? (
                <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
              ) : (
                <Save className="w-5 h-5" />
              )}
              Simpan
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
