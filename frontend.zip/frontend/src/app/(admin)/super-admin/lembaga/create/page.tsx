'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Save } from 'lucide-react';

export default function CreateLembagaPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [logo, setLogo] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [formData, setFormData] = useState({
    nama: '',
    slug: '',
    deskripsi: '',
    status: 'aktif'
  });

  const generateSlug = (text: string) => {
    return text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const newData = { ...prev, [name]: value };
      if (name === 'nama') {
        newData.slug = generateSlug(value);
      }
      return newData;
    });
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLogo(file);
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const token = localStorage.getItem('token');
    const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

    if (!token) {
      alert('Silakan login terlebih dahulu');
      setLoading(false);
      return;
    }

    try {
      const formDataToSend = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        formDataToSend.append(key, value);
      });
      if (logo) {
        formDataToSend.append('logo', logo);
      }

      const res = await fetch(`${API_URL}/admin/lembaga`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formDataToSend,
      });

      const data = await res.json();
      console.log('Response:', data);

      if (res.ok) {
        router.push('/super-admin/lembaga');
      } else {
        alert('Gagal membuat lembaga: ' + (data.message || data.error || 'Unknown error'));
      }
    } catch (error: any) {
      console.error('Error:', error);
      alert('Terjadi kesalahan: ' + (error.message || 'Cek koneksi backend'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 hover:bg-slate-100 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-bold">Tambah Lembaga</h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card p-6">
            <h2 className="font-semibold mb-4">Informasi Lembaga</h2>
            <div className="space-y-4">
              <div>
                <label className="label">Nama Lembaga <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  name="nama"
                  value={formData.nama}
                  onChange={handleChange}
                  className="input"
                  placeholder="Contoh: Remaja Masjid"
                  required
                />
              </div>
              <div>
                <label className="label">Slug</label>
                <input
                  type="text"
                  name="slug"
                  value={formData.slug}
                  onChange={handleChange}
                  className="input"
                  placeholder="remaja-masjid"
                />
              </div>
              <div>
                <label className="label">Deskripsi</label>
                <textarea
                  name="deskripsi"
                  value={formData.deskripsi}
                  onChange={handleChange}
                  className="input"
                  rows={4}
                  placeholder="Deskripsi lembaga..."
                />
              </div>
              <div>
                <label className="label">Status</label>
                <select name="status" value={formData.status} onChange={handleChange} className="input">
                  <option value="aktif">Aktif</option>
                  <option value="nonaktif">Nonaktif</option>
                </select>
              </div>
            </div>
          </div>

          <div className="card p-6">
            <h2 className="font-semibold mb-4">Logo Lembaga</h2>
            <div>
              <label className="label">Upload Logo</label>
              <input
                type="file"
                accept="image/*"
                onChange={handleLogoChange}
                className="input file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-primary file:text-white file:cursor-pointer"
              />
              <p className="text-xs text-slate-500 mt-1">Format: JPG, PNG. Max 2MB</p>
            </div>
            {preview && (
              <div className="mt-4">
                <img src={preview} alt="Preview Logo" className="max-w-full h-48 object-contain rounded-xl bg-slate-50" />
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-4">
          <button type="button" onClick={() => router.back()} className="btn-secondary">
            Batal
          </button>
          <button type="submit" disabled={loading} className="btn-primary flex items-center gap-2">
            {loading ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <Save className="w-5 h-5" />}
            Simpan
          </button>
        </div>
      </form>
    </div>
  );
}

