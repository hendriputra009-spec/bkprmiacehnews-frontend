export default function LembagaLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
