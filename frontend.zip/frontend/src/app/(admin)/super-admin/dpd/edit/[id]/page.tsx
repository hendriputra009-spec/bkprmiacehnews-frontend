'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { ArrowLeft, Save, Trash2, Upload } from 'lucide-react';

export default function EditDpdPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id;
  const [loading, setLoading] = useState(false);
  const [loadingData, setLoadingData] = useState(true);
  const [formData, setFormData] = useState({
    nama_kabupaten: '',
    slug: '',
    sk_dpd: '',
    sk_dpd_file: null as string | File | null,
    alamat: '',
    telepon: '',
    email: '',
    struktur_organisasi: '',
    profil_mpd_bkprmi: '',
    logo: null as string | File | null,
    bagan_pengurus: null as string | File | null,
    foto_sekretariat: null as string | File | null,
    status: 'aktif'
  });

  useEffect(() => {
    fetchDpd();
  }, [id]);

  const fetchDpd = async () => {
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/dpd/${id}`, {
        headers: {
          'Accept': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (data.data) {
        setFormData({
          nama_kabupaten: data.data.nama_kabupaten || '',
          slug: data.data.slug || '',
          sk_dpd: data.data.sk_dpd || '',
          sk_dpd_file: data.data.sk_dpd_file || null,
          alamat: data.data.alamat || '',
          telepon: data.data.telepon || '',
          email: data.data.email || '',
          struktur_organisasi: data.data.struktur_organisasi || '',
          profil_mpd_bkprmi: data.data.profil_mpd_bkprmi || '',
          logo: data.data.logo || null,
          bagan_pengurus: data.data.bagan_pengurus || null,
          foto_sekretariat: data.data.foto_sekretariat || null,
          status: data.data.status || 'aktif'
        });
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoadingData(false);
    }
  };

  const generateSlug = (text: string) => {
    return text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  };

  const BACKEND_ORIGIN = (process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1').replace(/\/api\/v1\/?$/, '');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type, files } = e.target as HTMLInputElement;

    setFormData(prev => {
      const newData = {
        ...prev,
        [name]: type === 'file' ? (files?.[0] ?? null) : value,
      };

      if (name === 'nama_kabupaten') {
        newData.slug = generateSlug(value);
      }

      return newData;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

      const body = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        if (value === null || value === undefined) return;
        if (value instanceof File) {
          body.append(key, value);
        } else {
          body.append(key, String(value));
        }
      });
      // Laravel requires _method=PUT for multipart/form-data updates
      body.append('_method', 'PUT');

      const res = await fetch(`${API_URL}/admin/dpd/${id}`, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body,
      });

      if (res.ok) {
        router.push('/super-admin/dpd');
      } else {
        alert('Gagal update DPD');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Terjadi kesalahan');
    } finally {
      setLoading(false);
    }
  };

  if (loadingData) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 hover:bg-slate-100 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-bold">Edit DPD</h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card p-6">
          <h2 className="font-semibold mb-4">Data DPD</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="label">Nama Kabupaten/Kota</label>
              <input
                type="text"
                name="nama_kabupaten"
                value={formData.nama_kabupaten}
                onChange={handleChange}
                className="input"
                required
              />
            </div>
            <div>
              <label className="label">Slug</label>
              <input
                type="text"
                name="slug"
                value={formData.slug}
                onChange={handleChange}
                className="input"
                required
              />
            </div>
            <div>
              <label className="label">SK DPD (Nomor)</label>
              <input
                type="text"
                name="sk_dpd"
                value={formData.sk_dpd}
                onChange={handleChange}
                className="input"
              />
              <p className="text-sm text-slate-500 mt-1">Nomor SK (masih bisa diisi walaupun file juga diunggah).</p>
            </div>
            <div>
              <label className="label">Email</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="input"
              />
            </div>
            <div>
              <label className="label">Telepon</label>
              <input
                type="text"
                name="telepon"
                value={formData.telepon}
                onChange={handleChange}
                className="input"
              />
            </div>
            <div>
              <label className="label">Status</label>
              <select name="status" value={formData.status} onChange={handleChange} className="input">
                <option value="aktif">Aktif</option>
                <option value="nonaktif">Nonaktif</option>
              </select>
            </div>
            <div className="md:col-span-2">
              <label className="label">Alamat</label>
              <textarea
                name="alamat"
                value={formData.alamat}
                onChange={handleChange}
                className="input"
                rows={3}
              />
            </div>
            <div className="md:col-span-2">
              <label className="label">Struktur Organisasi</label>
              <textarea
                name="struktur_organisasi"
                value={formData.struktur_organisasi}
                onChange={handleChange}
                className="input"
                rows={4}
              />
            </div>
            <div className="md:col-span-2">
              <label className="label">Profil MPD BKPRMI</label>
              <textarea
                name="profil_mpd_bkprmi"
                value={formData.profil_mpd_bkprmi}
                onChange={handleChange}
                className="input"
                rows={4}
              />
            </div>
            <div>
              <label className="label">Logo DPD</label>
              <input
                type="file"
                name="logo"
                accept="image/*"
                onChange={handleChange}
                className="input"
              />
              {formData.logo && typeof formData.logo === 'string' && (
                <p className="text-sm text-slate-500 mt-1">
                  Saat ini: <a href={`${BACKEND_ORIGIN}/storage/${formData.logo}`} target="_blank" rel="noreferrer" className="text-primary underline">Lihat logo</a>
                </p>
              )}
            </div>
            <div>
              <label className="label">Bagan Pengurus</label>
              <input
                type="file"
                name="bagan_pengurus"
                accept="image/*"
                onChange={handleChange}
                className="input"
              />
              {formData.bagan_pengurus && typeof formData.bagan_pengurus === 'string' && (
                <p className="text-sm text-slate-500 mt-1">
                  Saat ini: <a href={`${BACKEND_ORIGIN}/storage/${formData.bagan_pengurus}`} target="_blank" rel="noreferrer" className="text-primary underline">Lihat gambar</a>
                </p>
              )}
              <p className="text-sm text-slate-500 mt-1">Maksimum 2MB. (PNG/JPG)</p>
            </div>
            <div>
              <label className="label">SK DPD (PDF/Word)</label>
              <input
                type="file"
                name="sk_dpd_file"
                accept=".pdf,.doc,.docx"
                onChange={handleChange}
                className="input"
              />
              {formData.sk_dpd_file && typeof formData.sk_dpd_file === 'string' && (
                <p className="text-sm text-slate-500 mt-1">
                  Saat ini: <a href={`${BACKEND_ORIGIN}/storage/${formData.sk_dpd_file}`} target="_blank" rel="noreferrer" className="text-primary underline">Unduh file</a>
                </p>
              )}
              <p className="text-sm text-slate-500 mt-1">Maksimum 2MB.</p>
            </div>
            <div>
              <label className="label">Foto Sekretariat</label>
              <input
                type="file"
                name="foto_sekretariat"
                accept="image/*"
                onChange={handleChange}
                className="input"
              />
              {formData.foto_sekretariat && typeof formData.foto_sekretariat === 'string' && (
                <p className="text-sm text-slate-500 mt-1">
                  Saat ini: <a href={`${BACKEND_ORIGIN}/storage/${formData.foto_sekretariat}`} target="_blank" rel="noreferrer" className="text-primary underline">Lihat foto</a>
                </p>
              )}
              <p className="text-sm text-slate-500 mt-1">Maksimum 2MB.</p>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-4">
          <button type="button" onClick={() => router.back()} className="btn-secondary">
            Batal
          </button>
          <button type="submit" disabled={loading} className="btn-primary flex items-center gap-2">
            {loading ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <Save className="w-5 h-5" />}
            Simpan Perubahan
          </button>
        </div>
      </form>
    </div>
  );
}

