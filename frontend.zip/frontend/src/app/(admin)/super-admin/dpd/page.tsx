'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Plus, Search, Edit, Trash2, Building, ChevronLeft, ChevronRight } from 'lucide-react';

export default function DpdAdminPage() {
  const router = useRouter();
  const [dpds, setDpds] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalRecords, setTotalRecords] = useState(0);
  const perPage = 15;

  useEffect(() => {
    fetchDpds(currentPage);
  }, [currentPage]);

  const fetchDpds = async (page: number = 1) => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/dpd?page=${page}&per_page=${perPage}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      
      // Handle pagination response
      if (data.data) {
        setDpds(data.data.data || []);
        setTotalPages(data.data.last_page || 1);
        setTotalRecords(data.data.total || 0);
      } else if (Array.isArray(data)) {
        setDpds(data);
        setTotalPages(1);
        setTotalRecords(data.length);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Yakin hapus DPD ini?')) return;
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/dpd/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        // Refresh current page after delete
        fetchDpds(currentPage);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  // Client-side search filtering
  const filteredDpds = dpds.filter(d => 
    d.nama_kabupaten?.toLowerCase().includes(search.toLowerCase())
  );

  // Calculate showing records text
  const getShowingText = () => {
    if (totalRecords === 0) return 'Tidak ada data';
    const start = (currentPage - 1) * perPage + 1;
    const end = Math.min(currentPage * perPage, totalRecords);
    return `Menampilkan ${start}-${end} dari ${totalRecords} data`;
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Kelola DPD (Kabupaten/Kota)</h1>
        <button onClick={() => router.push('/super-admin/dpd/create')} className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" /> Tambah DPD
        </button>
      </div>

      <div className="card">
        <div className="p-4 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Cari DPD..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="input pl-10"
            />
          </div>
        </div>

        {loading ? (
          <div className="p-8 text-center">
            <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          </div>
        ) : filteredDpds.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <Building className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Belum ada DPD</p>
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="text-left p-4">Nama Kabupaten/Kota</th>
                    <th className="text-left p-4">Email</th>
                    <th className="text-left p-4">Telepon</th>
                    <th className="text-left p-4">Status</th>
                    <th className="text-left p-4">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredDpds.map((dpd) => (
                    <tr key={dpd.id} className="border-t hover:bg-slate-50">
                      <td className="p-4 font-medium">{dpd.nama_kabupaten}</td>
                      <td className="p-4">{dpd.email}</td>
                      <td className="p-4">{dpd.telepon}</td>
                      <td className="p-4">
                        <span className={`px-2 py-1 text-xs rounded-lg ${dpd.status === 'aktif' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`}>
                          {dpd.status}
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="flex gap-2">
                          <button onClick={() => router.push(`/super-admin/dpd/edit/${dpd.id}`)} className="btn-secondary p-2">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button onClick={() => handleDelete(dpd.id)} className="btn-danger p-2">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="p-4 border-t flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-sm text-slate-500">
                  {getShowingText()}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                    className="flex items-center gap-1 px-3 py-2 text-sm font-medium text-slate-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    Sebelumnya
                  </button>
                  
                  {/* Page Numbers */}
                  <div className="flex items-center gap-1">
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                      <button
                        key={page}
                        onClick={() => handlePageChange(page)}
                        className={`w-10 h-10 text-sm font-medium rounded-lg ${
                          currentPage === page
                            ? 'bg-primary text-white'
                            : 'text-slate-600 bg-white border border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        {page}
                      </button>
                    ))}
                  </div>
                  
                  <button
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                    className="flex items-center gap-1 px-3 py-2 text-sm font-medium text-slate-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Berikutnya
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

