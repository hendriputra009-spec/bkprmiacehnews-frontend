'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Save, Building } from 'lucide-react';

// Daftar 23 Kabupaten/Kota di Aceh
const kabupatenList = [
  'Aceh Barat',
  'Aceh Barat Daya',
  'Aceh Besar',
  'Aceh Jaya',
  'Aceh Selatan',
  'Aceh Singkil',
  'Aceh Tamiang',
  'Aceh Tengah',
  'Aceh Tenggara',
  'Aceh Timur',
  'Aceh Utara',
  'Bener Meriah',
  'Bireuen',
  'Gayo Lues',
  'Nagan Raya',
  'Pidie',
  'Pidie Jaya',
  'Simeulue',
  'Banda Aceh',
  'Langsa',
  'Lhokseumawe',
  'Sabang',
  'Subulussalam',
];

export default function CreateDpdPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [selectedKabupaten, setSelectedKabupaten] = useState('');
  const [formData, setFormData] = useState({
    nama_kabupaten: '',
    slug: '',
    sk_dpd: '',
    sk_dpd_file: null as File | null,
    alamat: '',
    telepon: '',
    email: '',
    struktur_organisasi: '',
    profil_mpd_bkprmi: '',
    logo: null as File | null,
    bagan_pengurus: null as File | null,
    foto_sekretariat: null as File | null,
    status: 'aktif'
  });

  const generateSlug = (text: string) => {
    return text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  };

  const handleKabupatenChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setSelectedKabupaten(value);
    
    if (value) {
      const slug = generateSlug(value);
      setFormData(prev => ({
        ...prev,
        nama_kabupaten: `DPD Kabupaten ${value}`,
        slug: slug,
        sk_dpd: `SK-BKPRMI/${slug.toUpperCase()}/001`,
        email: `dpd.${slug}@bkprmiaceh.id`
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        nama_kabupaten: '',
        slug: '',
        sk_dpd: '',
        email: ''
      }));
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type, files } = e.target as HTMLInputElement;

    if (type === 'file') {
      setFormData(prev => ({ ...prev, [name]: files?.[0] ?? null }));
      return;
    }

    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const token = localStorage.getItem('token');
    if (!token) {
      alert('Sesi Anda telah berakhir. Silakan login kembali.');
      router.push('/login');
      setLoading(false);
      return;
    }

    try {
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

      const body = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        if (value === null || value === undefined) return;
        if (value instanceof File) {
          body.append(key, value);
        } else {
          body.append(key, String(value));
        }
      });

      const res = await fetch(`${API_URL}/admin/dpd`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json',
        },
        credentials: 'include',
        body,
      });

      if (res.ok) {
        router.push('/super-admin/dpd');
      } else {
        const error = await res.json() as any;
        // Show detailed error message
        if (error?.errors && typeof error.errors === 'object') {
          const errorMessages = Object.entries(error.errors as Record<string, any[]>)
            .map(([field, messages]) => `${field}: ${Array.isArray(messages) ? messages.join(', ') : String(messages)}`)
            .join('\n');
          alert('Gagal membuat DPD:\n' + errorMessages);
        } else {
          alert('Gagal membuat DPD: ' + (error?.message || 'Unknown error'));
        }
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Terjadi kesalahan');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 hover:bg-slate-100 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-bold">Tambah DPD</h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card p-6">
          <h2 className="font-semibold mb-4">Pilih Wilayah</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="label">Provinsi</label>
              <input type="text" value="Aceh" disabled className="input bg-slate-100" />
            </div>
            <div>
              <label className="label">Kabupaten/Kota <span className="text-red-500">*</span></label>
              <select 
                value={selectedKabupaten} 
                onChange={handleKabupatenChange}
                className="input"
                required
              >
                <option value="">Pilih Kabupaten/Kota</option>
                {kabupatenList.map(kab => (
                  <option key={kab} value={kab}>{kab}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="card p-6">
          <h2 className="font-semibold mb-4">Informasi DPD (Otomatis)</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="label">Nama DPD</label>
              <input 
                type="text" 
                name="nama_kabupaten" 
                value={formData.nama_kabupaten} 
                onChange={handleChange} 
                className="input" 
                placeholder="DPD Kabupaten Aceh Tengah"
                required 
              />
            </div>
            <div>
              <label className="label">Slug</label>
              <input 
                type="text" 
                name="slug" 
                value={formData.slug} 
                onChange={handleChange} 
                className="input" 
                placeholder="aceh-tengah"
                required 
              />
            </div>
            <div>
              <label className="label">SK DPD (Nomor)</label>
              <input 
                type="text" 
                name="sk_dpd" 
                value={formData.sk_dpd} 
                onChange={handleChange} 
                className="input" 
                placeholder="SK-BKPRMI/ACEH-TENGAH/001"
              />
              <p className="text-sm text-slate-500 mt-1">Nomor SK (masih bisa diisi walaupun file juga diunggah).</p>
            </div>
            <div>
              <label className="label">Email</label>
              <input 
                type="email" 
                name="email" 
                value={formData.email} 
                onChange={handleChange} 
                className="input" 
                placeholder="dpd.aceh-tengah@bkprmiaceh.id"
              />
            </div>
            <div>
              <label className="label">Telepon</label>
              <input 
                type="text" 
                name="telepon" 
                value={formData.telepon} 
                onChange={handleChange} 
                className="input" 
                placeholder="0812-3456-7890"
              />
            </div>
            <div>
              <label className="label">Status</label>
              <select name="status" value={formData.status} onChange={handleChange} className="input">
                <option value="aktif">Aktif</option>
                <option value="nonaktif">Nonaktif</option>
              </select>
            </div>
            <div className="md:col-span-2">
              <label className="label">Alamat</label>
              <textarea 
                name="alamat" 
                value={formData.alamat} 
                onChange={handleChange} 
                className="input" 
                rows={3} 
                placeholder="Alamat kantor DPD..."
              />
            </div>
          </div>
        </div>

        <div className="card p-6">
          <h2 className="font-semibold mb-4">Dokumen & Media</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="label">Struktur Organisasi</label>
              <textarea
                name="struktur_organisasi"
                value={formData.struktur_organisasi}
                onChange={handleChange}
                className="input"
                rows={4}
                placeholder="Tuliskan struktur organisasi (bisa diketik atau tempel dari dokumen)."
              />
            </div>
            <div className="md:col-span-2">
              <label className="label">Profil MPD BKPRMI</label>
              <textarea
                name="profil_mpd_bkprmi"
                value={formData.profil_mpd_bkprmi}
                onChange={handleChange}
                className="input"
                rows={4}
                placeholder="Profil singkat MPD BKPRMI..."
              />
            </div>
            <div>
              <label className="label">Logo DPD</label>
              <input
                type="file"
                name="logo"
                accept="image/*"
                onChange={handleChange}
                className="input"
              />
            </div>
            <div>
              <label className="label">Bagan Pengurus</label>
              <input
                type="file"
                name="bagan_pengurus"
                accept="image/*"
                onChange={handleChange}
                className="input"
              />
              <p className="text-sm text-slate-500 mt-1">Maksimum 2MB. (PNG/JPG)</p>
            </div>
            <div>
              <label className="label">SK DPD (PDF/Word)</label>
              <input
                type="file"
                name="sk_dpd_file"
                accept=".pdf,.doc,.docx"
                onChange={handleChange}
                className="input"
              />
              <p className="text-sm text-slate-500 mt-1">Maksimum 2MB.</p>
            </div>
            <div>
              <label className="label">Foto Sekretariat</label>
              <input
                type="file"
                name="foto_sekretariat"
                accept="image/*"
                onChange={handleChange}
                className="input"
              />
              <p className="text-sm text-slate-500 mt-1">Maksimum 2MB.</p>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-4">
          <button type="button" onClick={() => router.back()} className="btn-secondary">Batal</button>
          <button type="submit" disabled={loading || !selectedKabupaten} className="btn-primary flex items-center gap-2">
            {loading ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <Save className="w-5 h-5" />}
            Simpan
          </button>
        </div>
      </form>
    </div>
  );
}

