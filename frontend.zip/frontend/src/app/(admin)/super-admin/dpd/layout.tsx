export default function DpdLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
