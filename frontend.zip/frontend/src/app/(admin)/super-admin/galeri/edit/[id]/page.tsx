'use client';

import { useEffect, useRef, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { ArrowLeft, Save, Image as ImageIcon } from 'lucide-react';
import { adminApi } from '@/lib/api';

const getBaseUrl = () => {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
    return new URL(apiUrl).origin;
  } catch {
    return 'http://localhost:8000';
  }
};

const getStorageUrl = (path?: string) => {
  if (!path) return `${getBaseUrl()}/storage/placeholder/berita-placeholder.svg`;
  return `${getBaseUrl()}/storage/${path}`;
};

export default function EditGaleriPage() {
  const router = useRouter();
  const params = useParams();
  const id = Number(params?.id ?? 0);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [gambar, setGambar] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [formData, setFormData] = useState({
    judul: '',
    slug: '',
    deskripsi: '',
    tanggal: '',
    status: 'draft'
  });

  useEffect(() => {
    if (!id) return;
    fetchData();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const res = await adminApi.getAdminGaleri();
      const payload = res.data?.data ?? res.data;
      const items = Array.isArray(payload)
        ? payload
        : Array.isArray(payload?.data)
        ? payload.data
        : [];

      const current = items.find((g: any) => g.id === id);
      if (!current) {
        router.push('/super-admin/galeri');
        return;
      }

      setFormData({
        judul: current.judul || '',
        slug: current.slug || '',
        deskripsi: current.deskripsi || '',
        tanggal: current.tanggal || '',
        status: current.status || 'draft'
      });

      setPreview(getStorageUrl(current.gambar));
    } catch (error) {
      console.error('Error loading galeri:', error);
      router.push('/super-admin/galeri');
    } finally {
      setLoading(false);
    }
  };

  const generateSlug = (text: string) => {
    return text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const next = { ...prev, [name]: value };
      if (name === 'judul') {
        next.slug = generateSlug(value);
      }
      return next;
    });
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setGambar(file);
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id) return;

    setSaving(true);
    try {
      const dataToSend: any = { ...formData };
      if (gambar) dataToSend.gambar = gambar;

      await adminApi.updateGaleri(id, dataToSend);
      router.push('/super-admin/galeri');
    } catch (error) {
      console.error('Error updating galeri:', error);
      alert('Gagal menyimpan perubahan.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-500">Memuat data galeri...</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 hover:bg-slate-100 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-bold">Edit Galeri</h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card p-6">
            <h2 className="font-semibold mb-4">Informasi Galeri</h2>
            <div className="space-y-4">
              <div>
                <label className="label">Judul</label>
                <input type="text" name="judul" value={formData.judul} onChange={handleChange} className="input" required />
              </div>
              <div>
                <label className="label">Slug</label>
                <input type="text" name="slug" value={formData.slug} onChange={handleChange} className="input" required />
              </div>
              <div>
                <label className="label">Deskripsi</label>
                <textarea name="deskripsi" value={formData.deskripsi} onChange={handleChange} className="input" rows={3} />
              </div>
              <div>
                <label className="label">Tanggal</label>
                <input type="date" name="tanggal" value={formData.tanggal} onChange={handleChange} className="input" />
              </div>
              <div>
                <label className="label">Status</label>
                <select name="status" value={formData.status} onChange={handleChange} className="input">
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                </select>
              </div>
            </div>
          </div>

          <div className="card p-6">
            <h2 className="font-semibold mb-4">Gambar</h2>
            <div>
              <label className="label">Upload Gambar</label>
              <input type="file" accept="image/*" onChange={handleImageChange} className="input file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-primary file:text-white file:cursor-pointer" />
            </div>
            {preview && (
              <div className="mt-4">
                <img src={preview} alt="Preview" className="max-w-full h-48 object-cover rounded-xl" />
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-4">
          <button type="button" onClick={() => router.back()} className="btn-secondary">Batal</button>
          <button type="submit" disabled={saving} className="btn-primary flex items-center gap-2">
            {saving ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <Save className="w-5 h-5" />}
            Simpan
          </button>
        </div>
      </form>
    </div>
  );
}
