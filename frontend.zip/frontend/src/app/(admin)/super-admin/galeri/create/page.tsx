'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Save, Image as ImageIcon } from 'lucide-react';

export default function CreateGaleriPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [gambar, setGambar] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [formData, setFormData] = useState({
    judul: '',
    slug: '',
    deskripsi: '',
    tanggal: '',
    status: 'draft'
  });

  const generateSlug = (text: string) => {
    return text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const newData = { ...prev, [name]: value };
      if (name === 'judul') {
        newData.slug = generateSlug(value);
      }
      return newData;
    });
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setGambar(file);
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      
      const formDataToSend = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        formDataToSend.append(key, value);
      });
      if (gambar) {
        formDataToSend.append('gambar', gambar);
      }

      const res = await fetch(`${API_URL}/admin/galeri`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formDataToSend,
      });

      if (res.ok) {
        router.push('/super-admin/galeri');
      } else {
        alert('Gagal membuat galeri');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Terjadi kesalahan');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 hover:bg-slate-100 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-bold">Tambah Galeri</h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card p-6">
            <h2 className="font-semibold mb-4">Informasi Galeri</h2>
            <div className="space-y-4">
              <div>
                <label className="label">Judul</label>
                <input type="text" name="judul" value={formData.judul} onChange={handleChange} className="input" required />
              </div>
              <div>
                <label className="label">Slug</label>
                <input type="text" name="slug" value={formData.slug} onChange={handleChange} className="input" required />
              </div>
              <div>
                <label className="label">Deskripsi</label>
                <textarea name="deskripsi" value={formData.deskripsi} onChange={handleChange} className="input" rows={3} />
              </div>
              <div>
                <label className="label">Tanggal</label>
                <input type="date" name="tanggal" value={formData.tanggal} onChange={handleChange} className="input" />
              </div>
              <div>
                <label className="label">Status</label>
                <select name="status" value={formData.status} onChange={handleChange} className="input">
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                </select>
              </div>
            </div>
          </div>

          <div className="card p-6">
            <h2 className="font-semibold mb-4">Gambar</h2>
            <div>
              <label className="label">Upload Gambar</label>
              <input type="file" accept="image/*" onChange={handleImageChange} className="input file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-primary file:text-white file:cursor-pointer" />
            </div>
            {preview && (
              <div className="mt-4">
                <img src={preview} alt="Preview" className="max-w-full h-48 object-cover rounded-xl" />
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-4">
          <button type="button" onClick={() => router.back()} className="btn-secondary">Batal</button>
          <button type="submit" disabled={loading} className="btn-primary flex items-center gap-2">
            {loading ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <Save className="w-5 h-5" />}
            Simpan
          </button>
        </div>
      </form>
    </div>
  );
}

