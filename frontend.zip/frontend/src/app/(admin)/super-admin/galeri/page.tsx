'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Plus, Search, Edit, Trash2, Image } from 'lucide-react';

const getBaseUrl = () => {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
    return new URL(apiUrl).origin;
  } catch {
    return 'http://localhost:8000';
  }
};

const getStorageUrl = (path?: string) => {
  if (!path) return `${getBaseUrl()}/storage/placeholder/berita-placeholder.svg`;
  return `${getBaseUrl()}/storage/${path}`;
};

// Format date from ISO format to YYYY-MM-DD
const formatDate = (dateString?: string) => {
  if (!dateString) return '-';
  try {
    // Handle ISO format like "2026-03-08T00:00:00.000000Z"
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  } catch {
    return dateString;
  }
};

export default function GaleriAdminPage() {
  const router = useRouter();
  const [galeris, setGaleris] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetchGaleris();
  }, []);

  const fetchGaleris = async () => {
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/galeri`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();

      // API returns paginated data: { success, data: { data: [...] } }
      const responseData = data?.data ?? data;
      const items = Array.isArray(responseData)
        ? responseData
        : Array.isArray(responseData?.data)
        ? responseData.data
        : [];

      setGaleris(items);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Yakin hapus galeri ini?')) return;
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/galeri/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setGaleris(galeris.filter(g => g.id !== id));
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const filteredGaleris = galeris.filter(g => 
    g.judul?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Kelola Galeri</h1>
        <button onClick={() => router.push('/super-admin/galeri/create')} className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" /> Tambah Galeri
        </button>
      </div>

      <div className="card">
        <div className="p-4 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Cari galeri..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="input pl-10"
            />
          </div>
        </div>

        {loading ? (
          <div className="p-8 text-center">
            <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          </div>
        ) : filteredGaleris.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <Image className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Belum ada galeri</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
            {filteredGaleris.map((galeri) => (
              <div key={galeri.id} className="card overflow-hidden">
                <div className="aspect-video bg-slate-100 relative">
                  {galeri.gambar ? (
                    <img src={getStorageUrl(galeri.gambar)} alt={galeri.judul} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Image className="w-12 h-12 text-slate-300" />
                    </div>
                  )}
                  <span className={`absolute top-2 right-2 px-2 py-1 text-xs rounded-lg ${galeri.status === 'published' ? 'bg-green-500 text-white' : 'bg-yellow-500 text-white'}`}>
                    {galeri.status}
                  </span>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold truncate">{galeri.judul}</h3>
                  <p className="text-sm text-slate-500">{formatDate(galeri.tanggal)}</p>
                  <div className="flex gap-2 mt-4">
                    <button onClick={() => router.push(`/super-admin/galeri/edit/${galeri.id}`)} className="btn-secondary flex-1 flex items-center justify-center gap-1 py-2">
                      <Edit className="w-4 h-4" /> Edit
                    </button>
                    <button onClick={() => handleDelete(galeri.id)} className="btn-danger flex-1 flex items-center justify-center gap-1 py-2">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

