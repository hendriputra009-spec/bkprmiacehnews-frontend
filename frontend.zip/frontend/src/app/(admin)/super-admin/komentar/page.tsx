'use client';

import { useState, useEffect } from 'react';
import { Check, X, MessageCircle } from 'lucide-react';

export default function KomentarAdminPage() {
  const [komentars, setKomentars] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchKomentars();
  }, []);

  const fetchKomentars = async () => {
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/komentar`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.komentars) setKomentars(data.komentars);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (id: number) => {
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/komentar/${id}/approve`, {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setKomentars(komentars.map(k => k.id === id ? { ...k, status: 'approved' } : k));
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleReject = async (id: number) => {
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/komentar/${id}/reject`, {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setKomentars(komentars.map(k => k.id === id ? { ...k, status: 'rejected' } : k));
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Yakin hapus komentar ini?')) return;
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/komentar/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setKomentars(komentars.filter(k => k.id !== id));
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const filteredKomentars = komentars.filter(k => filter === 'all' || k.status === filter);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Kelola Komentar</h1>
        <div className="flex gap-2">
          {['all', 'pending', 'approved', 'rejected'].map(f => (
            <button key={f} onClick={() => setFilter(f)} className={`px-4 py-2 rounded-lg text-sm ${filter === f ? 'bg-primary text-white' : 'bg-slate-100 hover:bg-slate-200'}`}>
              {f === 'all' ? 'Semua' : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="card">
        {loading ? (
          <div className="p-8 text-center">
            <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          </div>
        ) : filteredKomentars.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <MessageCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Belum ada komentar</p>
          </div>
        ) : (
          <div className="divide-y">
            {filteredKomentars.map((komentar) => (
              <div key={komentar.id} className="p-4 hover:bg-slate-50">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium">{komentar.nama}</span>
                      <span className={`px-2 py-0.5 text-xs rounded ${komentar.status === 'approved' ? 'bg-green-100 text-green-700' : komentar.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'}`}>
                        {komentar.status}
                      </span>
                    </div>
                    <p className="text-sm text-slate-600">{komentar.komentar}</p>
                    <p className="text-xs text-slate-400 mt-1">{komentar.email}</p>
                  </div>
                  <div className="flex gap-2">
                    {komentar.status === 'pending' && (
                      <>
                        <button onClick={() => handleApprove(komentar.id)} className="p-2 bg-green-500 text-white rounded-lg hover:bg-green-600">
                          <Check className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleReject(komentar.id)} className="p-2 bg-red-500 text-white rounded-lg hover:bg-red-600">
                          <X className="w-4 h-4" />
                        </button>
                      </>
                    )}
                    <button onClick={() => handleDelete(komentar.id)} className="p-2 bg-slate-200 text-slate-600 rounded-lg hover:bg-slate-300">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

