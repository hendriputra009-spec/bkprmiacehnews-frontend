'use client';

import { useState, useEffect, useRef } from 'react';
import { Save, FileText, Upload, X, File, History, Target, Award, BookOpen, AlertCircle } from 'lucide-react';

const PROFIL_TYPES = [
  { key: 'sejarah_bkprmi', label: 'Sejarah BKPRMI', icon: History, description: 'Sejarah berdirinya BKPRMI' },
  { key: 'sejarah_bkprmi_aceh', label: 'Sejarah BKPRMI Aceh', icon: History, description: 'Sejarah BKPRMI di Aceh' },
  { key: 'struktur_organisasi', label: 'Struktur Organisasi', icon: Target, description: 'Struktur organisasi BKPRMI' },
  { key: 'ad_art', label: 'AD/ART', icon: FileText, description: 'Anggaran Dasar / Anggaran Rumah Tangga' },
  { key: 'pedoman_organisasi', label: 'Pedoman Organisasi', icon: BookOpen, description: 'Pedoman organisasi BKPRMI' },
  { key: 'pengakuan_negara', label: 'Pengakuan Negara', icon: Award, description: 'Surat keputusan pengakuan dari pemerintah' },
];

interface Profil {
  id: number;
  jenis: string;
  judul: string;
  konten: string | null;
  file: string | null;
  created_at: string;
  updated_at: string;
}

export default function ProfilAdminPage() {
  const [profils, setProfils] = useState<Profil[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [formData, setFormData] = useState<{ judul: string; konten: string; file: File | null; existingFile: string | null }>({
    judul: '',
    konten: '',
    file: null,
    existingFile: null,
  });
  const [saving, setSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchProfils();
  }, []);

  const fetchProfils = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/profil`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      // Handle both paginated and non-paginated responses
      if (data.data) {
        const profilData = Array.isArray(data.data.data) ? data.data.data : data.data;
        setProfils(profilData);
      } else if (Array.isArray(data)) {
        setProfils(data);
      }
    } catch (error) {
      console.error('Error fetching profils:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (key: string, profil?: Profil) => {
    setEditingKey(key);
    if (profil) {
      setFormData({
        judul: profil.judul || '',
        konten: profil.konten || '',
        file: null,
        existingFile: profil.file,
      });
    } else {
      // New profil
      setFormData({
        judul: '',
        konten: '',
        file: null,
        existingFile: null,
      });
    }
  };

  const handleCancel = () => {
    setEditingKey(null);
    setFormData({ judul: '', konten: '', file: null, existingFile: null });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setFormData((prev) => ({ ...prev, file }));
  };

  const handleRemoveFile = () => {
    setFormData((prev) => ({ ...prev, file: null }));
  };

  const handleSave = async (jenis: string) => {
    setSaving(true);
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      
      const formDataToSend = new FormData();
      formDataToSend.append('judul', formData.judul);
      formDataToSend.append('konten', formData.konten);
      if (formData.file) {
        formDataToSend.append('file', formData.file);
      }

      const res = await fetch(`${API_URL}/admin/profil/${jenis}`, {
        method: 'POST',
        headers: { 
          'Authorization': `Bearer ${token}`,
        },
        body: formDataToSend,
      });

      if (res.ok) {
        setEditingKey(null);
        fetchProfils();
        alert('Profil berhasil disimpan');
      } else {
        const errorData = await res.json();
        alert('Gagal menyimpan: ' + (errorData.message || 'Terjadi kesalahan'));
      }
    } catch (error) {
      console.error('Error saving profil:', error);
      alert('Terjadi kesalahan saat menyimpan');
    } finally {
      setSaving(false);
    }
  };

  const getProfilByJenis = (jenis: string) => {
    return profils.find(p => p.jenis === jenis);
  };

  const getStorageUrl = (path: string) => {
    const STORAGE_URL = process.env.NEXT_PUBLIC_STORAGE_URL || 'http://localhost:8000/storage';
    return `${STORAGE_URL}/${path}`;
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Kelola Profil Organisasi</h1>
        <button 
          onClick={fetchProfils} 
          className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors text-sm font-medium"
        >
          Refresh
        </button>
      </div>

      {loading ? (
        <div className="card p-8 text-center">
          <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="mt-2 text-slate-500">Memuat data...</p>
        </div>
      ) : (
        <div className="space-y-6">
          {PROFIL_TYPES.map(({ key, label, icon: Icon, description }) => {
            const profil = getProfilByJenis(key);
            const isEditing = editingKey === key;

            return (
              <div key={key} className="card p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <h2 className="text-lg font-semibold text-slate-900">{label}</h2>
                        <p className="text-sm text-slate-500">{description}</p>
                      </div>
                      <button 
                        onClick={() => handleEdit(key, profil)}
                        className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-700 transition-colors text-sm font-medium"
                      >
                        {profil ? 'Edit' : 'Buat'}
                      </button>
                    </div>

                    {/* Display Mode */}
                    {!isEditing && profil && (
                      <div className="mt-4">
                        {profil.konten ? (
                          <div 
                            className="prose prose-sm max-w-none text-slate-600 line-clamp-3"
                            dangerouslySetInnerHTML={{ __html: profil.konten }}
                          />
                        ) : profil.file ? (
                          <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                            <File className="w-8 h-8 text-primary" />
                            <div className="flex-1">
                              <p className="text-sm font-medium text-slate-700">Dokumen tersedia</p>
                              <p className="text-xs text-slate-500">{profil.file.split('/').pop()}</p>
                            </div>
                            <a 
                              href={getStorageUrl(profil.file)} 
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-3 py-1.5 bg-primary text-white rounded-lg text-sm hover:bg-primary-700"
                            >
                              Lihat
                            </a>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 text-slate-400">
                            <AlertCircle className="w-4 h-4" />
                            <span className="text-sm">Belum ada konten</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Edit Mode */}
                    {isEditing && (
                      <div className="mt-4 space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Judul</label>
                          <input
                            type="text"
                            name="judul"
                            value={formData.judul}
                            onChange={handleChange}
                            className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary"
                            placeholder="Masukkan judul..."
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">
                            Konten {formData.existingFile || formData.file ? '(atau upload file)' : ''}
                          </label>
                          <textarea
                            name="konten"
                            value={formData.konten}
                            onChange={handleChange}
                            rows={6}
                            className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary/20 focus:border-primary"
                            placeholder="Masukkan konten HTML..."
                          />
                          <p className="text-xs text-slate-500 mt-1">Anda dapat menggunakan tag HTML untuk format teks</p>
                        </div>

                        {/* File Upload */}
                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Atau Upload File (PDF, DOC, dll)</label>
                          
                          {/* Current File */}
                          {formData.existingFile && (
                            <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg mb-2">
                              <File className="w-8 h-8 text-primary" />
                              <div className="flex-1">
                                <p className="text-sm font-medium text-slate-700">File saat ini</p>
                                <p className="text-xs text-slate-500 truncate">{formData.existingFile}</p>
                              </div>
                              <button
                                type="button"
                                onClick={() => setFormData(prev => ({ ...prev, existingFile: null }))}
                                className="p-1 text-red-500 hover:bg-red-50 rounded"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          )}

                          {/* New File Selection */}
                          <div className="border-2 border-dashed border-slate-200 rounded-lg p-4">
                            <input
                              ref={fileInputRef}
                              type="file"
                              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                              onChange={handleFileChange}
                              className="hidden"
                              id={`file-${key}`}
                            />
                            {formData.file ? (
                              <div className="flex items-center gap-3">
                                <File className="w-8 h-8 text-green-600" />
                                <div className="flex-1">
                                  <p className="text-sm font-medium text-slate-700">{formData.file.name}</p>
                                  <p className="text-xs text-slate-500">{(formData.file.size / 1024).toFixed(1)} KB</p>
                                </div>
                                <button
                                  type="button"
                                  onClick={handleRemoveFile}
                                  className="p-1 text-red-500 hover:bg-red-50 rounded"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                              </div>
                            ) : (
                              <label
                                htmlFor={`file-${key}`}
                                className="flex flex-col items-center justify-center cursor-pointer py-2"
                              >
                                <Upload className="w-8 h-8 text-slate-400 mb-2" />
                                <span className="text-sm text-slate-600">Klik untuk upload file</span>
                                <span className="text-xs text-slate-400">PDF, DOC, JPG, PNG (max 5MB)</span>
                              </label>
                            )}
                          </div>
                        </div>

                        <div className="flex gap-2 justify-end pt-2">
                          <button
                            onClick={handleCancel}
                            className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors font-medium"
                            disabled={saving}
                          >
                            Batal
                          </button>
                          <button
                            onClick={() => handleSave(key)}
                            className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-700 transition-colors font-medium flex items-center gap-2"
                            disabled={saving}
                          >
                            {saving ? (
                              <>
                                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                Menyimpan...
                              </>
                            ) : (
                              <>
                                <Save className="w-4 h-4" />
                                Simpan
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

