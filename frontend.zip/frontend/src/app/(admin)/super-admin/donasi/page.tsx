'use client';

import { useState, useEffect } from 'react';
import { Check, DollarSign, RefreshCw, Trash2 } from 'lucide-react';

export default function DonasiAdminPage() {
  const [donasis, setDonasis] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchDonasis();
  }, []);

  const fetchDonasis = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/donasi`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      // Handle paginated response - data.data contains the paginated results
      if (data.data) {
        // If paginated, data.data.data contains the array
        const donasis = Array.isArray(data.data.data) ? data.data.data : data.data;
        setDonasis(donasis);
      } else if (Array.isArray(data)) {
        // Direct array response
        setDonasis(data);
      }
    } catch (error) {
      console.error('Error fetching donasis:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleConfirm = async (id: number) => {
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/donasi/${id}/confirm`, {
        method: 'PUT',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      if (res.ok) {
        setDonasis(donasis.map(d => d.id === id ? { ...d, status: 'confirmed' } : d));
      }
    } catch (error) {
      console.error('Error confirming donasi:', error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Apakah Anda yakin ingin menghapus donasi ini?')) {
      return;
    }
    
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/admin/donasi/${id}`, {
        method: 'DELETE',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      if (res.ok) {
        setDonasis(donasis.filter(d => d.id !== id));
      }
    } catch (error) {
      console.error('Error deleting donasi:', error);
      alert('Gagal menghapus donasi');
    }
  };

  const formatRupiah = (amount: number) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(amount);
  };

  const filteredDonasis = donasis.filter(d => filter === 'all' || d.status === filter);
  const totalDonasi = donasis.reduce((sum, d) => sum + (parseFloat(d.nominal) || 0), 0);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Kelola Donasi</h1>
        <button 
          onClick={fetchDonasis} 
          className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          disabled={loading}
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="card p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-slate-500">Total Donasi</p>
              <p className="text-xl font-bold">{formatRupiah(totalDonasi)}</p>
            </div>
          </div>
        </div>
        <div className="card p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-slate-500">Donasi Pending</p>
              <p className="text-xl font-bold">{donasis.filter(d => d.status === 'pending').length}</p>
            </div>
          </div>
        </div>
        <div className="card p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-slate-500">Donasi Dikonfirmasi</p>
              <p className="text-xl font-bold">{donasis.filter(d => d.status === 'confirmed').length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Buttons */}
      <div className="flex gap-2 mb-4">
        {['all', 'pending', 'confirmed'].map(f => (
          <button 
            key={f} 
            onClick={() => setFilter(f)} 
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === f 
                ? 'bg-primary text-white' 
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            {f === 'all' ? 'Semua' : f === 'pending' ? 'Menunggu' : 'Dikonfirmasi'}
          </button>
        ))}
      </div>

      <div className="card">
        {loading ? (
          <div className="p-8 text-center">
            <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
            <p className="mt-2 text-slate-500">Memuat data...</p>
          </div>
        ) : filteredDonasis.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <DollarSign className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Belum ada donasi</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="text-left p-4 font-semibold text-slate-600">Nama</th>
                  <th className="text-left p-4 font-semibold text-slate-600">Email</th>
                  <th className="text-left p-4 font-semibold text-slate-600">Telepon</th>
                  <th className="text-left p-4 font-semibold text-slate-600">Nominal</th>
                  <th className="text-left p-4 font-semibold text-slate-600">Program</th>
                  <th className="text-left p-4 font-semibold text-slate-600">Status</th>
                  <th className="text-left p-4 font-semibold text-slate-600">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filteredDonasis.map((donasi) => (
                  <tr key={donasi.id} className="border-t border-slate-100 hover:bg-slate-50">
                    <td className="p-4 font-medium">{donasi.nama}</td>
                    <td className="p-4">{donasi.email}</td>
                    <td className="p-4">{donasi.telepon}</td>
                    <td className="p-4 font-semibold text-green-600">{formatRupiah(donasi.nominal)}</td>
                    <td className="p-4">{donasi.program}</td>
                    <td className="p-4">
                      <span className={`px-2 py-1 text-xs rounded-lg font-medium ${
                        donasi.status === 'confirmed' 
                          ? 'bg-green-500 text-white' 
                          : 'bg-yellow-500 text-white'
                      }`}>
                        {donasi.status === 'confirmed' ? 'Dikonfirmasi' : 'Menunggu'}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        {donasi.status === 'pending' && (
                          <button 
                            onClick={() => handleConfirm(donasi.id)} 
                            className="flex items-center gap-1 py-1.5 px-3 text-sm bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors"
                          >
                            <Check className="w-4 h-4" /> 
                            Konfirmasi
                          </button>
                        )}
                        <button 
                          onClick={() => handleDelete(donasi.id)}
                          className="flex items-center gap-1 py-1.5 px-3 text-sm bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                          Hapus
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

