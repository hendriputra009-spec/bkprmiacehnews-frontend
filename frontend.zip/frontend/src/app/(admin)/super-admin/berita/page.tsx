'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Eye, Search, X, Check, Loader2 } from 'lucide-react';
import { adminApi } from '@/lib/api';

const getBaseUrl = () => {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
    return new URL(apiUrl).origin;
  } catch {
    return 'http://localhost:8000';
  }
};

const getStorageUrl = (path?: string) => {
  if (!path) return `${getBaseUrl()}/storage/placeholder/berita-placeholder.svg`;
  return `${getBaseUrl()}/storage/${path}`;
};

interface Berita {
  id: number;
  judul: string;
  slug: string;
  excerpt: string;
  gambar: string;
  kategori_id: number;
  status: 'draft' | 'pending' | 'published';
  viewed: number;
  created_at: string;
  updated_at: string;
  kategori?: {
    id: number;
    nama: string;
  };
  author?: {
    id: number;
    name: string;
  };
}

interface Kategori {
  id: number;
  nama: string;
}

export default function BeritaAdminPage() {
  const [berita, setBerita] = useState<Berita[]>([]);
  const [kategori, setKategori] = useState<Kategori[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [deleteModal, setDeleteModal] = useState<{ show: boolean; id: number | null; loading: boolean }>({ show: false, id: null, loading: false });
  const [statusModal, setStatusModal] = useState<{ show: boolean; id: number | null; status: string | null; loading: boolean }>({ show: false, id: null, status: null, loading: false });

  const fetchData = async () => {
    try {
      setLoading(true);
      const params: any = {};
      if (search) params.search = search;
      if (statusFilter) params.status = statusFilter;

      const [beritaRes, kategoriRes] = await Promise.all([
        adminApi.getAdminBerita(params),
        adminApi.getAdminKategori()
      ]);

      console.log('fetchBerita response:', beritaRes.data);
      console.log('fetchKategori response:', kategoriRes.data);

      const beritaPayload = beritaRes.data?.data ?? beritaRes.data;
      const kategoriPayload = kategoriRes.data?.data ?? kategoriRes.data;

      const extractArray = (payload: any) => {
        if (Array.isArray(payload)) return payload;
        if (payload && Array.isArray(payload.data)) return payload.data;
        return [];
      };

      setBerita(extractArray(beritaPayload));
      setKategori(extractArray(kategoriPayload));
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchData();
  };

  const handleDelete = async () => {
    if (!deleteModal.id) return;
    try {
      setDeleteModal(prev => ({ ...prev, loading: true }));
      await adminApi.deleteBerita(deleteModal.id);
      setDeleteModal({ show: false, id: null, loading: false });
      fetchData();
    } catch (error) {
      console.error('Error deleting berita:', error);
      setDeleteModal({ show: false, id: null, loading: false });
    }
  };

  const handleStatusChange = async () => {
    if (!statusModal.id || !statusModal.status) return;
    try {
      setStatusModal(prev => ({ ...prev, loading: true }));
      await adminApi.toggleBeritaStatus(statusModal.id, statusModal.status);
      setStatusModal({ show: false, id: null, status: null, loading: false });
      fetchData();
    } catch (error) {
      console.error('Error changing status:', error);
      setStatusModal({ show: false, id: null, status: null, loading: false });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'published':
        return 'badge-success';
      case 'pending':
        return 'badge-warning';
      case 'draft':
        return 'badge-neutral';
      default:
        return 'badge-neutral';
    }
  };

  const getKategoriName = (kategoriId: number) => {
    const kat = kategori.find(k => k.id === kategoriId);
    return kat ? kat.nama : '-';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Kelola Berita</h1>
          <p className="text-slate-500">Kelola semua berita di website</p>
        </div>
        <a href="/super-admin/berita/create" className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" /> Tambah Berita
        </a>
      </div>

      {/* Search & Filter */}
      <div className="card mb-6">
        <form onSubmit={handleSearch}>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="text" 
                placeholder="Cari berita..." 
                className="input pl-12"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <select 
              className="input md:w-48"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="">Semua Status</option>
              <option value="published">Published</option>
              <option value="draft">Draft</option>
              <option value="pending">Pending</option>
            </select>
            <button type="submit" className="btn btn-outline">
              Cari
            </button>
          </div>
        </form>
      </div>

      {/* Table */}
      <div className="card overflow-hidden p-0">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : berita.length === 0 ? (
          <div className="text-center py-12 text-slate-500">
            <p>Belum ada berita</p>
            <a href="/super-admin/berita/create" className="text-primary hover:underline mt-2 inline-block">
              Tambah berita pertama
            </a>
          </div>
        ) : (
          <table className="w-full">
            <thead className="bg-slate-50 border-b">
              <tr>
                <th className="text-left px-6 py-4 text-sm font-medium text-slate-500">Gambar</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-slate-500">Judul</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-slate-500">Kategori</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-slate-500">Status</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-slate-500">Tanggal</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-slate-500">Views</th>
                <th className="text-right px-6 py-4 text-sm font-medium text-slate-500">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {(Array.isArray(berita) ? berita : []).map((item) => (
                <tr key={item.id} className="hover:bg-slate-50">
                  <td className="px-6 py-4">
                    {item.gambar ? (
                      <img
                        src={getStorageUrl(item.gambar)}
                        alt={item.judul}
                        className="w-14 h-10 object-cover rounded-lg"
                      />
                    ) : (
                      <div className="w-14 h-10 bg-slate-100 flex items-center justify-center rounded-lg text-slate-400 text-xs">
                        No Image
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <p className="font-medium text-slate-900">{item.judul}</p>
                    <p className="text-sm text-slate-500 truncate max-w-xs">{item.excerpt}</p>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500">
                    {getKategoriName(item.kategori_id)}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`badge ${getStatusBadge(item.status)}`}>
                      {item.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500">
                    {formatDate(item.created_at)}
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500">
                    {item.viewed}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-end gap-1">
                      <Link 
                        href={`/berita/${item.slug}?preview=1`} 
                        target="_blank"
                        className="p-2 text-slate-400 hover:text-primary transition-colors"
                        title="Lihat"
                      >
                        <Eye className="w-5 h-5" />
                      </Link>
                      <Link 
                        href={`/super-admin/berita/edit/${item.id}`}
                        className="p-2 text-slate-400 hover:text-primary transition-colors"
                        title="Edit"
                      >
                        <Edit className="w-5 h-5" />
                      </Link>
                      {item.status === 'draft' || item.status === 'pending' ? (
                        <button 
                          onClick={() => setStatusModal({ show: true, id: item.id, status: 'published', loading: false })}
                          className="p-2 text-slate-400 hover:text-green-500 transition-colors"
                          title="Publish"
                        >
                          <Check className="w-5 h-5" />
                        </button>
                      ) : (
                        <button 
                          onClick={() => setStatusModal({ show: true, id: item.id, status: 'draft', loading: false })}
                          className="p-2 text-slate-400 hover:text-yellow-500 transition-colors"
                          title="Unpublish"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      )}
                      <button 
                        onClick={() => setDeleteModal({ show: true, id: item.id, loading: false })}
                        className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                        title="Hapus"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Delete Modal */}
      {deleteModal.show && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-bold mb-4">Hapus Berita</h3>
            <p className="text-slate-600 mb-6">
              Apakah Anda yakin ingin menghapus berita ini? Tindakan ini tidak dapat dibatalkan.
            </p>
            <div className="flex gap-3 justify-end">
              <button 
                onClick={() => setDeleteModal({ show: false, id: null, loading: false })}
                className="btn btn-outline"
                disabled={deleteModal.loading}
              >
                Batal
              </button>
              <button 
                onClick={handleDelete}
                className="btn bg-red-500 text-white hover:bg-red-600"
                disabled={deleteModal.loading}
              >
                {deleteModal.loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  'Hapus'
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Status Modal */}
      {statusModal.show && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-bold mb-4">
              {statusModal.status === 'published' ? 'Publish Berita' : 'Unpublish Berita'}
            </h3>
            <p className="text-slate-600 mb-6">
              {statusModal.status === 'published' 
                ? 'Apakah Anda yakin ingin mempublish berita ini? Berita akan terlihat di halaman publik.'
                : 'Apakah Anda yakin ingin unpublish berita ini? Berita tidak akan terlihat di halaman publik.'
              }
            </p>
            <div className="flex gap-3 justify-end">
              <button 
                onClick={() => setStatusModal({ show: false, id: null, status: null, loading: false })}
                className="btn btn-outline"
                disabled={statusModal.loading}
              >
                Batal
              </button>
              <button 
                onClick={handleStatusChange}
                className={`btn ${statusModal.status === 'published' ? 'btn-primary' : 'bg-yellow-500 text-white hover:bg-yellow-600'}`}
                disabled={statusModal.loading}
              >
                {statusModal.loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  statusModal.status === 'published' ? 'Publish' : 'Unpublish'
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
