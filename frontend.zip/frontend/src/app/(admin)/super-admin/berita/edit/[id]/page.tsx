'use client';

import { useEffect, useRef, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { ArrowLeft, Save, Image as ImageIcon, Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight, List, ListOrdered, Type, Palette } from 'lucide-react';
import { adminApi } from '@/lib/api';

const getBaseUrl = () => {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
    return new URL(apiUrl).origin;
  } catch {
    return 'http://localhost:8000';
  }
};

const getStorageUrl = (path?: string) => {
  if (!path) return `${getBaseUrl()}/storage/placeholder/berita-placeholder.svg`;
  return `${getBaseUrl()}/storage/${path}`;
};

export default function EditBeritaPage() {
  const router = useRouter();
  const params = useParams();
  const id = Number(params?.id ?? 0);

  const editorRef = useRef<HTMLDivElement>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [kategoris, setKategoris] = useState<any[]>([]);
  const [gambar, setGambar] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [formData, setFormData] = useState({
    judul: '',
    slug: '',
    excerpt: '',
    konten: '',
    kategori_id: '',
    status: 'published',
    meta_title: '',
    meta_description: ''
  });

  useEffect(() => {
    if (!id) return;
    fetchData();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [beritaRes, kategoriRes] = await Promise.all([
        adminApi.getAdminBeritaDetail(id),
        adminApi.getAdminKategori(),
      ]);

      const berita = beritaRes.data?.data ?? beritaRes.data;
      const kategorisPayload = kategoriRes.data?.data ?? kategoriRes.data;

      setKategoris(Array.isArray(kategorisPayload) ? kategorisPayload : []);

      if (berita) {
        setFormData({
          judul: berita.judul || '',
          slug: berita.slug || '',
          excerpt: berita.excerpt || '',
          konten: berita.konten || '',
          kategori_id: berita.kategori_id?.toString() || '',
          status: berita.status || 'published',
          meta_title: berita.meta_title || '',
          meta_description: berita.meta_description || '',
        });

        setPreview(getStorageUrl(berita.gambar));
      }
    } catch (error) {
      console.error('Error fetching berita:', error);
      alert('Gagal memuat data berita.');
    } finally {
      setLoading(false);
    }
  };

  const generateSlug = (text: string) => {
    return text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  };

  const generateSEO = (judul: string) => {
    const slug = generateSlug(judul);
    const metaTitle = judul.length > 60 ? judul.substring(0, 60) + '...' : judul;
    const metaDesc = formData.excerpt || judul + ' - Berita terbaru dari BKPRMI Aceh';
    return { slug, meta_title: metaTitle, meta_description: metaDesc };
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const next = { ...prev, [name]: value };
      if (name === 'judul' && value) {
        const seo = generateSEO(value);
        next.slug = seo.slug;
        next.meta_title = seo.meta_title;
        next.meta_description = seo.meta_description;
      }
      if (name === 'meta_title' && value && !formData.slug) {
        next.slug = generateSlug(value);
      }
      return next;
    });
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setGambar(file);
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const execCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    editorRef.current?.focus();
  };

  const handleContentChange = () => {
    if (editorRef.current) {
      setFormData(prev => ({ ...prev, konten: editorRef.current?.innerHTML || '' }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id) return;

    setSaving(true);
    try {
      const dataToSend: any = { ...formData };
      if (gambar) dataToSend.gambar = gambar;

      await adminApi.updateBerita(id, dataToSend);
      router.push('/super-admin/berita');
    } catch (error) {
      console.error('Error updating berita:', error);
      alert('Gagal menyimpan perubahan.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-500">Memuat data berita...</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 hover:bg-slate-100 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-bold">Edit Berita</h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card p-6">
            <h2 className="font-semibold mb-4">Informasi Dasar</h2>
            <div className="space-y-4">
              <div>
                <label className="label">Judul <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  name="judul"
                  value={formData.judul}
                  onChange={handleChange}
                  className="input"
                  placeholder="Masukkan judul berita"
                  required
                />
                <p className="text-xs text-slate-500 mt-1">SEO akan dibuat otomatis dari judul</p>
              </div>
              <div>
                <label className="label">Slug <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  name="slug"
                  value={formData.slug}
                  onChange={handleChange}
                  className="input"
                  placeholder="url-seo-berita"
                  required
                />
              </div>
              <div>
                <label className="label">Excerpt / Ringkasan</label>
                <textarea
                  name="excerpt"
                  value={formData.excerpt}
                  onChange={handleChange}
                  className="input"
                  rows={3}
                  placeholder="Ringkasan singkat berita (untuk preview)"
                />
              </div>
              <div>
                <label className="label">Kategori</label>
                <select
                  name="kategori_id"
                  value={formData.kategori_id}
                  onChange={handleChange}
                  className="input"
                >
                  <option value="">Pilih Kategori</option>
                  {kategoris.map(k => (
                    <option key={k.id} value={k.id}>{k.nama}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Status</label>
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  className="input"
                >
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                </select>
              </div>
            </div>
          </div>

          <div className="card p-6">
            <h2 className="font-semibold mb-4">Gambar</h2>
            <div className="space-y-4">
              <div>
                <label className="label">Upload Gambar</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="input file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-primary file:text-white file:cursor-pointer"
                />
              </div>
              {preview && (
                <div className="mt-4">
                  <img src={preview} alt="Preview" className="max-w-full h-48 object-cover rounded-xl" />
                </div>
              )}
            </div>

            <h2 className="font-semibold mt-6 mb-4">SEO Otomatis</h2>
            <div className="space-y-4">
              <div>
                <label className="label">Meta Title</label>
                <input
                  type="text"
                  name="meta_title"
                  value={formData.meta_title}
                  onChange={handleChange}
                  className="input"
                  placeholder="Judul untuk SEO (auto dari judul)"
                />
              </div>
              <div>
                <label className="label">Meta Description</label>
                <textarea
                  name="meta_description"
                  value={formData.meta_description}
                  onChange={handleChange}
                  className="input"
                  rows={2}
                  placeholder="Deskripsi untuk SEO"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-4 justify-end">
          <button
            type="button"
            onClick={() => router.back()}
            className="btn btn-outline"
            disabled={saving}
          >
            Batal
          </button>
          <button type="submit" className="btn btn-primary flex items-center gap-2" disabled={saving}>
            {saving ? (
              <span className="flex items-center gap-2">
                <Save className="w-5 h-5 animate-spin" />
                Menyimpan...
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <Save className="w-5 h-5" />
                Simpan Perubahan
              </span>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
