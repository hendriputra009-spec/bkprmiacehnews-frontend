'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Save, Image as ImageIcon, Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight, List, ListOrdered, Type, Palette } from 'lucide-react';

export default function CreateBeritaPage() {
  const router = useRouter();
  const editorRef = useRef<HTMLDivElement>(null);
  const [loading, setLoading] = useState(false);
  const [kategoris, setKategoris] = useState<any[]>([]);
  const [gambar, setGambar] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [formData, setFormData] = useState({
    judul: '',
    slug: '',
    excerpt: '',
    konten: '',
    kategori_id: '',
    status: 'published',
    meta_title: '',
    meta_description: ''
  });

  useEffect(() => {
    fetchKategoris();
  }, []);

  const fetchKategoris = async () => {
    try {
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(`${API_URL}/kategori`);
      const data = await res.json();
      if (data.kategoris) setKategoris(data.kategoris);
    } catch (error) {
      console.error('Error fetching kategoris:', error);
    }
  };

  const generateSlug = (text: string) => {
    return text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  };

  const generateSEO = (judul: string) => {
    const slug = generateSlug(judul);
    const metaTitle = judul.length > 60 ? judul.substring(0, 60) + '...' : judul;
    const metaDesc = formData.excerpt || judul + ' - Berita terbaru dari BKPRMI Aceh';
    return { slug, meta_title: metaTitle, meta_description: metaDesc };
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const newData = { ...prev, [name]: value };
      // Auto-generate SEO when judul changes
      if (name === 'judul' && value) {
        const seo = generateSEO(value);
        newData.slug = seo.slug;
        newData.meta_title = seo.meta_title;
        newData.meta_description = seo.meta_description;
      }
      // Update slug from meta_title for SEO
      if (name === 'meta_title' && value && !formData.slug) {
        newData.slug = generateSlug(value);
      }
      return newData;
    });
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setGambar(file);
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  // Rich text editor commands
  const execCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    editorRef.current?.focus();
  };

  const handleContentChange = () => {
    if (editorRef.current) {
      setFormData(prev => ({ ...prev, konten: editorRef.current?.innerHTML || '' }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      
      const formDataToSend = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        formDataToSend.append(key, value);
      });
      if (gambar) {
        formDataToSend.append('gambar', gambar);
      }

      const res = await fetch(`${API_URL}/admin/berita`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formDataToSend,
      });

      if (res.ok) {
        router.push('/super-admin/berita');
      } else {
        const error = await res.json();
        alert('Gagal membuat berita: ' + (error.message || 'Unknown error'));
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Terjadi kesalahan');
    } finally {
      setLoading(false);
    }
  };

  const colors = ['#000000', '#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF', '#0F766E', '#EAB308', '#EF4444'];

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 hover:bg-slate-100 rounded-xl">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-bold">Buat Berita Baru</h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card p-6">
            <h2 className="font-semibold mb-4">Informasi Dasar</h2>
            <div className="space-y-4">
              <div>
                <label className="label">Judul <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  name="judul"
                  value={formData.judul}
                  onChange={handleChange}
                  className="input"
                  placeholder="Masukkan judul berita"
                  required
                />
                <p className="text-xs text-slate-500 mt-1">SEO akan dibuat otomatis dari judul</p>
              </div>
              <div>
                <label className="label">Slug <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  name="slug"
                  value={formData.slug}
                  onChange={handleChange}
                  className="input"
                  placeholder="url-seo-berita"
                  required
                />
              </div>
              <div>
                <label className="label">Excerpt / Ringkasan</label>
                <textarea
                  name="excerpt"
                  value={formData.excerpt}
                  onChange={handleChange}
                  className="input"
                  rows={3}
                  placeholder="Ringkasan singkat berita (untuk preview)"
                />
              </div>
              <div>
                <label className="label">Kategori</label>
                <select
                  name="kategori_id"
                  value={formData.kategori_id}
                  onChange={handleChange}
                  className="input"
                >
                  <option value="">Pilih Kategori</option>
                  {kategoris.map(k => (
                    <option key={k.id} value={k.id}>{k.nama}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Status</label>
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  className="input"
                >
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                </select>
              </div>
            </div>
          </div>

          <div className="card p-6">
            <h2 className="font-semibold mb-4">Gambar</h2>
            <div className="space-y-4">
              <div>
                <label className="label">Upload Gambar</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="input file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-primary file:text-white file:cursor-pointer"
                />
              </div>
              {preview && (
                <div className="mt-4">
                  <img src={preview} alt="Preview" className="max-w-full h-48 object-cover rounded-xl" />
                </div>
              )}
            </div>

            <h2 className="font-semibold mt-6 mb-4">SEO Otomatis</h2>
            <div className="space-y-4">
              <div>
                <label className="label">Meta Title</label>
                <input
                  type="text"
                  name="meta_title"
                  value={formData.meta_title}
                  onChange={handleChange}
                  className="input"
                  placeholder="Judul untuk SEO (auto dari judul)"
                />
              </div>
              <div>
                <label className="label">Meta Description</label>
                <textarea
                  name="meta_description"
                  value={formData.meta_description}
                  onChange={handleChange}
                  className="input"
                  rows={2}
                  placeholder="Deskripsi untuk SEO"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="card p-6">
          <h2 className="font-semibold mb-4">Konten Berita</h2>
          
          {/* Toolbar */}
          <div className="flex flex-wrap items-center gap-1 mb-2 p-2 bg-slate-50 rounded-lg border">
            <button type="button" onClick={() => execCommand('bold')} className="p-2 hover:bg-white rounded" title="Bold">
              <Bold className="w-4 h-4" />
            </button>
            <button type="button" onClick={() => execCommand('italic')} className="p-2 hover:bg-white rounded" title="Italic">
              <Italic className="w-4 h-4" />
            </button>
            <button type="button" onClick={() => execCommand('underline')} className="p-2 hover:bg-white rounded" title="Underline">
              <Underline className="w-4 h-4" />
            </button>
            <div className="w-px h-6 bg-slate-300 mx-1"></div>
            <button type="button" onClick={() => execCommand('justifyLeft')} className="p-2 hover:bg-white rounded" title="Rata Kiri">
              <AlignLeft className="w-4 h-4" />
            </button>
            <button type="button" onClick={() => execCommand('justifyCenter')} className="p-2 hover:bg-white rounded" title="Rata Tengah">
              <AlignCenter className="w-4 h-4" />
            </button>
            <button type="button" onClick={() => execCommand('justifyRight')} className="p-2 hover:bg-white rounded" title="Rata Kanan">
              <AlignRight className="w-4 h-4" />
            </button>
            <div className="w-px h-6 bg-slate-300 mx-1"></div>
            <button type="button" onClick={() => execCommand('insertUnorderedList')} className="p-2 hover:bg-white rounded" title="Bullet List">
              <List className="w-4 h-4" />
            </button>
            <button type="button" onClick={() => execCommand('insertOrderedList')} className="p-2 hover:bg-white rounded" title="Numbered List">
              <ListOrdered className="w-4 h-4" />
            </button>
            <div className="w-px h-6 bg-slate-300 mx-1"></div>
            <button type="button" onClick={() => execCommand('formatBlock', 'h2')} className="p-2 hover:bg-white rounded text-sm font-bold" title="Heading">
              <Type className="w-4 h-4" />
            </button>
            <div className="relative">
              <button type="button" onClick={() => setShowColorPicker(!showColorPicker)} className="p-2 hover:bg-white rounded" title="Warna Teks">
                <Palette className="w-4 h-4" />
              </button>
              {showColorPicker && (
                <div className="absolute top-full left-0 mt-1 p-2 bg-white rounded-lg shadow-lg border grid grid-cols-5 gap-1 z-10">
                  {colors.map((color, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => { execCommand('foreColor', color); setShowColorPicker(false); }}
                      className="w-6 h-6 rounded border"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Editor */}
          <div
            ref={editorRef}
            contentEditable
            onInput={handleContentChange}
            className="input min-h-[300px] prose max-w-none focus:outline-none focus:ring-2 focus:ring-primary/20"
            style={{ padding: '1rem' }}
          />
          <p className="text-sm text-slate-500 mt-2">Tulis konten berita di sini dengan menggunakan toolbar di atas</p>
        </div>

        <div className="flex justify-end gap-4">
          <button type="button" onClick={() => router.back()} className="btn-secondary">
            Batal
          </button>
          <button type="submit" disabled={loading} className="btn-primary flex items-center gap-2">
            {loading ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <Save className="w-5 h-5" />}
            Simpan Berita
          </button>
        </div>
      </form>
    </div>
  );
}

