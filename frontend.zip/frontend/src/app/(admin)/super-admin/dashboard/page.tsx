'use client';

import { useState, useEffect } from 'react';
import { FileText, Image, MapPin, Users, Heart, Eye } from 'lucide-react';

interface DashboardStats {
  total_berita: number;
  total_galeri: number;
  total_dpd: number;
  total_donasi: number;
  total_komentar: number;
  total_views: number;
  donasi_nominal: number;
  donasi_confirmed: number;
  donasi_pending: number;
  komentar_pending: number;
}

interface StatsConfig {
  label: string;
  key: string;
  icon: any;
  color: string;
}

const statsConfig: StatsConfig[] = [
  { label: 'Total Berita', key: 'total_berita', icon: FileText, color: 'bg-blue-500' },
  { label: 'Total Galeri', key: 'total_galeri', icon: Image, color: 'bg-purple-500' },
  { label: 'Total DPD', key: 'total_dpd', icon: MapPin, color: 'bg-green-500' },
  { label: 'Total Donasi', key: 'total_donasi', icon: Heart, color: 'bg-red-500' },
  { label: 'Komentar Baru', key: 'komentar_pending', icon: Users, color: 'bg-yellow-500' },
  { label: 'Total Views', key: 'total_views', icon: Eye, color: 'bg-indigo-500' },
];

export default function DashboardPage() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [statsData, setStatsData] = useState<DashboardStats>({
    total_berita: 0,
    total_galeri: 0,
    total_dpd: 0,
    total_donasi: 0,
    total_komentar: 0,
    total_views: 0,
    donasi_nominal: 0,
    donasi_confirmed: 0,
    donasi_pending: 0,
    komentar_pending: 0,
  });

  useEffect(() => {
    fetchStatistics();
    
    // Auto-refresh every 30 seconds for real-time data
    const interval = setInterval(() => {
      fetchStatistics();
    }, 30000);
    
    return () => clearInterval(interval);
  }, []);

  const fetchStatistics = async (isManualRefresh = false) => {
    try {
      if (isManualRefresh) {
        setRefreshing(true);
      }
      setError(null);
      
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      
      console.log('Fetching dashboard statistics...');
      console.log('Token:', token ? 'Present' : 'Missing');
      
      const res = await fetch(`${API_URL}/admin/dashboard/statistics`, {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json'
        }
      });
      
      console.log('Response status:', res.status);
      
      if (res.ok) {
        const data = await res.json();
        console.log('Statistics data:', data);
        
        if (data.success && data.data) {
          setStatsData({
            total_berita: data.data.total_berita || 0,
            total_galeri: data.data.total_galeri || 0,
            total_dpd: data.data.total_dpd || 0,
            total_donasi: data.data.total_donasi || 0,
            total_komentar: data.data.total_komentar || 0,
            total_views: data.data.total_views || 0,
            donasi_nominal: data.data.donasi_nominal || 0,
            donasi_confirmed: data.data.donasi_confirmed || 0,
            donasi_pending: data.data.donasi_pending || 0,
            komentar_pending: data.data.komentar_pending || 0,
          });
        }
      } else {
        const errorData = await res.json();
        console.error('Failed to fetch statistics:', errorData);
        setError(errorData.message || 'Gagal memuat data');
      }
    } catch (error) {
      console.error('Error fetching statistics:', error);
      setError('Terjadi kesalahan saat memuat data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const formatRupiah = (amount: number) => {
    if (amount === 0) return 'Rp 0';
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(amount);
  };

  const getDisplayValue = (key: string): string => {
    if (loading) return '0';
    
    const value = statsData[key as keyof DashboardStats];
    
    if (key === 'total_donasi') {
      return formatRupiah(statsData.donasi_nominal);
    }
    
    return typeof value === 'number' ? value.toString() : '0';
  };

  return (
    <div>
      <div className="mb-8 flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
          <p className="text-slate-500">Selamat datang di panel admin BKPRMI Aceh</p>
        </div>
        <button 
          onClick={() => fetchStatistics(true)}
          disabled={refreshing}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2"
        >
          {refreshing ? (
            <>
              <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
              <span>Memuat...</span>
            </>
          ) : (
            'Refresh'
          )}
        </button>
      </div>

      {/* Error Message */}
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
        {statsConfig.map((stat, index) => (
          <div key={index} className="card">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl ${stat.color} flex items-center justify-center`}>
                <stat.icon className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">
                  {getDisplayValue(stat.key)}
                </p>
                <p className="text-xs text-slate-500">{stat.label}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="card mb-8">
        <h2 className="text-lg font-semibold text-slate-900 mb-4">Aksi Cepat</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <a href="/super-admin/berita/create" className="p-4 bg-blue-50 rounded-xl text-center hover:bg-blue-100 transition-colors">
            <FileText className="w-6 h-6 text-blue-600 mx-auto mb-2" />
            <span className="text-sm font-medium text-blue-600">Tambah Berita</span>
          </a>
          <a href="/super-admin/galeri/create" className="p-4 bg-purple-50 rounded-xl text-center hover:bg-purple-100 transition-colors">
            <Image className="w-6 h-6 text-purple-600 mx-auto mb-2" />
            <span className="text-sm font-medium text-purple-600">Tambah Galeri</span>
          </a>
          <a href="/super-admin/dpd" className="p-4 bg-green-50 rounded-xl text-center hover:bg-green-100 transition-colors">
            <MapPin className="w-6 h-6 text-green-600 mx-auto mb-2" />
            <span className="text-sm font-medium text-green-600">Kelola DPD</span>
          </a>
          <a href="/super-admin/donasi" className="p-4 bg-red-50 rounded-xl text-center hover:bg-red-100 transition-colors">
            <Heart className="w-6 h-6 text-red-600 mx-auto mb-2" />
            <span className="text-sm font-medium text-red-600">Lihat Donasi</span>
          </a>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="card">
        <h2 className="text-lg font-semibold text-slate-900 mb-4">Aktivitas Terbaru</h2>
        <div className="text-center py-8 text-slate-400">
          <p>Belum ada aktivitas terbaru.</p>
          <p className="text-sm mt-1">Konten akan muncul setelah admin menambahkan data.</p>
        </div>
      </div>
    </div>
  );
}

