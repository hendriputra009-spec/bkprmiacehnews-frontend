import Link from 'next/link';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import ShareButtons from '@/components/news/ShareButtons';
import { ArrowLeft, Calendar, Image as ImageIcon, ChevronRight, ExternalLink } from 'lucide-react';

export const dynamic = 'force-dynamic';

const getApiUrl = () => process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

const getApiOrigin = () => {
  try {
    return new URL(getApiUrl()).origin;
  } catch {
    return 'http://localhost:8000';
  }
};

function formatDate(dateString: string) {
  const date = new Date(dateString);
  return date.toLocaleDateString('id-ID', { 
    weekday: 'long',
    day: 'numeric', 
    month: 'long', 
    year: 'numeric' 
  });
}

export default async function GaleriDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const baseUrl = getApiUrl();
  const baseOrigin = getApiOrigin();
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://bkpmriaceh.org';

  try {
    const res = await fetch(
      `${baseUrl}/galeri/${encodeURIComponent(slug)}`,
      { cache: 'no-store' }
    );

    if (!res.ok) {
      throw new Error('Failed to fetch');
    }

    const payload = await res.json();
    const galeri = payload?.data;

    if (!galeri) {
      return (
        <div className="min-h-screen flex flex-col bg-slate-50">
          <Navbar />
          
          <div className="bg-white border-b border-slate-200">
            <div className="container-page py-3">
              <nav className="flex items-center gap-2 text-sm">
                <Link href="/" className="text-slate-500 hover:text-primary transition-colors">
                  Beranda
                </Link>
                <ChevronRight className="w-4 h-4 text-slate-400" />
                <Link href="/galeri" className="text-slate-500 hover:text-primary transition-colors">
                  Galeri
                </Link>
                <ChevronRight className="w-4 h-4 text-slate-400" />
                <span className="text-slate-900 font-medium truncate max-w-xs">
                  {slug}
                </span>
              </nav>
            </div>
          </div>

          <main className="flex-1 py-8">
            <div className="container-page">
              <div className="text-center py-20 bg-white rounded-2xl border border-slate-200">
                <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-4xl">🖼️</span>
                </div>
                <h1 className="text-2xl font-bold text-slate-900 mb-2">Galeri Tidak Ditemukan</h1>
                <p className="text-slate-500 mb-6">Data galeri tidak tersedia.</p>
                <Link href="/galeri" className="btn btn-primary">
                  Kembali ke Galeri
                </Link>
              </div>
            </div>
          </main>
          
          <Footer />
        </div>
      );
    }

    // Get image URL
    const imagePath = galeri.gambar || galeri.gambar_url || '';
    const imageUrl = imagePath 
      ? `${baseOrigin}/storage/${imagePath}`
      : null;

    return (
      <div className="min-h-screen flex flex-col bg-slate-50">
        <Navbar />
        
        {/* Breadcrumb */}
        <div className="bg-white border-b border-slate-200">
          <div className="container-page py-3">
            <nav className="flex items-center gap-2 text-sm">
              <Link href="/" className="text-slate-500 hover:text-primary transition-colors">
                Beranda
              </Link>
              <ChevronRight className="w-4 h-4 text-slate-400" />
              <Link href="/galeri" className="text-slate-500 hover:text-primary transition-colors">
                Galeri
              </Link>
              <ChevronRight className="w-4 h-4 text-slate-400" />
              <span className="text-slate-900 font-medium truncate max-w-xs">
                {galeri.judul}
              </span>
            </nav>
          </div>
        </div>

        <main className="flex-1 py-8">
          <div className="container-page">
            {/* Back Button */}
            <Link 
              href="/galeri" 
              className="inline-flex items-center gap-2 text-slate-600 hover:text-primary transition-colors mb-6"
            >
              <ArrowLeft className="w-4 h-4" /> 
              Kembali ke Galeri
            </Link>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Main Content */}
              <div className="lg:col-span-2 space-y-6">
                {/* Image */}
                <div className="relative rounded-2xl overflow-hidden shadow-lg bg-white">
                  {imageUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={imageUrl}
                      alt={galeri.judul}
                      className="w-full h-auto object-contain max-h-[600px]"
                    />
                  ) : (
                    <div className="w-full aspect-video bg-slate-200 flex items-center justify-center">
                      <div className="text-center">
                        <ImageIcon className="w-16 h-16 text-slate-300 mx-auto mb-2" />
                        <p className="text-slate-400 text-sm">Gambar tidak tersedia</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Title & Description */}
                <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                  <h1 className="text-2xl md:text-3xl font-heading font-bold text-slate-900 mb-4">
                    {galeri.judul}
                  </h1>
                  
                  <div className="flex flex-wrap items-center gap-4 mb-6">
                    {galeri.tanggal && (
                      <span className="flex items-center gap-2 text-sm text-slate-500">
                        <Calendar className="w-4 h-4" />
                        {formatDate(galeri.tanggal)}
                      </span>
                    )}
                  </div>

                  <p className="text-slate-700 leading-relaxed whitespace-pre-line">
                    {galeri.deskripsi || 'Deskripsi belum tersedia.'}
                  </p>
                </div>

                {/* Share Buttons */}
                <div className="bg-white rounded-xl border border-slate-200 p-5">
                  <ShareButtons 
                    title={galeri.judul}
                    description={galeri.deskripsi || `Galeri: ${galeri.judul}`}
                    url={`${siteUrl}/galeri/${galeri.slug}`}
                    image={imageUrl || undefined}
                  />
                </div>
              </div>

              {/* Sidebar */}
              <aside className="space-y-6">
                {/* Info Card */}
                <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                  <h2 className="font-semibold text-lg text-slate-900 mb-4">Informasi Galeri</h2>
                  <div className="space-y-4 text-sm">
                    <div className="flex justify-between items-center py-2 border-b border-slate-100">
                      <span className="text-slate-500">Status</span>
                      <span className={`font-medium px-2 py-0.5 rounded-full text-xs ${
                        galeri.status === 'published' 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-yellow-100 text-yellow-700'
                      }`}>
                        {galeri.status === 'published' ? 'Published' : 'Draft'}
                      </span>
                    </div>
                    {galeri.tanggal && (
                      <div className="flex justify-between items-center py-2 border-b border-slate-100">
                        <span className="text-slate-500">Tanggal</span>
                        <span className="text-slate-900 font-medium">
                          {new Date(galeri.tanggal).toLocaleDateString('id-ID')}
                        </span>
                      </div>
                    )}
                    {galeri.created_at && (
                      <div className="flex justify-between items-center py-2">
                        <span className="text-slate-500">Dibuat</span>
                        <span className="text-slate-900 font-medium">
                          {new Date(galeri.created_at).toLocaleDateString('id-ID')}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  {/* Open Image Button */}
                  {imageUrl && (
                    <a
                      href={imageUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-4 w-full btn btn-primary flex items-center justify-center gap-2"
                    >
                      <ExternalLink className="w-4 h-4" />
                      Buka Gambar
                    </a>
                  )}
                </div>

              </aside>
            </div>
          </div>
        </main>
        
        <Footer />
      </div>
    );
  } catch (error) {
    console.error('Error fetching gallery:', error);
    
    return (
      <div className="min-h-screen flex flex-col bg-slate-50">
        <Navbar />
        
        <div className="bg-white border-b border-slate-200">
          <div className="container-page py-3">
            <nav className="flex items-center gap-2 text-sm">
              <Link href="/" className="text-slate-500 hover:text-primary transition-colors">
                Beranda
              </Link>
              <ChevronRight className="w-4 h-4 text-slate-400" />
              <Link href="/galeri" className="text-slate-500 hover:text-primary transition-colors">
                Galeri
              </Link>
              <ChevronRight className="w-4 h-4 text-slate-400" />
              <span className="text-slate-900 font-medium truncate max-w-xs">
                {slug}
              </span>
            </nav>
          </div>
        </div>

        <main className="flex-1 py-8">
          <div className="container-page">
            <div className="text-center py-20 bg-white rounded-2xl border border-slate-200">
              <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-4xl">🖼️</span>
              </div>
              <h1 className="text-2xl font-bold text-slate-900 mb-2">Galeri Tidak Ditemukan</h1>
              <p className="text-slate-500 mb-6">Terjadi kesalahan saat memuat galeri.</p>
              <Link href="/galeri" className="btn btn-primary">
                Kembali ke Galeri
              </Link>
            </div>
          </div>
        </main>
        
        <Footer />
      </div>
    );
  }
}

