'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Plus, Search, Edit, Trash2, Building2, Image } from 'lucide-react';

const getBaseUrl = () => {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
    return new URL(apiUrl).origin;
  } catch {
    return 'http://localhost:8000';
  }
};

const getStorageUrl = (path?: string) => {
  if (!path) return null;
  return getBaseUrl() + '/storage/' + path;
};

export default function LembagaAdminPage() {
  const router = useRouter();
  const [lembagas, setLembagas] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetchLembagas();
  }, []);

  const fetchLembagas = async () => {
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(API_URL + '/admin/lembaga', {
        headers: { 'Authorization': 'Bearer ' + token }
      });
      const data = await res.json();
      if (data.lembagas) setLembagas(data.lembagas);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Yakin hapus lembaga ini?')) return;
    try {
      const token = localStorage.getItem('token');
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';
      const res = await fetch(API_URL + '/admin/lembaga/' + id, {
        method: 'DELETE',
        headers: { 'Authorization': 'Bearer ' + token }
      });
      if (res.ok) {
        setLembagas(lembagas.filter(l => l.id !== id));
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const filteredLembagas = lembagas.filter(l => 
    l.nama && l.nama.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Kelola Lembaga</h1>
        <button onClick={() => router.push('/super-admin/lembaga/create')} className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" /> Tambah Lembaga
        </button>
      </div>

      <div className="card">
        <div className="p-4 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input type="text" placeholder="Cari lembaga..." value={search} onChange={(e) => setSearch(e.target.value)} className="input pl-10" />
          </div>

        {loading ? (
          <div className="p-8 text-center">
            <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          </div>
        ) : filteredLembagas.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <Building2 className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Belum ada lembaga</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="text-left p-4">Logo</th>
                  <th className="text-left p-4">Nama</th>
                  <th className="text-left p-4">Slug</th>
                  <th className="text-left p-4">Status</th>
                  <th className="text-left p-4">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filteredLembagas.map((lembaga) => (
                  <tr key={lembaga.id} className="border-t hover:bg-slate-50">
                    <td className="p-4">
                      <div className="w-12 h-12 rounded-lg bg-slate-100 overflow-hidden flex items-center justify-center">
                        {lembaga.logo ? (
                          <img src={getStorageUrl(lembaga.logo) || ''} alt={lembaga.nama} className="w-full h-full object-contain" />
                        ) : (
                          <Image className="w-6 h-6 text-slate-400" />
                        )}
                      </div>
                    </td>
                    <td className="p-4 font-medium">{lembaga.nama}</td>
                    <td className="p-4">{lembaga.slug}</td>
                    <td className="p-4">
                      <span className={'px-2 py-1 text-xs rounded-lg ' + (lembaga.status === 'aktif' ? 'bg-green-500 text-white' : 'bg-red-500 text-white')}>
                        {lembaga.status}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="flex gap-2">
                        <button onClick={() => router.push('/super-admin/lembaga/edit/' + lembaga.id)} className="btn-secondary p-2">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDelete(lembaga.id)} className="btn-danger p-2">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  </div>
  );
}
