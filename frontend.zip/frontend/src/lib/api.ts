import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

const api: AxiosInstance = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      if (typeof window !== 'undefined') {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

// Public API
export const publicApi = {
  // Berita
  getBerita: (params?: any) => api.get('/berita', { params }),
  getBeritaDetail: (slug: string) => api.get(`/berita/${slug}`),
  
  // Kategori
  getKategori: () => api.get('/kategori'),
  
  // Galeri
  getGaleri: (params?: any) => api.get('/galeri', { params }),
  getGaleriDetail: (slug: string) => api.get(`/galeri/${slug}`),
  
  // DPD
  getDpd: () => api.get('/dpd'),
  getDpdDetail: (slug: string) => api.get(`/dpd/${slug}`),

  // Kabupaten (regencies)
  getKabupaten: () => api.get('/kabupaten'),

  // Tata Jumat
  getTataJumat: (params?: any) => api.get('/tata-jumat', { params }),
  getTataJumatDetail: (id: number) => api.get(`/tata-jumat/${id}`),
  
  // Lembaga
  getLembaga: () => api.get('/lembaga'),
  getLembagaDetail: (slug: string) => api.get(`/lembaga/${slug}`),
  
  // Profil
  getProfil: (jenis?: string) => api.get('/profil', { params: { jenis } }),
  
  // Form submissions
  postKomentar: (data: any) => api.post('/komentar', data),
  postDonasi: (data: any) => api.post('/donasi', data),
};

// Auth API
export const authApi = {
  login: (email: string, password: string) => 
    api.post('/admin/login', { email, password }),
  loginDpd: (email: string, password: string) => 
    api.post('/dpd/login', { email, password }),
  logout: () => api.post('/admin/logout'),
  me: () => api.get('/admin/me'),
};

// Admin API
export const adminApi = {
  // Berita
  getAdminBerita: (params?: any) => api.get('/admin/berita', { params }),
  getAdminBeritaDetail: (id: number) => api.get(`/admin/berita/${id}`),
  createBerita: (data: any) => {
    const formData = new FormData();
    Object.keys(data).forEach(key => {
      if (data[key] !== undefined && data[key] !== null) {
        formData.append(key, data[key]);
      }
    });
    return api.post('/admin/berita', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  updateBerita: (id: number, data: any) => {
    const formData = new FormData();
    Object.keys(data).forEach(key => {
      if (data[key] !== undefined && data[key] !== null) {
        formData.append(key, data[key]);
      }
    });
    return api.post(`/admin/berita/${id}?_method=PUT`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  deleteBerita: (id: number) => api.delete(`/admin/berita/${id}`),
  toggleBeritaStatus: (id: number, status: string) => 
    api.put(`/admin/berita/${id}/status`, { status }),
  
  // Galeri
  getAdminGaleri: (params?: any) => api.get('/admin/galeri', { params }),
  createGaleri: (data: any) => {
    const formData = new FormData();
    Object.keys(data).forEach(key => {
      if (data[key] !== undefined && data[key] !== null) {
        formData.append(key, data[key]);
      }
    });
    return api.post('/admin/galeri', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  updateGaleri: (id: number, data: any) => {
    const formData = new FormData();
    Object.keys(data).forEach(key => {
      if (data[key] !== undefined && data[key] !== null) {
        formData.append(key, data[key]);
      }
    });
    return api.post(`/admin/galeri/${id}?_method=PUT`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  deleteGaleri: (id: number) => api.delete(`/admin/galeri/${id}`),
  
  // DPD
  getAdminDpd: (params?: any) => api.get('/admin/dpd', { params }),
  getAdminDpdDetail: (id: number) => api.get(`/admin/dpd/${id}`),
  createDpd: (data: any) => api.post('/admin/dpd', data),
  updateDpd: (id: number, data: any) => api.put(`/admin/dpd/${id}`, data),
  deleteDpd: (id: number) => api.delete(`/admin/dpd/${id}`),
  createDpdAdmin: (id: number, data: any) => api.post(`/admin/dpd/${id}/admin`, data),
  
  // Tata Jumat
  getAdminTataJumat: (params?: any) => api.get('/admin/tata-jumat', { params }),
  createTataJumat: (data: any) => {
    const formData = new FormData();
    Object.keys(data).forEach(key => {
      if (data[key] !== undefined && data[key] !== null) {
        formData.append(key, data[key]);
      }
    });
    return api.post('/admin/tata-jumat', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  updateTataJumat: (id: number, data: any) => {
    const formData = new FormData();
    Object.keys(data).forEach(key => {
      if (data[key] !== undefined && data[key] !== null) {
        formData.append(key, data[key]);
      }
    });
    return api.post(`/admin/tata-jumat/${id}?_method=PUT`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  deleteTataJumat: (id: number) => api.delete(`/admin/tata-jumat/${id}`),
  
  // Lembaga
  getAdminLembaga: (params?: any) => api.get('/admin/lembaga', { params }),
  createLembaga: (data: any) => {
    const formData = new FormData();
    Object.keys(data).forEach(key => {
      if (data[key] !== undefined && data[key] !== null) {
        formData.append(key, data[key]);
      }
    });
    return api.post('/admin/lembaga', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  updateLembaga: (id: number, data: any) => {
    const formData = new FormData();
    Object.keys(data).forEach(key => {
      if (data[key] !== undefined && data[key] !== null) {
        formData.append(key, data[key]);
      }
    });
    return api.post(`/admin/lembaga/${id}?_method=PUT`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  deleteLembaga: (id: number) => api.delete(`/admin/lembaga/${id}`),
  
  // Kategori
  getAdminKategori: (params?: any) => api.get('/admin/kategori', { params }),
  createKategori: (data: any) => api.post('/admin/kategori', data),
  updateKategori: (id: number, data: any) => api.put(`/admin/kategori/${id}`, data),
  deleteKategori: (id: number) => api.delete(`/admin/kategori/${id}`),
  
  // Komentar
  getAdminKomentar: (params?: any) => api.get('/admin/komentar', { params }),
  approveKomentar: (id: number) => api.put(`/admin/komentar/${id}/approve`),
  rejectKomentar: (id: number) => api.put(`/admin/komentar/${id}/reject`),
  deleteKomentar: (id: number) => api.delete(`/admin/komentar/${id}`),
  
  // Donasi
  getAdminDonasi: (params?: any) => api.get('/admin/donasi', { params }),
  confirmDonasi: (id: number) => api.put(`/admin/donasi/${id}/confirm`),
  
  // Profil
  getAdminProfil: () => api.get('/admin/profil'),
  updateProfil: (jenis: string, data: any) => {
    const formData = new FormData();
    Object.keys(data).forEach(key => {
      if (data[key] !== undefined && data[key] !== null) {
        formData.append(key, data[key]);
      }
    });
    return api.put(`/admin/profil/${jenis}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
};

// DPD Admin API
export const dpdApi = {
  getProfile: () => api.get('/dpd/profile'),
  updateProfile: (data: any) => {
    const formData = new FormData();
    Object.keys(data).forEach(key => {
      if (data[key] !== undefined && data[key] !== null) {
        formData.append(key, data[key]);
      }
    });
    return api.put('/dpd/profile', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  getTataJumat: (params?: any) => api.get('/dpd/tata-jumat', { params }),
  createTataJumat: (data: any) => {
    const formData = new FormData();
    Object.keys(data).forEach(key => {
      if (data[key] !== undefined && data[key] !== null) {
        formData.append(key, data[key]);
      }
    });
    return api.post('/dpd/tata-jumat', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  updateTataJumat: (id: number, data: any) => {
    const formData = new FormData();
    Object.keys(data).forEach(key => {
      if (data[key] !== undefined && data[key] !== null) {
        formData.append(key, data[key]);
      }
    });
    return api.put(`/dpd/tata-jumat/${id}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  deleteTataJumat: (id: number) => api.delete(`/dpd/tata-jumat/${id}`),
};

export default api;
